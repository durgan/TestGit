DROP TABLE IF EXISTS `ew_car_owner`;
CREATE TABLE `ew_car_owner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(255) NOT NULL COMMENT '姓名',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `phone` varchar(255) NOT NULL COMMENT '手机号',
  `id_no` varchar(255) DEFAULT NULL COMMENT '身份证',
  `drive_no` varchar(255) DEFAULT NULL COMMENT '驾驶证',
  `address` varchar(255) DEFAULT NULL COMMENT '常住地址',
  `address_detail` varchar(255) DEFAULT NULL COMMENT '详细地址，门牌号',
  `icon` text COMMENT '头像',
  `sex` tinyint(1) DEFAULT '1' COMMENT '性别：1：男 2：女',
  `birthday` date DEFAULT NULL COMMENT '用户生日',
  `token` varchar(255) DEFAULT '0' COMMENT '用户Token(密码+当前时间,MD5加密)',
  `level` int(11) DEFAULT '0' COMMENT '等级',
  `level_point` int(11) DEFAULT '100' COMMENT '等级评分',
  `device` varchar(255) DEFAULT NULL COMMENT '用户设备',
  `push_token` varchar(256) DEFAULT NULL COMMENT '消息推送设备token',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`),
  KEY `username_index` (`username`),
  KEY `token_index` (`token`),
  KEY `phone_index` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车主用户管理表';

DROP TABLE IF EXISTS `ew_car`;
CREATE TABLE `ew_car` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `owner_id` bigint(20) NOT NULL COMMENT '车主ID',
  `car_no` varchar(255) NOT NULL COMMENT '行驶证',
  `car_plate_number` varchar(255) NOT NULL COMMENT '车牌号',
  `car_type_id` bigint(20) NOT NULL COMMENT '车型ID',
  `buy_time` datetime NOT NULL COMMENT '购买时间/上路时间',
  `regist_time` datetime NOT NULL COMMENT '车辆注册时间/第一次上牌时间',
  `vin_code` varchar(255) NOT NULL COMMENT '车架号',
  `engine_code` varchar(255) NOT NULL COMMENT '发动机号',
  `drive_kilo` int(11) DEFAULT NULL COMMENT '行驶里程',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`),
  KEY `car_type_id_index` (`car_type_id`),
  KEY `vin_code_index` (`vin_code`),
  KEY `engine_code_index` (`engine_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车辆管理表';

DROP TABLE IF EXISTS `ew_car_bind`;
CREATE TABLE `ew_car_bind` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `owner_id` bigint(20) NOT NULL COMMENT '车主ID',
  `car_id` bigint(20) NOT NULL COMMENT '车辆ID',
  `status` tinyint(1) DEFAULT '0' COMMENT '审核状态，0：待审核，1：审核通过，2：审核不通过',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`),
  KEY `owner_id_index` (`owner_id`),
  KEY `car_id_index` (`car_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车辆绑定管理表';

DROP TABLE IF EXISTS `ew_car_brand`;
CREATE TABLE `ew_car_brand` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(255) NOT NULL COMMENT '品牌名称',
  `icon` varchar(255) NOT NULL COMMENT '品牌图标',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`),
  KEY `name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车辆品牌管理表';

DROP TABLE IF EXISTS `ew_car_series`;
CREATE TABLE `ew_car_series` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `brand_id` bigint(20) NOT NULL COMMENT '品牌ID',
  `name` varchar(255) NOT NULL COMMENT '系列名称',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`),
  KEY `brand_id_index` (`brand_id`),
  KEY `name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车系管理表';

DROP TABLE IF EXISTS `ew_car_type`;
CREATE TABLE `ew_car_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `series_id` bigint(20) NOT NULL COMMENT '车系ID',
  `name` varchar(255) NOT NULL COMMENT '型号名称',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`),
  KEY `series_id_index` (`series_id`),
  KEY `name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车型管理表';

DROP TABLE IF EXISTS `ew_assessor`;
CREATE TABLE `ew_assessor` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `code` varchar(255) NOT NULL COMMENT '工号',
  `username` varchar(255) NOT NULL COMMENT '姓名',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `phone` varchar(255) NOT NULL COMMENT '手机号',
  `address` varchar(255) DEFAULT NULL COMMENT '常住地址',
  `address_detail` varchar(255) DEFAULT NULL COMMENT '详细地址，门牌号',
  `icon` text COMMENT '头像',
  `sex` tinyint(1) DEFAULT '1' COMMENT '性别：1：男 2：女',
  `birthday` date DEFAULT NULL COMMENT '用户生日',
  `token` varchar(255) DEFAULT '0' COMMENT '用户Token(密码+当前时间,MD5加密)',
  `level` int(11) DEFAULT '0' COMMENT '等级',
  `level_point` int(11) DEFAULT '100' COMMENT '等级评分',
  `device` varchar(255) DEFAULT NULL COMMENT '用户设备',
  `push_token` varchar(256) DEFAULT NULL COMMENT '消息推送设备token',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`),
  KEY `code_index` (`code`),
  KEY `username_index` (`username`),
  KEY `token_index` (`token`),
  KEY `phone_index` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='定损员管理表';

DROP TABLE IF EXISTS `ew_engineer`;
CREATE TABLE `ew_engineer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `shop_id` bigint(20) NOT NULL COMMENT '4S店/经销商ID',
  `code` varchar(255) NOT NULL COMMENT '工号',
  `username` varchar(255) NOT NULL COMMENT '姓名',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `phone` varchar(255) NOT NULL COMMENT '手机号',
  `address` varchar(255) DEFAULT NULL COMMENT '常住地址',
  `address_detail` varchar(255) DEFAULT NULL COMMENT '详细地址，门牌号',
  `icon` text COMMENT '头像',
  `sex` tinyint(1) DEFAULT '1' COMMENT '性别：1：男 2：女',
  `birthday` date DEFAULT NULL COMMENT '用户生日',
  `token` varchar(255) DEFAULT '0' COMMENT '用户Token(密码+当前时间,MD5加密)',
  `level` int(11) DEFAULT '0' COMMENT '等级',
  `level_point` int(11) DEFAULT '100' COMMENT '等级评分',
  `device` varchar(255) DEFAULT NULL COMMENT '用户设备',
  `push_token` varchar(256) DEFAULT NULL COMMENT '消息推送设备token',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`),
  KEY `code_index` (`code`),
  KEY `username_index` (`username`),
  KEY `token_index` (`token`),
  KEY `phone_index` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='合作4S店/经销商技师管理表';

DROP TABLE IF EXISTS `ew_shop`;
CREATE TABLE `ew_shop` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(255) NOT NULL COMMENT '4S店/经销商名称',
  `code` varchar(255) NOT NULL COMMENT '4S店/经销商编码',
  `address` varchar(255) NOT NULL COMMENT '详细地址',
  `longitude` decimal(14,10) DEFAULT '0.0000000000' COMMENT '地址经度',
  `latitude` decimal(14,10) DEFAULT '0.0000000000' COMMENT '地址纬度',
  `phone` varchar(255) NOT NULL COMMENT '联系电话',
  `start_time` datetime NOT NULL COMMENT '营业开始时间',
  `end_time` datetime NOT NULL COMMENT '营业结束时间',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`),
  KEY `name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='4S店/经销商管理表';

DROP TABLE IF EXISTS `ew_maintain`;
CREATE TABLE `ew_maintain` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `owner_id` bigint(20) NOT NULL COMMENT '车主ID',
  `car_id` bigint(20) NOT NULL COMMENT '车辆ID',
  `shop_id` bigint(20) NOT NULL COMMENT '4S店/经销商ID',
  `contact_name` varchar(255) NOT NULL COMMENT '联系人',
  `contact_phone` varchar(255) NOT NULL COMMENT '联系电话',
  `start_time` datetime NOT NULL COMMENT '预约保养开始时间',
  `end_time` datetime NOT NULL COMMENT '预约保养结束时间',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`),
  KEY `owner_id_index` (`owner_id`),
  KEY `car_id_index` (`car_id`),
  KEY `shop_id_index` (`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='保养预约管理表';

DROP TABLE IF EXISTS `ew_article`;
CREATE TABLE `ew_article` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `time` datetime NOT NULL COMMENT '发布时间',
  `image` text NOT NULL COMMENT '封面图片',
  `type` tinyint(1) DEFAULT '0' COMMENT '板块类型，0：自驾游活动，1：二手车板块，2：险企宣传板块，3：友商宣传板块，4：车厂宣传板块',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='宣传板块管理表';

DROP TABLE IF EXISTS `ew_gas_record`;
CREATE TABLE `ew_gas_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `car_id` bigint(20) NOT NULL COMMENT '车辆ID',
  `gas_id` bigint(20) NOT NULL COMMENT '汽油标号ID',
  `drive_kilo` int(11) DEFAULT NULL COMMENT '当前里程',
  `gas_mass` decimal(14,2) DEFAULT '0.00' COMMENT '加油量（升）',
  `gas_price` decimal(14,2) DEFAULT '0.00' COMMENT '单价（元）',
  `gas_total_price` decimal(14,2) DEFAULT '0.00' COMMENT '加油金额（元）',
  `gas_station_name` varchar(255) NOT NULL COMMENT '加油站名称',
  `gas_wear` decimal(14,2) DEFAULT '0.00' COMMENT '本次油耗（L/100KM）',
  `remark` text NOT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`),
  KEY `car_id_index` (`car_id`),
  KEY `gas_id_index` (`gas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='油耗记录管理表';

DROP TABLE IF EXISTS `ew_gas`;
CREATE TABLE `ew_gas` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(255) NOT NULL COMMENT '汽油标号名称',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='汽油标号管理表';

DROP TABLE IF EXISTS `ew_car_account`;
CREATE TABLE `ew_car_account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `type` tinyint(1) DEFAULT '0' COMMENT '费用类型，0：行车费，1：维修，2：保养，3：保险，4：交通处罚，5：其他',
  `money` decimal(14,2) DEFAULT '0.00' COMMENT '支出（元）',
  `remark` text NOT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新者',
  `update_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `del_flag` varchar(64) DEFAULT '0' COMMENT '逻辑删除标记（0：未删除；1：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用车费用管理表';