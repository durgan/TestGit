#!/bin/bash

if [ $# -ne 2 ];then
    echo "Usage: $0 start_org_num end_org_num"
    exit
fi

start_num=$1
end_num=$2

for((i=$start_num; i<=$end_num; i++))
do
    container=rca.org${i}.cnsuning.com   
    echo "stop $container"
    docker stop $container
    if [ $? -eq 0 ];then
        echo "stop $container successful"
    else
        echo "failed to stop $container"
        echo "command: docker stop $container"
    fi
    sleep 3
done

