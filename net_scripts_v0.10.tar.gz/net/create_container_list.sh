#!/bin/bash

. scripts/env.sh

list_file=container.list
rm -f "${list_file}"

# create orderer list
for org in $ORDERER_ORGS
do
    for((i=1; i<= $NUM_ORDERERS; i++))
    do
        echo "orderer${i}.$org$DOMAIN" >> "${list_file}"
    done
done

for org in $PEER_ORGS
do
    for((i=1; i<=$NUM_PEERS; i++))
    do
        echo "peer${i}.$org$DOMAIN" >> "${list_file}"
    done
done
