#!/bin/bash

if [ $# -ne 1 ];then
    echo "Usage: $0 org_count"
    exit
fi

org_count=$1

for((i=0; i<=$org_count; i++))
do
    container=rca.org${i}.cnsuning.com   
    echo "==================== $container ===================="
    docker exec -it $container ps -ef | grep fabric-ca-server
    if [ $? -eq 0 ];then
        echo "==================== check $container successful ===================="
    else
        echo "==================== failed to check $container ===================="
    fi
done

