#!/bin/bash

docker-compose -f docker-compose-orderer.yml up -d || exit 1
docker exec -d $1 /scripts/init_fabric-ca.sh ||  exit 1

echo "start fabric-orderer successful"
