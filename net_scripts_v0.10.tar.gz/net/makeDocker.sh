#!/bin/bash
#
# Copyright IBM Corp. All Rights Reserved.
#
# SPDX-License-Identifier: Apache-2.0
#

#
# This script builds the docker compose file needed to run this sample.
#

SDIR=$(dirname "$0")
source $SDIR/scripts/env.sh

function main {
   echo "$CONTAINER_TZ" > container_timezone

   {
   writeHeader
   writeRootFabricCA
   } > $SDIR/docker-compose-ca.yml
   log "Created docker-compose-ca.yml"

   {
   writeHeader
   writeSetupFabric
   } > $SDIR/docker-compose-setup.yml
   log "Created docker-compose-setup.yml"

   writeOrderfabric 
   writePeerfabric   

   {
   writeHeader
   writeRunFabric
   } > $SDIR/docker-compose-run.yml
   log "Created docker-compose-run.yml"

   {
   writeHeader
   writeCliFabric
   } > $SDIR/docker-compose-cli.yml
   log "Created docker-compose-cli.yml"

   {
   echo "[ca]"
   current=0
   for ORG in $ORGS; do
       initOrgVars $ORG
       PORT1=`expr $current \* 10`
       PORT2=`expr 7054 + $PORT1`
       current=`expr $current + 1`
       echo "$ROOT_CA_NAME = $CA_IP:$PORT2"
   done
   
   echo ""
   echo "[orderer]"
   for ORG in $ORDERER_ORGS; do
      COUNT=0
      while [[ "$COUNT" -le $NUM_ORDERERS ]]; do
         initOrdererVars $ORG $COUNT
         name="ORDERIP$COUNT"
         ca_ip=`sed "/^$name=/!d;s/.*=//" $SDIR/scripts/env.sh`
         echo "$ORDERER_NAME = $ca_ip:7050"
         COUNT=$((COUNT+1))
      done
   done
   echo ""

   echo "[peer]"
   for ORG in $PEER_ORGS; do
      COUNT=1
      while [[ "$COUNT" -le $NUM_PEERS ]]; do
         initPeerVars $ORG $COUNT
         echo "$PEER_NAME = "
         COUNT=$((COUNT+1))
      done
   done
   } >$SDIR/peer.ini
}

# Write services for the root fabric CA servers
function writeRootFabricCA {
   current=0
   for ORG in $ORGS; do
      initOrgVars $ORG
      PORT1=`expr $current \* 10`
      PORT2=`expr 7054 + $PORT1`
      current=`expr $current + 1`
      writeRootCA  $PORT2
   done
}

# Write services for the intermediate fabric CA servers
function writeIntermediateFabricCA {
   for ORG in $ORGS; do
      initOrgVars $ORG
      writeIntermediateCA
   done
}

# Write a service to setup the fabric artifacts (e.g. genesis block, etc)
function writeSetupFabric {
   echo "  setup:
    container_name: setup
    image: hyperledger/fabric-ca
    command: /bin/bash -c '/scripts/setup-fabric.sh 2>&1 | tee /$SETUP_LOGFILE; sleep 99999'
    environment:
      - TZ=$CONTAINER_TZ
    volumes:
      - ./scripts:/scripts
      - ./$DATA:/$DATA
      - ./fabric-ca-client:/etc/hyperledger/fabric-ca-client
      - /usr/share/zoneinfo/$CONTAINER_TZ:/etc/localtime:ro
    networks:
      - $NETWORK"
   echo ""
}

# Write services for fabric orderer and peer containers
function writeOrderfabric {
   for ORG in $ORDERER_ORGS; do
      COUNT=1
      while [[ "$COUNT" -le $NUM_ORDERERS ]]; do
         initOrdererVars $ORG $COUNT
         {
         writeHeader
         writeOrderer
         } > $SDIR/docker-compose-$ORDERER_NAME.yml
         log "Created docker-compose-$ORDERER_NAME.yml"
         COUNT=$((COUNT+1))
      done
   done
}

function writePeerfabric {
   current=1
   for ORG in $PEER_ORGS; do
      COUNT=1
      PORT1=`expr $current \* 10`
      PORT2=`expr 7054 + $PORT1`
      current=`expr $current + 1`
      while [[ "$COUNT" -le $NUM_PEERS ]]; do
         initPeerVars $ORG $COUNT
         {
         writeHeader
         writePeer
         }> $SDIR/docker-compose-$PEER_NAME.yml
         log "Created docker-compose-$PEER_NAME.yml"
         COUNT=$((COUNT+1))
      done
   done
}

# Write a service to run a fabric test including creating a channel,
# installing chaincode, invoking and querying
function writeRunFabric {
   # Set samples directory relative to this script
   SAMPLES_DIR=$(dirname $(cd ${SDIR} && pwd))
   # Set fabric directory relative to GOPATH
   FABRIC_DIR=${GOPATH}/src/github.com/hyperledger/fabric
   echo "  run:
    container_name: run
    image: hyperledger/fabric-tools
    environment:
      - GOPATH=/opt/gopath
      - TZ=$CONTAINER_TZ
    command: /bin/bash -c 'sleep 3;/scripts/run-fabric.sh 2>&1 | tee /$RUN_LOGFILE; sleep 99999'
    volumes:
      - ./scripts:/scripts
      - ./$DATA:/$DATA
      - ${SAMPLES_DIR}:/opt/gopath/src/github.com/hyperledger/fabric-samples
      - ${FABRIC_DIR}:/opt/gopath/src/github.com/hyperledger/fabric
      - ./fabric-ca-client:/etc/hyperledger/fabric-ca-client
      - /usr/share/zoneinfo/$CONTAINER_TZ:/etc/localtime:ro
    networks:
      - $NETWORK
"
}

# Write services for fabric cli containers
# installing chaincode, invoking and querying
function writeCliFabric {
   echo "  cli:
    container_name: cli
    image: hyperledger/fabric-tools
    environment:
      - GOPATH=/opt/gopath
      - TZ=$CONTAINER_TZ
    tty: true
    volumes:
      - ./scripts:/scripts
      - ./$DATA:/$DATA
      - ./chaincode/go/:/opt/gopath/src/github.com/hyperledger/fabric/examples/chaincode/go
      - ./fabric-ca-client:/etc/hyperledger/fabric-ca-client
      - /usr/share/zoneinfo/$CONTAINER_TZ:/etc/localtime:ro
    networks:
      - $NETWORK
"
}

function writeRootCA {
   local FABRIC_CA_DB=$(echo rca$ORG | tr '[0-9]' '[a-j]')
   if [ $ORG = "org0" ];then
       local depends_on=""
   else
       i=${ORG##org}
       local depends_on=rca.org$((i - 1))$DOMAIN
   fi

   echo "  $ROOT_CA_NAME:
    container_name: $ROOT_CA_NAME
    image: hyperledger/fabric-ca
    tty: true
    command: /bin/sh
    environment:
      - FABRIC_CA_SERVER_HOME=/etc/hyperledger/fabric-ca
      - FABRIC_CA_SERVER_TLS_ENABLED=true
      - FABRIC_CA_SERVER_CSR_CN=$ROOT_CA_NAME
      - FABRIC_CA_SERVER_CSR_HOSTS=$ROOT_CA_HOST
      - FABRIC_CA_SERVER_DEBUG=true
      - BOOTSTRAP_USER_PASS=$ROOT_CA_ADMIN_USER_PASS
      - TARGET_CERTFILE=$ROOT_CA_CERTFILE
      - FABRIC_ORGS="$ORGS"
      - FABRIC_CA_MYSQL="${FABRIC_CA_MYSQL}"
      - FABRIC_CA_MYSQL_URI="${MYSQL_URI}/${FABRIC_CA_DB}?parseTime=true"
      - DOCKER_CONTAINER=$ROOT_CA_NAME
      - TZ=$CONTAINER_TZ
    volumes:
      - ./scripts:/scripts
      - ./$DATA:/$DATA
      - ./fabric-ca-client:/etc/hyperledger/fabric-ca-client
      - /usr/share/zoneinfo/$CONTAINER_TZ:/etc/localtime:ro
    networks:
      - $NETWORK
    ports:
      - $1:7054"
    if [ ! -z "$depends_on" ];then
        echo "    depends_on:
      - $depends_on"
    fi
    echo ""
}

function writeIntermediateCA {
   echo "  $INT_CA_NAME:
    container_name: $INT_CA_NAME
    image: hyperledger/fabric-ca
    command: /bin/bash -c '/scripts/start-intermediate-ca.sh $ORG 2>&1 | tee /$INT_CA_LOGFILE'
    environment:
      - FABRIC_CA_SERVER_HOME=/etc/hyperledger/fabric-ca
      - FABRIC_CA_SERVER_CA_NAME=$INT_CA_NAME
      - FABRIC_CA_SERVER_INTERMEDIATE_TLS_CERTFILES=$ROOT_CA_CERTFILE
      - FABRIC_CA_SERVER_CSR_HOSTS=$INT_CA_HOST
      - FABRIC_CA_SERVER_TLS_ENABLED=true
      - FABRIC_CA_SERVER_DEBUG=true
      - BOOTSTRAP_USER_PASS=$INT_CA_ADMIN_USER_PASS
      - PARENT_URL=https://$ROOT_CA_ADMIN_USER_PASS@$ROOT_CA_HOST:7054
      - TARGET_CHAINFILE=$INT_CA_CHAINFILE
      - ORG=$ORG
      - FABRIC_ORGS="$ORGS"
      - TZ=$CONTAINER_TZ
    volumes:
      - ./scripts:/scripts
      - ./$DATA:/$DATA
      - ./fabric-ca-client:/etc/hyperledger/fabric-ca-client
      - /usr/share/zoneinfo/$CONTAINER_TZ:/etc/localtime:ro
    networks:
      - $NETWORK
    depends_on:
      - $ROOT_CA_NAME
"
}

function writeOrderer {
   MYHOME=/etc/hyperledger/orderer
   echo "  $ORDERER_NAME:
    container_name: $ORDERER_NAME
    image: hyperledger/fabric-orderer
    environment:
      - FABRIC_CA_CLIENT_HOME=$MYHOME
      - FABRIC_CA_CLIENT_TLS_CERTFILES=$CA_CHAINFILE
      - ENROLLMENT_URL=https://$ORDERER_NAME_PASS@$CA_HOST:7054
      - ORDERER_HOME=$MYHOME
      - ORDERER_HOST=$ORDERER_HOST
      - ORDERER_GENERAL_LISTENADDRESS=0.0.0.0
      - ORDERER_GENERAL_GENESISMETHOD=file
      - ORDERER_GENERAL_GENESISFILE=$GENESIS_BLOCK_FILE
      - ORDERER_GENERAL_LOCALMSPID=$ORG_MSP_ID
      - ORDERER_GENERAL_LOCALMSPDIR=$MYHOME/msp
      - ORDERER_GENERAL_TLS_ENABLED=true
      - ORDERER_GENERAL_TLS_PRIVATEKEY=$MYHOME/tls/server.key
      - ORDERER_GENERAL_TLS_CERTIFICATE=$MYHOME/tls/server.crt
      - ORDERER_GENERAL_TLS_ROOTCAS=[$CA_CHAINFILE]
      - ORDERER_GENERAL_TLS_CLIENTAUTHREQUIRED=true
      - ORDERER_GENERAL_TLS_CLIENTROOTCAS=[$CA_CHAINFILE]
      - ORDERER_GENERAL_LOGLEVEL=debug
      - ORDERER_DEBUG_BROADCASTTRACEDIR=$LOGDIR
      - ORG=$ORG
      - ORG_ADMIN_CERT=$ORG_ADMIN_CERT
      - DOCKER_CONTAINER=$ORDERER_NAME
      - ORDERER_KAFKA_RETRY_LONGINTERVAL=10s 
      - ORDERER_KAFKA_RETRY_LONGTOTAL=100s 
      - ORDERER_KAFKA_RETRY_SHORTINTERVAL=1s
      - ORDERER_KAFKA_RETRY_SHORTTOTAL=30s
      - ORDERER_KAFKA_VERBOSE=true
      - ORDERER_KAFKA_BROKERS=[kafka0:9092,kafka1:9092,kafka2:9092,kafka3:9092]
      - TZ=$CONTAINER_TZ
    tty: true
    command: /bin/sh
    volumes:
      - ./scripts:/scripts
      - ./$DATA:/$DATA
      - ./fabric-ca-client:/etc/hyperledger/fabric-ca-client
      - /usr/share/zoneinfo/$CONTAINER_TZ:/etc/localtime:ro
    networks:
      - $NETWORK
    ports:
      - 7050:7050
    extra_hosts:
      - \"$CA_HOST:$CA_IP\"
      - \"kafka0:10.47.177.225\"
      - \"kafka1:10.47.177.226\"
      - \"kafka2:10.47.177.227\"
      - \"kafka3:10.47.177.228\"
      - \"zookeeper0:10.47.177.228\"
      - \"zookeeper1:10.47.177.229\"
      - \"zookeeper2:10.47.177.230\"
"
}

function writePeer {
   MYHOME=/opt/gopath/src/github.com/hyperledger/fabric/peer
   echo "
  couchdb$COUNT.$ORG$DOMAIN:
    container_name: couchdb$COUNT.$ORG$DOMAIN
    image: hyperledger/fabric-couchdb
    # Comment/Uncomment the port mapping if you want to hide/expose the CouchDB service,
    # for example map it to utilize Fauxton User Interface in dev environments.
    volumes:
      - /usr/share/zoneinfo/$CONTAINER_TZ:/etc/localtime:ro
    environment:
      - TZ=$CONTAINER_TZ
    networks:
      - $NETWORK
    ports:
      - 5984:5984

  $PEER_NAME:
    container_name: $PEER_NAME
    image: hyperledger/fabric-peer
    environment:
      - FABRIC_CA_CLIENT_HOME=$MYHOME
      - FABRIC_CA_CLIENT_TLS_CERTFILES=$CA_CHAINFILE
      - ENROLLMENT_URL=https://$PEER_NAME_PASS@$CA_HOST:$PORT2
      - PEER_NAME=$PEER_NAME
      - PEER_HOME=$MYHOME
      - PEER_HOST=$PEER_HOST
      - PEER_NAME_PASS=$PEER_NAME_PASS
      - CORE_PEER_ID=$PEER_HOST
      - CORE_PEER_ADDRESS=$PEER_HOST:7051
      - CORE_PEER_LOCALMSPID=$ORG_MSP_ID
      - CORE_PEER_MSPCONFIGPATH=$MYHOME/msp
      - CORE_VM_ENDPOINT=unix:///host/var/run/docker.sock
      - CORE_VM_DOCKER_HOSTCONFIG_NETWORKMODE=net_${NETWORK}
      - CORE_LOGGING_LEVEL=DEBUG
      - CORE_PEER_TLS_ENABLED=true
      - CORE_PEER_TLS_CERT_FILE=$MYHOME/tls/server.crt
      - CORE_PEER_TLS_KEY_FILE=$MYHOME/tls/server.key
      - CORE_PEER_TLS_ROOTCERT_FILE=$CA_CHAINFILE
      - CORE_PEER_TLS_CLIENTAUTHREQUIRED=true
      - CORE_PEER_TLS_CLIENTROOTCAS_FILES=$CA_CHAINFILE
      - CORE_PEER_TLS_CLIENTCERT_FILE=/$DATA/tls/$PEER_NAME-client.crt
      - CORE_PEER_TLS_CLIENTKEY_FILE=/$DATA/tls/$PEER_NAME-client.key
      - CORE_PEER_GOSSIP_USELEADERELECTION=true
      - CORE_PEER_GOSSIP_ORGLEADER=false
      - CORE_PEER_GOSSIP_EXTERNALENDPOINT=$PEER_HOST:7051
      - CORE_PEER_GOSSIP_SKIPHANDSHAKE=true
      - ORG=$ORG
      - CORE_LEDGER_STATE_STATEDATABASE=CouchDB
      - CORE_LEDGER_STATE_COUCHDBCONFIG_COUCHDBADDRESS=couchdb$COUNT.$ORG$DOMAIN:5984
      - ORG_ADMIN_CERT=$ORG_ADMIN_CERT
      - DOCKER_CONTAINER=$PEER_NAME
      - TZ=$CONTAINER_TZ"
   if [ $NUM -gt 1 ]; then
      echo "      - CORE_PEER_GOSSIP_BOOTSTRAP=peer1-${ORG}:7051"
   fi
   echo "    working_dir: $MYHOME
    tty: true
    command: /bin/sh
    volumes:
      - ./scripts:/scripts
      - ./$DATA:/$DATA
      - /var/run:/host/var/run
      - ./fabric-ca-client:/etc/hyperledger/fabric-ca-client
      - /usr/share/zoneinfo/$CONTAINER_TZ:/etc/localtime:ro
    networks:
      - $NETWORK
    ports:
      - 7051:7051
      - 7052:7052
      - 7053:7053
    depends_on:
      - couchdb$COUNT.$ORG$DOMAIN
    extra_hosts:
      - \"$CA_HOST:$CA_IP\""
for LOCAL_ORG in $ORDERER_ORGS; do
      local COUNT=1
      while [[ "$COUNT" -le $NUM_ORDERERS ]]; do
         name="ORDERIP$COUNT"
         ca_ip=`sed "/^$name=/!d;s/.*=//" $SDIR/scripts/env.sh`
         echo "      - \"orderer$COUNT.$LOCAL_ORG$DOMAIN:$ca_ip\""
         COUNT=$((COUNT+1))
      done
done
echo ""
}

function writeHeader {
   echo "version: '2'

networks:
  $NETWORK:


services:
"
}

main
