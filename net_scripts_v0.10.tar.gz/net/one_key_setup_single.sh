#!/bin/bash

function usage()
{
    echo "Usage: $0 <start|clean> [FILE]"
    echo "    FILE: orderer or peer containers list"
}

function check_ret()
{
    ret=$1
    msg=$2

    if [ $ret -eq 0 ];then
        echo " ===================== $msg is successful ===================== "
    else
        echo " ===================== failure to $msg ===================== "
        exit
    fi
}

function start_ca()
{
    local max_number=$1
    docker-compose -f docker-compose-ca.yml up -d
    check_ret $? "start ca"
    ./docker-fabric-ca-init.sh $max_number
    docker-compose -f docker-compose-setup.yml up -d
    check_ret $? "start ca setup"
    while [ ! -f data/genesis.block ]; do sleep 1; done
}

function start_kafka()
{
    docker-compose -f docker-compose-kafka-single.yaml up -d
    check_ret $? "start kafka"
}

function start_orderer()
{
    for orderer in $orderer_list
    do
        docker-compose -f docker-compose-${orderer}.yml up -d
        check_ret $? "start ${orderer}"
        docker exec -d ${orderer} "/scripts/init_fabric-orderer.sh"
        check_ret $? "init ${orderer}"
    done
}

function start_peer()
{
    for peer in $peer_list
    do
        docker-compose -f docker-compose-${peer}.yml up -d
        check_ret $? "start ${peer}"
        docker exec -d ${peer} "/scripts/init_fabric-peer.sh"
        check_ret $? "init ${peer}"
    done
}

function start_cli()
{
    docker-compose -f docker-compose-cli.yml up -d
    check_ret $? "start cli"
}

function cp_vi_container()
{
    container="$1"
    
    if [ -f "/usr/lib/x86_64-linux-gnu/libgpm.so.2" ];then
        docker cp /usr/lib/x86_64-linux-gnu/libgpm.so.2 ${container}:/usr/lib/x86_64-linux-gnu/libgpm.so.2
    fi
    
    if [ -f /usr/lib/x86_64-linux-gnu/libpython3.5m.so.1.0 ];then
        docker cp /usr/lib/x86_64-linux-gnu/libpython3.5m.so.1.0 ${container}:/usr/lib/x86_64-linux-gnu/libpython3.5m.so.1.0
    fi
    
    if [ -f /usr/bin/vi ];then
        docker cp -L /usr/bin/vi ${container}:/usr/bin/vi
    fi
}

function start_all()
{
    start_ca $max_ca_org_number
    start_kafka
    start_orderer
    start_peer
    start_cli
    cp_vi_container cli
}

function clean_all()
{
    for peer in $peer_list
    do
        docker-compose -f docker-compose-${peer}.yml down
    done

    for orderer in $orderer_list
    do
        docker-compose -f docker-compose-${orderer}.yml down
    done

    docker-compose -f docker-compose-kafka-single.yaml down
    docker-compose -f docker-compose-setup.yml down
    docker-compose -f docker-compose-ca.yml down
    docker-compose -f docker-compose-cli.yml down
}


if [ ! -z "$1" -a "$1" = "-h" ];then
    usage
    exit
fi
if [ $# -eq 1 ];then
    cmd=$1
    list_file=""
elif [ $# -eq 2 ];then
    cmd=$1
    list_file=$2
else
    usage
    exit
fi

max_ca_org_number=`grep "container_name" docker-compose-ca.yml | tail -1 | cut -d"." -f 2 | sed 's/org//'`

if [ -z "$list_file" ];then
    orderer_list=`ls docker-compose-orderer*.yml | sed -e 's/docker-compose-//g' -e 's/.yml//g'` 
    peer_list=`ls docker-compose-peer*.yml | sed -e 's/docker-compose-//g' -e 's/.yml//g'`
else
    orderer_list=`grep "^orderer" "$list_file"`
    peer_list=`grep "^peer" "$list_file"`
fi

if [ $cmd = "start" ];then
    start_all
elif [ $cmd = "clean" ];then
    clean_all
else
    usage
    exit
fi

