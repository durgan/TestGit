#!/bin/bash

function usage()
{
    echo "Usage: $0 [FILE]"
    echo "    FILE: orderer or peer containers list"
}

function get_usable_port()
{
    port_mapping_default=$1
    port_mapping=$port_mapping_default

    yum_list=`ls *.yml`
    if [ -z "${yum_list}" ];then
        echo $port_mapping
        return
    fi

    exist_ports=`grep '\- [0-9]*:[0-9]*' *.yml | awk '{print $3}' | cut -d':' -f 1`

    while [ 1 ]
    do
        echo "$exist_ports" | grep "$port_mapping" > /dev/null
        if [ $? -eq 0 ];then
            port_mapping=`expr $port_mapping '+' 10`
        else
            echo $port_mapping
            return
        fi
        if [ $port_mapping -gt 65535 ];then
            echo "can't find port mapping for $port_mapping_default"
            exit
        fi
    done
}

function modify_port()
{
    yum_file=$1

    org_mappings=`grep '\- [0-9]*:[0-9]*' "${yum_file}"`

    echo "${org_mappings}" | while read org
    do
        port=`echo $org | awk '{print $2}' | cut -d':' -f2`
        mapping=`echo $org | awk '{print $2}' | cut -d':' -f1`
        new_mapping=`get_usable_port $mapping`
        new="- $new_mapping:$port"
        sed -i "s/$org/$new/g" "${yum_file}"
    done

}

if [ ! -z "$1" -a "$1" = "-h" ];then
    usage
    exit 
fi
if [ $# -eq 0 ];then
    list_file=""
elif [ $# -eq 1 ];then
    list_file=$1
else
    usage
    exit
fi

if [ -z "$list_file" ];then
    orderer_list=`ls docker-compose-orderer*.yml | sed -e 's/docker-compose-//g' -e 's/.yml//g'`
    peer_list=`ls docker-compose-peer*.yml | sed -e 's/docker-compose-//g' -e 's/.yml//g'`
else
    orderer_list=`grep "^orderer" "$list_file"`
    peer_list=`grep "^peer" "$list_file"`
fi

index=0
for orderer in $orderer_list
do
    ((index++))
    if [ $index -eq 1 ];then
       continue
    fi 
    echo "modify docker-compose-${orderer}.yml"
    modify_port docker-compose-${orderer}.yml
done

index=0
for peer in $peer_list
do
    ((index++))
    if [ $index -eq 1 ];then
       continue
    fi
    echo "modify docker-compose-${peer}.yml"
    modify_port docker-compose-${peer}.yml
done

