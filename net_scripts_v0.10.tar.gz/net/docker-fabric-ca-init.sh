#!/bin/bash

if [ $# -ne 1 ];then
    echo "Usage: $0 org_count"
    exit
fi

org_count=$1

for((i=0; i<=$org_count; i++))
do
    container=rca.org${i}.cnsuning.com   
    echo "init $container"
    docker exec -d $container /scripts/init_fabric-ca.sh
    if [ $? -eq 0 ];then
        echo "init $container successful"
    else
        echo "failed to init $container"
        echo "command: docker exec -d $container /scripts/init_fabric-ca.sh"
    fi
    sleep 3
done

