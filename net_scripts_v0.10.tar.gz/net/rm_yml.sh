#!/bin/bash

for((i=3;i<=10;i++))
do
    rm -f docker-compose-peer${i}.org*.cnsuning.com.yml
done

for((i=3;i<=100;i++))
do
    rm -f docker-compose-peer*.org${i}.cnsuning.com.yml
done
