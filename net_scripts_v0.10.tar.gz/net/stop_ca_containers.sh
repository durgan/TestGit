#!/bin/bash

if [ $# -ne 2 ];then
    echo "Usage: $0 <start org number> <end org number>"
    exit 1
fi

start_num=$1
end_num=$2

for((i=$start_num; i<=$end_num; i++))
do
    docker stop rca.org${i}.cnsuning.com
    if [ $? -ne 0 ];then
        echo "failed to stop rca.org${i}.cnsuning.com"
    fi
done
