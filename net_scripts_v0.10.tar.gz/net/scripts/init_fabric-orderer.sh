#!/bin/bash

mkdir -p /data/logs

/scripts/start-orderer.sh > /data/logs/init-${DOCKER_CONTAINER}.log 2>&1

