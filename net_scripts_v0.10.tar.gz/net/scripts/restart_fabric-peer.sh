#!/bin/bash

mkdir -p /data/logs

# Start the peer
env | grep CORE >> /data/logs/restart-${DOCKER_CONTAINER}.log 2>&1
peer node start >> /data/logs/restart-${DOCKER_CONTAINER}.log 2>&1

