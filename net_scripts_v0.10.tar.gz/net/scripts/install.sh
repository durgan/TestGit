#!/bin/bash

if [ $# -ne 4 ];then
    echo "Usage: $0 <channel name> <chaincode name> <org index> <peer index>"
    exit
fi

unset CORE_PEER_TLS_ROOTCERT_FILE
unset CORE_PEER_TLS_KEY_FILE
unset CORE_PEER_LOCALMSPID
unset CORE_VM_ENDPOINT
unset CORE_PEER_TLS_CERT_FILE
unset CORE_PEER_TLS_ENABLED
unset CORE_PEER_MSPCONFIGPATH
unset CORE_PEER_ID
unset CORE_LOGGING_LEVEL
unset CORE_PEER_ADDRESS

orderer_ca=/data/org0-ca-cert.pem
channel_name=$1
cc_name=$2
org_index=$3
peer_index=$4

export CORE_PEER_TLS_ENABLED=true
export CORE_LOGGING_LEVEL=DEBUG   #for debug

function check_ret()
{
    ret=$1
    msg=$2
    
    if [ $ret -eq 0 ];then
        echo " ===================== $msg on ${CORE_PEER_ADDRESS%%:*} is successful ===================== "
    else
        echo " ===================== failure to $msg on ${CORE_PEER_ADDRESS%%:*} ===================== "
        exit
    fi
}

function set_env()
{
    org=$1
    peer=$2
    export orgmsp=org${org}MSP

    export CORE_PEER_TLS_ROOTCERT_FILE=/data/org${org}-ca-cert.pem
    export CORE_PEER_LOCALMSPID=org${org}MSP
    export CORE_PEER_MSPCONFIGPATH=/data/orgs/org${org}/admin/msp
    export CORE_PEER_ADDRESS=peer${peer}.org${org}.cnsuning.com:7051

    env | grep CORE
}

function join_channel()
{
    peer channel join -b ./channel-${channel_name}/${channel_name}.block
    check_ret $? "join channel '${channel_name}'"
}

function update()
{
    peer channel update -o orderer1.org0.cnsuning.com:7050 -c ${channel_name} -f ./channel-${channel_name}/${orgmsp}anchors.tx --tls true --cafile ${orderer_ca}
    check_ret $? "update anchors for '${channel_name}'"
}

function install_chaincode()
{
    peer chaincode install -n ${cc_name} -v 1.0 -p github.com/hyperledger/fabric/examples/chaincode/go/chaincode_example02
    check_ret $? "install chaincode for '${channel_name}'"
}

function instantiate_chaincode()
{
    peer chaincode instantiate -o orderer1.org0.cnsuning.com:7050 --tls true --cafile ${orderer_ca} -C ${channel_name} -n ${cc_name} -v 1.0 -c '{"Args":["init","a","100","b","200"]}' -P "OR ('org1MSP.member','org2MSP.member','org3MSP.member','org4MSP.member','org5MSP.member','org6MSP.member','org7MSP.member','org8MSP.member','org9MSP.member','org10MSP.member')"
    check_ret $? "instantiate chaincode for '${channel_name}'"
}

function query_chaincode()
{
    peer chaincode query -C ${channel_name} -n ${cc_name} -c '{"Args":["query","a"]}'
    check_ret $? "query chaincode for '${channel_name}'"
}

function invoke_chaincode()
{
    peer chaincode invoke -o orderer1.org0.cnsuning.com:7050 --tls true --cafile ${orderer_ca} -C ${channel_name} -n ${cc_name} -c '{"Args":["invoke","a","b","10"]}'
    check_ret $? "invoke chaincode for '${channel_name}'"
}


set_env $org_index $peer_index
join_channel
sleep 5
install_chaincode
sleep 5 
query_chaincode

