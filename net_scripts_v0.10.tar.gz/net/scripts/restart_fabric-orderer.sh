#!/bin/bash

mkdir -p /data/logs

# Start the orderer
env | grep ORDERER >> /data/logs/restart-${DOCKER_CONTAINER}.log 2>&1
orderer >> /data/logs/restart-${DOCKER_CONTAINER}.log 2>&1
