#!/bin/bash

mkdir -p /data/logs

/scripts/start-peer.sh > /data/logs/init-${DOCKER_CONTAINER}.log 2>&1 

