#!/bin/bash

mkdir -p /data/logs

if [ "$FABRIC_CA_MYSQL" = "yes" ];then
    fabric-ca-server start --db.type "mysql" --db.datasource "$FABRIC_CA_MYSQL_URI" >> /data/logs/restart-${DOCKER_CONTAINER}.log 2>&1
else
    fabric-ca-server start >> /data/logs/restart-${DOCKER_CONTAINER}.log 2>&1
fi

