#!/bin/bash

unset CORE_PEER_TLS_ROOTCERT_FILE
unset CORE_PEER_TLS_KEY_FILE
unset CORE_PEER_LOCALMSPID
unset CORE_VM_ENDPOINT
unset CORE_PEER_TLS_CERT_FILE
unset CORE_PEER_TLS_ENABLED
unset CORE_PEER_MSPCONFIGPATH
unset CORE_PEER_ID
unset CORE_LOGGING_LEVEL
unset CORE_PEER_ADDRESS

orderer_ca=/data/org0-ca-cert.pem

function check_ret()
{
    ret=$1
    msg=$2
    
    if [ $ret -eq 0 ];then
        echo " ===================== $msg on ${CORE_PEER_ADDRESS%%:*} is successful ===================== "
    else
        echo " ===================== failure to $msg on ${CORE_PEER_ADDRESS%%:*} ===================== "
        return
    fi
}

function set_env()
{
    if [ ! -z "$1" -a "$1" = "-h" ];then
        echo "Usage: set_env <org number> <peer number>"
        return
    fi
    if [ $# -eq 2 ];then
        local org=$1
        local peer=$2
    else
        echo "Usage: set_env <org number> <peer number>"
        return
    fi

    export orgmsp=org${org}MSP

    export CORE_PEER_TLS_ENABLED=true
    export CORE_LOGGING_LEVEL=DEBUG   #for debug
    export CORE_PEER_TLS_ROOTCERT_FILE=/data/org${org}-ca-cert.pem
    export CORE_PEER_LOCALMSPID=org${org}MSP
    export CORE_PEER_MSPCONFIGPATH=/data/orgs/org${org}/admin/msp
    export CORE_PEER_ADDRESS=peer${peer}.org${org}.cnsuning.com:7051

    env | grep CORE
}

function create_channel()
{
    if [ ! -z "$1" -a "$1" = "-h" ];then
        echo "Usage: create_channel <channel name> <org count>"
        return
    fi
    if [ $# -eq 2 ];then
        local channel_name=$1
        local org_count=$2
    else
        echo "Usage: create_channel <channel name> <org count>"
        return
    fi

    export FABRIC_CFG_PATH=/data

    mkdir ./channel-${channel_name}
    ./configtxgen -profile OrgsChannel -outputCreateChannelTx ./channel-${channel_name}/channel.tx -channelID $channel_name

    for ((i=1; i<=$org_count; i++))
    do
        ./configtxgen -profile OrgsChannel -outputAnchorPeersUpdate ./channel-${channel_name}/org${i}MSPanchors.tx -channelID $channel_name -asOrg org${i}
    done
    export FABRIC_CFG_PATH=/etc/hyperledger/fabric
set -x
    peer channel create -o orderer1.org0.cnsuning.com:7050 -c ${channel_name} -f ./channel-${channel_name}/channel.tx --tls true --cafile ${orderer_ca}
set +x
    check_ret $? "create channel '${channel_name}'"
    mv ${channel_name}.block ./channel-${channel_name}/
}

function join_channel()
{
    if [ ! -z "$1" -a "$1" = "-h" ];then
        echo "Usage: join_channel <channel name>"
        return
    fi
    if [ $# -eq 1 ];then
        local channel_name=$1
    else
        echo "Usage: join_channel <channel name>"
        return
    fi

set -x
    peer channel join -b ./channel-${channel_name}/${channel_name}.block
set +x
    check_ret $? "join channel '${channel_name}'"
}

function update_anchor()
{
    if [ ! -z "$1" -a "$1" = "-h" ];then
        echo "Usage: update_anchor <channel name>"
        return
    fi
    if [ $# -eq 1 ];then
        local channel_name=$1
    else
        echo "Usage: update_anchor <channel name>"
        return
    fi

set -x
    peer channel update -o orderer1.org0.cnsuning.com:7050 -c ${channel_name} -f ./channel-${channel_name}/${orgmsp}anchors.tx --tls true --cafile ${orderer_ca}
set +x
    check_ret $? "update anchors for '${channel_name}'"
}

function install_chaincode()
{
    if [ ! -z "$1" -a "$1" = "-h" ];then
        echo "Usage: install_chaincode <chaincode name> [path [version]]"
        return
    fi
    if [ $# -eq 1 ];then
        local cc_name=$1
        local path=github.com/hyperledger/fabric/examples/chaincode/go/chaincode_example02
        local version=1.0
    elif [ $# -eq 2 ];then
        local cc_name=$1
        local path=$2
        local version=1.0
    elif [ $# -eq 3 ];then
        local cc_name=$1
        local path=$2
        local version=$3
    else
        echo "Usage: install_chaincode <chaincode name> [path [version]]"
        return
    fi

set -x
    peer chaincode install -n ${cc_name} -v $version -p $path
set +x
    check_ret $? "install chaincode"
}

function instantiate_chaincode()
{
    if [ ! -z "$1" -a "$1" = "-h" ];then
        echo "Usage: instantiate_chaincode <channel name> <chaincode name> [version]"
        return
    fi
    if [ $# -eq 2 ];then
        local channel_name=$1
        local cc_name=$2
        local version=1.0
    elif [ $# -eq 3 ];then
        local channel_name=$1
        local cc_name=$2
        local version=$3
    else
        echo "Usage: instantiate_chaincode <channel name> <chaincode name> [version]"
        return
    fi

set -x
    peer chaincode instantiate -o orderer1.org0.cnsuning.com:7050 --tls true --cafile ${orderer_ca} -C ${channel_name} -n ${cc_name} -v $version -c '{"Args":["init","a","100","b","200"]}' -P "OR ('org1MSP.member','org2MSP.member','org3MSP.member','org4MSP.member','org5MSP.member','org6MSP.member','org7MSP.member','org8MSP.member','org9MSP.member','org10MSP.member')"
set +x
    check_ret $? "instantiate chaincode for '${channel_name}'"
}

function query_chaincode()
{
    if [ ! -z "$1" -a "$1" = "-h" ];then
        echo "Usage: query_chaincode <channel name> <chaincode name>"
        return
    fi
    if [ $# -eq 2 ];then
        local channel_name=$1
        local cc_name=$2
    else
        echo "Usage: query_chaincode <channel name> <chaincode name>"
        return
    fi

set -x
    peer chaincode query -C ${channel_name} -n ${cc_name} -c '{"Args":["query","a"]}'
set +x
    check_ret $? "query chaincode for '${channel_name}'"
}

function invoke_chaincode()
{
    if [ ! -z "$1" -a "$1" = "-h" ];then
        echo "Usage: invoke_chaincode <channel name> <chaincode name>"
        return
    fi
    if [ $# -eq 2 ];then
        local channel_name=$1
        local cc_name=$2
    else
        echo "Usage: invoke_chaincode <channel name> <chaincode name>"
        return
    fi

set -x
    peer chaincode invoke -o orderer1.org0.cnsuning.com:7050 --tls true --cafile ${orderer_ca} -C ${channel_name} -n ${cc_name} -c '{"Args":["invoke","a","b","10"]}'
set +x
    check_ret $? "invoke chaincode for '${channel_name}'"
}

function list_channel()
{
set -x
    peer channel list
set +x
}
