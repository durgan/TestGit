#!/bin/bash

if [ $# -eq 1 ];then
    channel_name=$1
else
    channel_name=my_channel
fi

cd $(dirname "$0")
tx_dir="`pwd`/data"

echo "channel_name=[$channel_name]"
echo "tx_dir=[$tx_dir]"

export FABRIC_CFG_PATH=./data
./configtxgen -profile TwoOrgsChannel -outputCreateChannelTx ./data/"${channel_name}".tx -channelID "${channel_name}"
