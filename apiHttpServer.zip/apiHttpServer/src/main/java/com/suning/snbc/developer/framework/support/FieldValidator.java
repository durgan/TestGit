package com.suning.snbc.developer.framework.support;


import java.util.regex.Pattern;

/**
 * @author 17031596@cnsuning.com
 */
public class FieldValidator {
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9\\u4e00-\\u9fa5]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$");
    private FieldValidator() {
    }

    public static FieldValidator build() {
        return new FieldValidator();
    }

    public FieldValidator required(String field, Object value) {
        if (value == null)
            throw new FieldInvalidException(field, "%s不能为空");
        return this;
    }
    public FieldValidator required(String field, Object value, String errorMessage) {
        if (value == null)
            throw new FieldInvalidException(field, errorMessage);
        return this;
    }

    public FieldValidator notEmpty(String field, String value) {
        if (value == null || value.length() == 0)
            throw new FieldInvalidException(field, "%s不能为空");
        return this;
    }

    public FieldValidator equals(String field, Object v1, Object v2, String errorMessage) {
        if (v1 == null) {
            if (v2 != null)
                throw new FieldInvalidException(field, errorMessage);
        } else if (!v1.equals(v2))
            throw new FieldInvalidException(field, errorMessage);
        return this;
    }

    public FieldValidator email(String field,String value){
        if(value == null || value.length() == 0)return this;
        if(EMAIL_PATTERN.matcher(value).matches())return this;
        throw new FieldInvalidException(field, "%s不是正确的邮箱地址");
    }


}
