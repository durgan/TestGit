package com.suning.snbc.developer.portal.entity;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@Accessors(chain = true)
@TableName("user")
public class SysUser {
    private static final long serialVersionUID = -1L;
    @TableId(value = "id",type = IdType.AUTO)
    private Long id;
    @NotBlank
    private String userName;
    private String roleType;
    private Integer roleLevel;
    @NotBlank
    private String email;
    private String password;
    @TableField("gmt_create")
    private Date createTime;
    @TableField("gmt_last_login")
    private Date lastLoginTime;

    private List<String> roles;
}
