package com.suning.snbc.developer.portal.sdk;

import org.hyperledger.fabric.sdk.Peer.PeerEventingServiceDisconnectEvent;
import org.hyperledger.fabric.sdk.Peer.PeerEventingServiceDisconnected;

public class APIPeerEventingServiceDisconnected implements PeerEventingServiceDisconnected{

	@Override
	public void disconnected(PeerEventingServiceDisconnectEvent event) {
		long reconnectCount = event.getReconnectCount();
		
	}

}
