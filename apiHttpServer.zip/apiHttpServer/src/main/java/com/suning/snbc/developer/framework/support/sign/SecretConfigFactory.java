package com.suning.snbc.developer.framework.support.sign;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;

import com.suning.snbc.sdk.FabricConfig;
import com.suning.snbc.sdk.FabricConfigFactory;
import com.suning.snbc.sdk.FabricOrg;

public class SecretConfigFactory {

	SecretConfig secretConfig;
	private String baseDir;

	private final static String configPath = "fabric";
	private final static String configFileName = "keysecret.ini";
	public final static String secretFileName = "publicKey.keystore";
	private static final String BLOCK = "";
	private static final String LEFT_SQUARE_BRACKET = "[";
	private static final String RIGHT_SQUARE_BRACKET = "]";
	private static final String EQUAL_SIGN = "=";
	private static final String KEY_SECRET = "keysecret";
	private static final String PUBLIC_SECRET = "publicsecret";

	public SecretConfigFactory setBaseDir(String baseDir) {
		this.baseDir = baseDir;
		return this;
	}

	public String getBaseDir() {
		return baseDir;
	}

	/**
	 * 获取存储的配置对象
	 * 
	 * @return
	 * @throws IOException
	 */
	public SecretConfig getSecretConfig() throws IOException {
		if (secretConfig == null) {
			secretConfig = generateStoredValue();
		}

		return secretConfig;
	}

	/**
	 * 更新key和secret映射
	 * @param key
	 * @param secret
	 * @return
	 * @throws IOException
	 */
	public SecretConfig updateKeySecret(String key, String secret) throws IOException {
		initBaseDir();
		System.out.println(baseDir + configFileName);
		writeCfgValue(baseDir + configFileName,KEY_SECRET,key,secret);
		return refreshStoredValue();
	}

	/**
	 * 根据配置文件刷新存储的配置对象
	 * 
	 * @return
	 * @throws IOException
	 */
	public SecretConfig refreshStoredValue() throws IOException {
		secretConfig = generateStoredValue();
		return secretConfig;
	}

	private SecretConfig generateStoredValue() throws IOException {
		if(secretConfig==null){
			secretConfig = new SecretConfig();
		}
		
		HashMap<String, String> keySecretMap = new HashMap<String, String>();
		initBaseDir();
		FileReader fileReader = new FileReader(baseDir + configFileName);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String s;
		String configType = BLOCK;
		while ((s = bufferedReader.readLine()) != null) {
			if (s.startsWith(LEFT_SQUARE_BRACKET)) {
				configType = s.replace(LEFT_SQUARE_BRACKET, BLOCK).replace(RIGHT_SQUARE_BRACKET, BLOCK).trim();
			} else if (s.length() > 0) {
				String[] keyValue = s.split(EQUAL_SIGN);
				String key = keyValue[0].trim();
				String value = keyValue[1].trim();
				if (KEY_SECRET.equalsIgnoreCase(configType)) {
					// 1adeb6002-0a77-4bb2-a89b-e285f2ff41ec =
					// ccd8a87e2744c3004d19989a8c16c4f6c3b5aa60
					keySecretMap.put(key, value);

				} else if (PUBLIC_SECRET.equalsIgnoreCase(configType)) {
					// publicsecret = ccd8a87e2744c3004d19989a8c16c4f6c3b5aa60
					secretConfig.setPublicSecret(value);
				}

				secretConfig.setKeySecretMap(keySecretMap);
			}
		}
		return secretConfig;
	}

	private void initBaseDir() {
		if (baseDir == null) {
			baseDir = Thread.currentThread().getContextClassLoader().getResource(configPath + "/" + configFileName)
					.getPath();
			baseDir = baseDir.replace(configFileName, "");
		}
		if (!baseDir.endsWith(String.valueOf(File.separatorChar))) {
			baseDir += String.valueOf(File.separatorChar);
		}
	}

	
	/**
     * 修改ini配置文件中变量的值
     *
     * @param file     配置文件的路径
     * @param section  要修改的变量所在段名称
     * @param variable 要修改的变量名称
     * @param value    变量的新值
     * @throws IOException 抛出文件操作可能出现的io异常
     */
    public static boolean writeCfgValue(String file, String section, String variable, String value) throws IOException {
        String fileContent, allLine, strLine, newLine, remarkStr = "";
        String getValue = null;
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
        boolean isInSection = false;
        boolean canAdd = true;
        fileContent = "";
        try {

            while ((allLine = bufferedReader.readLine()) != null) {
                allLine = allLine.trim();
                strLine = allLine.split(";")[0];
                Pattern p;
                Matcher m;
                p = Pattern.compile("\\[\\w+]");
                m = p.matcher((strLine));
                if (m.matches()) {
                    p = Pattern.compile("\\[" + section + "\\]");
                    m = p.matcher(strLine);
                    if (m.matches()) {
                        isInSection = true;
                    } else {
                        isInSection = false;
                    }
                }
                if (isInSection == true) {
                    strLine = strLine.trim();
                    String[] strArray = strLine.split("=");
                    getValue = strArray[0].trim();
                    if (getValue.equalsIgnoreCase(variable)) {
                        newLine = getValue + "=" + value;
                        fileContent += newLine;
                        while ((allLine = bufferedReader.readLine()) != null) {
                            fileContent += "\r\n" + allLine;
                        }
                        bufferedReader.close();
                        canAdd = false;
                        System.out.println(fileContent);
                        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, false));
                        bufferedWriter.write(fileContent);
                        bufferedWriter.flush();
                        bufferedWriter.close();

                        return true;
                    }

                }
                fileContent += allLine + "\r\n";
            }
            if (canAdd) {
                String str = variable + "=" + value;
                fileContent += str + "\r\n";
                System.out.println(fileContent);
                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, false));
                bufferedWriter.write(fileContent);
                bufferedWriter.flush();
                bufferedWriter.close();
            }
        } catch (IOException ex) {
            throw ex;
        } finally {
            bufferedReader.close();
        }
        return false;
    }

}
