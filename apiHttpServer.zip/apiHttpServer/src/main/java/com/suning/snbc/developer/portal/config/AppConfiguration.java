package com.suning.snbc.developer.portal.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author 17031596@cnsuning.com
 */
@Component
@Getter
@Setter
public class AppConfiguration {


    @Value("${fabric.org.id}")
    private String fabricOrgId;

//    @Value("${spring.session.kickout}")
    private boolean sessionKickout;
}
