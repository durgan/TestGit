package com.suning.snbc.developer.framework.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author 17031596@cnsuning.com
 */
@Data
@Accessors(chain = true)
public class BaseResponse {

    public static final BaseResponse SUCCESS = new BaseResponse(){
        @Override
        public BaseResponse setSuccess(int success) {
            throw new UnsupportedOperationException("can't set");
        }

        @Override
        public BaseResponse setMessage(String message) {
            throw new UnsupportedOperationException("can't set");
        }
    };
    public static final BaseResponse ERROR = new BaseResponse(){

        @Override
        public BaseResponse setSuccess(int success) {
            throw new UnsupportedOperationException("can't set");
        }

        @Override
        public BaseResponse setMessage(String message) {
            throw new UnsupportedOperationException("can't set");
        }

        @Override
        public int getSuccess() {
            return 0;
        }

        @Override
        public String getMessage() {
            return "系统错误";
        }
    };

    private int success = 1;
    @JsonProperty("errorMessage")
    private String message ;
    private Integer errorCode ;
    private Object result;

    @JsonProperty("developerMessage")
    private String developerMessage;
	@JsonProperty("requestId")
    private String requestId;
	@JsonProperty("moreInfo")
    private String moreInfo;
	private static String FAQ_DOC = "faq.com/";
	
    public BaseResponse() {
    }

    public BaseResponse(int errorCode, String message) {
        success  = 0;
        this.errorCode = errorCode;
        this.message = message;
    }

    public BaseResponse(int errorCode, String message,String developerMessage,String requestId) {
        success  = 0;
        this.errorCode = errorCode;
        this.message = message;
        this.developerMessage = developerMessage;
        this.requestId = requestId;
        this.moreInfo = FAQ_DOC+errorCode;
    }
    
    public BaseResponse(String message) {
        success  = 0;
        this.message = message;
    }

    public BaseResponse(Object result) {
        this.result = result;
    }
}
