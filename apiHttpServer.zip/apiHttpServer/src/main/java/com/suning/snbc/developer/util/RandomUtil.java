package com.suning.snbc.developer.util;


/**
 * 随机数生成工具类
 * 
 * @author 88399344 shengdong
 * @date 2018-05-14 20:10
 */
public class RandomUtil {
	
	//获取指定位数的随机字符串
	public static String getRandomString(int length) {
	    //随机字符串的随机字符库
	    String KeyString = "abcdefghijklmnopqrstuvwxyz0123456789";
	    StringBuffer sb = new StringBuffer();
	    int len = KeyString.length();
	    for (int i = 0; i < length; i++) {
	       sb.append(KeyString.charAt((int) Math.round(Math.random() * (len - 1))));
	    }
	    return sb.toString();
	}
	
	

}
