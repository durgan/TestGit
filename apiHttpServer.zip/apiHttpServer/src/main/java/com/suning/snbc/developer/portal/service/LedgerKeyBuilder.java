package com.suning.snbc.developer.portal.service;

public final class LedgerKeyBuilder {
    private static String ORG_KEY = "ORG:INFO:%s";
    private static String ORG_FIRST_KEY = "ORG:FIRST";
    private static String ORG_INVITE_KEY = "ORG:INVITE:%s";

    public static String orgKey(String orgId){
        return String.format(ORG_KEY,orgId);
    }
    public static String firstOrgKey(){
        return ORG_FIRST_KEY;
    }

    public static String orgInviteKey(String token){
        return String.format(ORG_INVITE_KEY,token);
    }
}
