package com.suning.snbc.developer.support;

public class DataNotFoundException extends RuntimeException {
}
