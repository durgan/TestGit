package com.suning.snbc.developer.portal.shiro;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Base64;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSONObject;
import com.suning.snbc.developer.framework.support.JsonRequest;
import com.suning.snbc.developer.support.BusinessException;
import com.suning.snbc.developer.util.AESUtil;

@Aspect
@Component
public class EnableRoleAspect {

	@Pointcut("execution (* com.suning.snbc.developer.portal.controller..*.*(..))")
	public void controllerAspect() {

	}

	@Around("controllerAspect()")
	public Object Interceptor(ProceedingJoinPoint pjp) throws Throwable {
		// 取自定义注解
		Method method = ((MethodSignature) pjp.getSignature()).getMethod();
		Method realMethod = pjp.getTarget().getClass().getDeclaredMethod(pjp.getSignature().getName(),
				method.getParameterTypes());
		Annotation an = method.getAnnotation(enableRole.class);
		String action = "";
		if (an instanceof enableRole) {
			enableRole myAnno = (enableRole) an;
			action = myAnno.roles();
			System.out.println("value: " + action);
		}

		Object result = null;
		if (action.equals("")) {
			result = pjp.proceed();
		} else {
			// ServletRequestAttributes attributes = (ServletRequestAttributes)
			// RequestContextHolder.getRequestAttributes();
			// HttpServletRequest request = attributes.getRequest();
			// Map<String, String[]> paramMap = request.getParameterMap();
			Object[] args = pjp.getArgs();
			System.out.println(JSONObject.toJSONString(args[0]));
			JsonRequest paramMap = (JsonRequest) args[0];
			if (!paramMap.hasKey("token")) {
				throw new BusinessException("没有token");
			}
			String token = paramMap.getString("token");
			System.out.println("token" + token);

			// 根据token判断权限
			byte[] aesKey = AESUtil.initKey();
			byte[] decryptResult = null;
			try {
				decryptResult = AESUtil.decrypt(Base64.getDecoder().decode(token), aesKey);
			} catch (Exception e) {
				throw new BusinessException("解码错误，请核实token是否输入正确!");
			}

			String role = new String(decryptResult);

			String[] requiredRoles = action.split(",");
			boolean haRule = false;
			for (String r : requiredRoles) {
				if (role.equals(r)) {
					haRule = true;
					break;
				}
			}
			if (haRule) {
				result = pjp.proceed();
			} else {
				throw new BusinessException(role + "没有权限访问接口!");
			}
			// Object[] args = pjp.getArgs();

		}

		return result;
	}
}
