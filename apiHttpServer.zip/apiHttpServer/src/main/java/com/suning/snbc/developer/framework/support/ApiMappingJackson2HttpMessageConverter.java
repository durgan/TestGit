package com.suning.snbc.developer.framework.support;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import java.io.IOException;
import java.lang.reflect.Type;

/**
 * @author 17031596@cnsuning.com
 */
public class ApiMappingJackson2HttpMessageConverter extends MappingJackson2HttpMessageConverter {

    public ApiMappingJackson2HttpMessageConverter(ObjectMapper objectMapper) {
        super(objectMapper);
    }

    @Override
    protected void writeInternal(Object object, Type type, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
        Object writable = object;
        if(writable instanceof BaseResponse)
            writable = object;
        else
            writable = new BaseResponse(object);
        super.writeInternal(writable, type, outputMessage);
    }
}
