package com.suning.snbc.developer.util;

import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;

//import org.apache.derby.jdbc.EmbeddedDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

/**
 * 
* Description: Derby工具类
* Title: DerbyUtil.java
* @author 88399341 - jiang
* @date 2018-11-02 17:27
 */
public class DerbyUtil {
    private static Logger logger = LoggerFactory.getLogger(DerbyUtil.class);

//	db存储位置
//	private static String dbLocation = "D:/derbydb/api2DB";
	private static String dbLocation = "/usr/local/apiDB";
	
	private static String initTable = "fcnInvokeCountTable";
	
	Connection conn = null;
	
	//使用静态块加载驱动程序
	     static{
	         try {
	        	 Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
	         } catch (ClassNotFoundException e) {
	        	 logger.error(e.getMessage());
	             e.printStackTrace();
	         } catch (InstantiationException e) {
	        	 logger.error(e.getMessage());
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				logger.error(e.getMessage());
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	 URL[] urls=sun.misc.Launcher.getBootstrapClassPath().getURLs();
	           for (int i = 0; i < urls.length; i++) {
	        	   logger.error(urls[i].toExternalForm());
	           }
	           
//	           测试extension classloader 的类加载路径，先打印一个路径，再打印出其parent，然后再打印出类加载路径中的所有jar包
	           logger.error("-------------------------------------");
	           logger.error(System.getProperty("java.ext.dirs"));
	           ClassLoader extensionClassloader=ClassLoader.getSystemClassLoader().getParent();
	           logger.error("the parent of extension classloader : "+extensionClassloader.getParent());
	           logger.error("extension classloader can use thess jars:");
	           URL[] extURLs = ((URLClassLoader)ClassLoader.getSystemClassLoader().getParent()).getURLs();
	           for (int i = 0; i < extURLs.length; i++) {
	        	   logger.error(extURLs[i].getPath());
	           }        
	           
	         
	     }
	     
	       public static Connection getConnection(){
	           Connection conn = null;
	           Properties props = new Properties();
				props.put("durgan", "durgan");
				logger.error("开始获取连接");
	           try {	
	               conn = DriverManager.getConnection("jdbc:derby:"+dbLocation+";create=true", props);
	           } catch (SQLException e) {
	               e.printStackTrace();
	               logger.error(e.getMessage());
	               logger.error("获取连接失败");
	           }
	           logger.error("结束获取连接");
	           return conn;
	       }

	       
	public static void close(ResultSet rs,Statement stat,Connection conn){
             try {
                 if(rs!=null)rs.close();
                 if(stat!=null)stat.close();
                 if(conn!=null)conn.close();
             } catch (SQLException e) {
                 e.printStackTrace();
             }
     }
	       
	       /**
	        * 查询操作
	        * @param sql
	        * @param resultValueNum 查询字段数量
	        * @return
	        * @throws SQLException
	        */
	       public static Map execuQuery(String sql,int resultValueNum) throws SQLException{
	    	   Connection coon = getConnection();
	    	   Statement s = coon.createStatement();
	    	   ResultSet rs = s.executeQuery(sql);
	    	   Map<Integer,Map<Integer,Object>> result = new HashMap<Integer,Map<Integer,Object>>();
	    	   int count = 0;
				while (rs.next()) {
					Map<Integer,Object> content = new HashMap<Integer,Object>();
					for(int i=1;i<=resultValueNum;i++){
						content.put(i, rs.getObject(i));
					}
					
					result.put(count, content);
					count++;
				}
				close(rs,s,coon);
				return result;
	       }
	       
	       public static boolean execu(String sql) throws SQLException{
	    	   Connection coon = getConnection();
	    	   Statement s = coon.createStatement();
	    	   s.execute(sql);
	    	   coon.commit();
	    	   close(null,s,coon);
	    	   return true;
	       }
	       
	       /**
	        * 校验table是否存在
	        * @param tableName
	        * @return
	        * @throws SQLException
	        */
	       public static boolean checkTableExist(String tableName) throws SQLException{
	    	   DatabaseMetaData meta = getConnection().getMetaData();
				ResultSet res = meta.getTables(null, null, null, new String[]{"TABLE"});
				HashSet<String> set=new HashSet<String>();
				while (res.next()) {
					set.add(res.getString("TABLE_NAME"));
				}
				
				if(set.contains(tableName.toUpperCase()))
					return true;
				return false;
	       }
	       
	       /**
	        * 创建初始表
	        * @return
	        * @throws SQLException
	        */
	       public static boolean initTable() throws SQLException{
	    	   if(!checkTableExist(initTable)){
	    		   DerbyUtil.execu("create table fcnInvokeCountTable(id int,channelname varchar(40),chaincodename varchar(40),fcnname varchar(40), count int)");
	    	   }
	    	   return true;
	       }
	       
	       
	       
	       public static void main(String[] args) throws SQLException {
//	    	   System.setProperty("derby.system.home","D:/derbydb/");
	    	   

//	    	   DerbyUtil.execu("create table fcnInvokeCountTable(id int,channelname varchar(40),chaincodename varchar(40),fcnname varchar(40), count int)");
//	    	   DerbyUtil.execu("insert into fcnInvokeCountTable(channelname,chaincodename,fcnname,count) values('jchannel', 'jchaincode2','jfcn',19)");
//	    	   DerbyUtil.execu("update fcnInvokeCountTable set count = 100 where channelname='jchannel' and chaincodename='jchaincode'");

//	    	   Map result = DerbyUtil.execuQuery("SELECT count FROM fcnInvokeCountTable where channelname='jchannel' and chaincodename='jchaincode'", 1);
//	    	   Map result = DerbyUtil.execuQuery("SELECT chaincodename,fcnname,count FROM fcnInvokeCountTable where channelname='jchannel' OFFSET 0 ROWS FETCH NEXT 5 ROWS ONLY", 3);
//
//	    	   System.out.println(JSONObject.toJSONString(result));
	    	   
//	    	   initTable();
	           URL[] urls=sun.misc.Launcher.getBootstrapClassPath().getURLs();
	           for (int i = 0; i < urls.length; i++) {
	        	   logger.error(urls[i].toExternalForm());
	           }
	           
//	           测试extension classloader 的类加载路径，先打印一个路径，再打印出其parent，然后再打印出类加载路径中的所有jar包
	           logger.error("-------------------------------------");
	           logger.error(System.getProperty("java.ext.dirs"));
	           ClassLoader extensionClassloader=ClassLoader.getSystemClassLoader().getParent();
	           logger.error("the parent of extension classloader : "+extensionClassloader.getParent());
	           logger.error("extension classloader can use thess jars:");
	           URL[] extURLs = ((URLClassLoader)ClassLoader.getSystemClassLoader().getParent()).getURLs();
	           for (int i = 0; i < extURLs.length; i++) {
	        	   logger.error(extURLs[i].getPath());
	           }        
	           
//	         测试system classloader 的类加载路径，其实也就时classpath的路径，并打印出它的parent
	           logger.error("-------------------------------------");
	           logger.error(System.getProperty("java.class.path"));
	           logger.error(ClassLoader.getSystemResource("").getPath());
	           ClassLoader systemClassloader=ClassLoader.getSystemClassLoader();
	           logger.error("the parent of system classloader : "+systemClassloader.getParent());
	           logger.error("end");
	    	   
		}
}
