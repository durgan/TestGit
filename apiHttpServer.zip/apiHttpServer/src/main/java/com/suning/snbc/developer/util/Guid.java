package com.suning.snbc.developer.util;

import java.util.Date;
import java.util.UUID;

import org.apache.commons.codec.digest.DigestUtils;

/**
 * 
* Description: 生成appkey appsecret
* Title: Guid.java
* @author 88399341 - jiang
* @date 2018-09-28 14:52
 */
public class Guid {
	
	public static final String ARG_ROLEMARK_BAAS = "0";
    public static final String ARG_ROLEMARK_CLIENT = "1";
	
	public String Guid(){
		UUID uuid = UUID.randomUUID();
		String key = uuid.toString();
		return key;
	}
	
	public String getBassAppKey(){
		Guid g = new Guid();
		String guid = g.Guid();
		return ARG_ROLEMARK_BAAS+guid;
	}
	
	public String getClientAppKey(){
		Guid g = new Guid();
		String guid = g.Guid();
		return ARG_ROLEMARK_CLIENT+guid;
	}
	
	public String getAppSecret(String app_key){
		String mw = "durgan"+app_key+new Date().getTime();
		String app_sign =DigestUtils.sha1Hex(mw.getBytes());
//		String app_sign = MD5Util.toMD5String(mw).toUpperCase();
		return app_sign;
	}
	
	public static void main(String[] args){
		Guid gd = new Guid();
		String appKey = gd.getClientAppKey();
		System.out.println(appKey);
		
		String appSecret = gd.getAppSecret(appKey);
		System.out.println(appSecret);
	}
	
	
}
