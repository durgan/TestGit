package com.suning.snbc.developer.framework.support;


import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.suning.snbc.developer.support.Helper;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Huzl
 * @version 1.0.0
 */
public class JsonRequest {
    private Map<String,Object>  map = new HashMap<>();
    private FieldValidator fieldValidator = FieldValidator.build();
    public Map<String, Object> getMap() {
        return map;
    }

    public String getOptString(String name){
        return getString(name,null);
    }

    public Integer getInteger(String name,Integer min,Integer max){
        return Helper.validInteger(getInteger(name),min,max);
    }

    public String getString(String name){
        String val = map.get(name).toString();
        fieldValidator.notEmpty(name,val);
        return val;
    }
    public Integer getInteger(String name){
        String val = getString(name);
        return Integer.valueOf(val);
    }
    public String getString(String name,String defaultValue){
        String val = map.get(name).toString();
        return StringUtils.isEmpty(val)?defaultValue:val;
    }
    
    public Integer getOptInteger(String name){
        String val = map.get(name).toString();
        return StringUtils.isEmpty(val)?null:Integer.valueOf(val);
    }
    
    public Integer getInteger(String name,Integer defaultValue){
        String val = map.get(name).toString();
        return StringUtils.isEmpty(val)?defaultValue:Integer.valueOf(val);
    }

    public Long getOptLong(String name){
        String val = map.get(name).toString();
        return StringUtils.isEmpty(val)?null:Long.valueOf(val);
    }
    
    public Long getLong(String name){
        String val = getString(name);
        return Long.valueOf(val);
    }
    
    public Long getLong(String name, Long defaultValue){
        String val = getString(name);
        return StringUtils.isEmpty(val)?defaultValue:Long.valueOf(val);
    }


    public Double getDouble(String name){
        String val = getString(name);
        return new Double(val);
    }
    
    public String[] getStringArray(String name){
    	ArrayList<String> val = (ArrayList<String>) map.get(name);
    	String[] strings = new String[val.size()];
    	return val.toArray(strings);
    }
    

    @JsonAnySetter
    public JsonRequest setProperty(String name,Object value) {
        map.put(name,value);
        return this;
    }
    
    public boolean hasKey(String key){
    	return map.containsKey(key);
    }

}
