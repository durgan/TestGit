package com.suning.snbc.developer.support;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
//import com.suning.snbc.developer.portal.dto.user.TestProductInfoVO;
//import com.suning.snbc.developer.util.HttpUtil;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;
public class FindQueryBuilder {
    private JSONObject selector = new JSONObject();
    private JSONArray sort = new JSONArray();
    private JSONObject sortJson = new JSONObject();
    private ArrayList<String> fields;
    private Integer current;
    private Integer size;

    public static FindQueryBuilder begin(String docType) {
        return new FindQueryBuilder().eq("docType", docType);
    }
    
    public static FindQueryBuilder begin() {
        return new FindQueryBuilder();
    }
    
    public static void main(String[] args) throws ClientProtocolException, IOException {
    	//自定义查询，转化args
		String query = FindQueryBuilder.begin()
                .eq("id", "id99")//.sort("deployTime", "desc")
                .build();
    	System.out.println(query);
    	
//    	TestProductInfoVO t = new TestProductInfoVO();
//    	t.setAssetPackageId("pid1");
//    	t.setDocType("pi");
//    	t.setId("id99");
//    	t.setProductFullName("t full name 1");
//    	t.setProductId("pid 1");
//    	t.setProductName("tpn 1");
//    	
//    	String ts = JSONObject.toJSONString(t);
//    	System.out.println(ts);
//    	
//    	JSONObject paramJson = new JSONObject();
//    	paramJson.put("channelName", "abs");
//    	paramJson.put("chaincodeName", "abs");
//    	paramJson.put("orgName", "org3");
//    	paramJson.put("fcn", "set");
//    	paramJson.put("args", new String[]{"j2",ts});
//    	String result = HttpUtil.doPost("http://localhost:8080/sdkHttpServer/sdk/chaincode/invoke", paramJson.toJSONString());
//    	System.out.println(result);
	}

    public String build() {
        JSONObject query = new JSONObject();
        query.put("selector", selector);
        if(sort!=null && sort.size()>0){
            query.put("sort", sort);
        }
        if (fields != null)
            query.put("fields", fields);
        if (current != null && size != null) {
            query.put("skip", current * size);
            query.put("limit", size);
        }
        return query.toJSONString();
    }

    public FindQueryBuilder eq(String field, Object value) {
        if (value != null)
            selector.put(field, value);
        return this;
    }

    public FindQueryBuilder sort(String field, Object value) {
        if (field!=null && value != null){
            sortJson.put(field, value);
            sort.add(sortJson);
        }
        return this;
    }

    public FindQueryBuilder field(String... fields) {
        if (fields == null || fields.length == 0)
            return this;
        if (this.fields == null)
            this.fields = new ArrayList<>();
        for (String field : fields) {
            this.fields.add(field);
        }
        return this;
    }
}
