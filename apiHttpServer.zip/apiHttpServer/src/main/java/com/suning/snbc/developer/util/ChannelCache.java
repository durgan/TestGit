package com.suning.snbc.developer.util;

import com.suning.snbc.developer.framework.support.MemoryCache;
import com.suning.snbc.developer.portal.Constants;
import com.suning.snbc.sdk.ChannelClient;
import com.suning.snbc.sdk.ChannelClientFactory;
import com.suning.snbc.sdk.FabricConfig;
import com.suning.snbc.sdk.FabricOrg;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

@Component
public class ChannelCache {

    @Resource
    private FabricConfig fabricConfigInject;

    private static FabricConfig fabricConfig;

    @PostConstruct
    public void init() {
        this.fabricConfig = fabricConfigInject;
    }

    public static ChannelClient getTestClient(String channelName, String OrgName, String chaincodeName) {
        if (MemoryCache.cache().get(channelName + "-"+OrgName+"-"+chaincodeName) != null)
            return (ChannelClient) MemoryCache.cache().get(channelName + "-"+OrgName+"-"+chaincodeName);
        FabricConfig onePeerConfig = new FabricConfig();
        BeanUtils.copyProperties(fabricConfig, onePeerConfig);

        Map<String, FabricOrg> map = new HashMap<>();
        map.put(Constants.ORDEERORG, fabricConfig.getFabricOrg(Constants.ORDEERORG));
        map.put(OrgName, fabricConfig.getFabricOrg(OrgName));
        onePeerConfig.setOrgMap(map);

        ChannelClientFactory channelClientFactory = new ChannelClientFactory();
        channelClientFactory.setFabricConfig(onePeerConfig);
        ChannelClient channelClient = channelClientFactory.buildChannelClient(channelName, chaincodeName);
        MemoryCache.cache().put(channelName + "-"+OrgName+"-"+chaincodeName, channelClient);
        return channelClient;
    }
    
    

}
