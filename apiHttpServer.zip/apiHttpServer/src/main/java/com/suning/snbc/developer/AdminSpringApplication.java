package com.suning.snbc.developer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author 17031596@cnsuning.com
 */
//@EnableTransactionManagement
@SpringBootApplication(exclude={DataSourceAutoConfiguration.class,HibernateJpaAutoConfiguration.class,org.springframework.boot.autoconfigure.security.SecurityAutoConfiguration.class})
@ServletComponentScan("com.suning.snbc.developer.portal.web")
@Slf4j
public class AdminSpringApplication extends SpringBootServletInitializer {
    public static void main(String[] args) {
        log.debug("AdminSpringApplication startup main");
        SpringApplication application = new SpringApplication(AdminSpringApplication.class);
        application.setBannerMode(Banner.Mode.OFF);
        application.run(args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        log.debug("AdminSpringApplication startup ServletInitializer");
        // 注意这里要指向原先用main方法执行的Application启动类
        return builder.sources(AdminSpringApplication.class);
    }
}
