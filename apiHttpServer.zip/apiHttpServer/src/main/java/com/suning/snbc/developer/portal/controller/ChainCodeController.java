package com.suning.snbc.developer.portal.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hyperledger.fabric.sdk.ChaincodeEndorsementPolicy;
import org.hyperledger.fabric.sdk.ChaincodeID;
import org.hyperledger.fabric.sdk.exception.ChaincodeEndorsementPolicyParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.YamlMapFactoryBean;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import com.suning.snbc.developer.framework.support.JsonRequest;
import com.suning.snbc.developer.framework.support.sign.signRole;
import com.suning.snbc.developer.portal.sdk.APIChaincodeEndorsementPolicy;
import com.suning.snbc.developer.portal.service.SDKService;
import com.suning.snbc.developer.support.BusinessException;
import com.suning.snbc.developer.support.FindQueryBuilder;
import com.suning.snbc.developer.util.ChannelCache;
import com.suning.snbc.developer.util.FileUtil;
import com.suning.snbc.sdk.ChannelClient;
import com.suning.snbc.sdk.FabricConfig;
import com.suning.snbc.sdk.model.ResponseAndHash;

/**
 * 
 * Description:合约操作相关 Title: ChainCodeController.java
 * 
 * @author 88399341 - jiang
 * @date 2018-07-31 14:25
 */
@RestController
@RequestMapping("/sdk/chaincode")
public class ChainCodeController {

	private static final Log logger = LogFactory.getLog(ChainCodeController.class);

	private static final String TAGSPLITSTR = "chaincode";

	private static final String CUSTOM_QUERY = "customeQuery";

	@Value("${fabric.abs.channelName}")
	private String absChannelName;

	@Value("${fabric.abs.org}")
	private String absOrg;

	@Value("${fabric.abs.chaincodeName}")
	private String absChaincodeName;

	@Autowired
	private SDKService sdkService;

	@Autowired
	FabricConfig fabricConfig;

	@Autowired
	private ServletContext servletContext;

	private void testEndorsement(String[] orgArr) {
		Map load = new LinkedHashMap();
		int orgNum = orgArr.length;
		// Map roleMember = new LinkedHashMap();
		// roleMember.put("name", "member");
		// roleMember.put("mspId", "AidTechMSP");

		// Map roleAdmin = new LinkedHashMap();
		// roleAdmin.put("name", "admin");
		// roleAdmin.put("mspId", "AidTechMSP");

		// Map user1 = new LinkedHashMap();
		// user1.put("role", roleMember);
		// Map user2 = new LinkedHashMap();
		// user2.put("role", roleMember);
		Map identities = new LinkedHashMap();

		Map policyof = new LinkedHashMap();
		List policyList = new ArrayList();
		policyof.put("1-of", policyList);

		for (int i = 1; i <= orgNum; i++) {
			Map roleAdmin = new LinkedHashMap();
			roleAdmin.put("name", "admin");
			roleAdmin.put("mspId", orgArr[i - 1] + "MSP");

			Map admin = new LinkedHashMap();
			admin.put("role", roleAdmin);
			identities.put("admin" + i, admin);

			Map signedadmin = new LinkedHashMap();
			signedadmin.put("signed-by", "admin" + i);
			List of1List = new ArrayList();
			of1List.add(signedadmin);
			Map policy = new LinkedHashMap();
			policy.put("1-of", of1List);
			policyList.add(policy);
		}

		load.put("identities", identities);
		load.put("policy", policyof);

		// Map admin1 = new LinkedHashMap();
		// admin1.put("role", roleAdmin);
		// Map admin2 = new LinkedHashMap();
		// admin2.put("role", roleAdmin);
		//
		// Map identities = new LinkedHashMap();
		//// identities.put("user1", user1);
		// identities.put("admin1", admin1);
		//// identities.put("user2", user2);
		// identities.put("admin2", admin2);

		// Map signeduser1 = new LinkedHashMap();
		// signeduser1.put("signed-by", "user1");

		// Map signedadmin1 = new LinkedHashMap();
		// signedadmin1.put("signed-by", "admin1");
		//
		// List of1List = new ArrayList();
		//// of1List.add(signeduser1);
		// of1List.add(signedadmin1);
		//
		//// Map signeduser2 = new LinkedHashMap();
		//// signeduser2.put("signed-by", "user2");
		// Map signedadmin2 = new LinkedHashMap();
		// signedadmin2.put("signed-by", "admin2");
		// List of2List = new ArrayList();
		//// of2List.add(signeduser2);
		// of2List.add(signedadmin2);
		//
		// Map policy1 = new LinkedHashMap();
		// policy1.put("1-of", of1List);
		//
		// Map policy2 = new LinkedHashMap();
		// policy2.put("1-of", of2List);
		//
		//
		// policyList.add(policy1);
		// policyList.add(policy2);

		// load.put("identities", identities);
		// load.put("policy", policyof);
	}

	@RequestMapping("/tu")
	public String testUpload(@RequestBody JsonRequest request)
			throws ChaincodeEndorsementPolicyParseException, IOException {

		return "ok";
	}

	/**
	 * 部署合约
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/install")
	public Map<String, Object> install(@RequestBody JsonRequest request) throws Exception {
		Map<String, Object> result = new HashMap<String, Object>();
		String channelName = request.getString("channelName");
		// String orgName = fabricConfig.getOrgName();
		String orgName = request.getString("orgName");
		String chaincodeName = request.getString("chaincodeName");
		String fileData = request.getString("fileData");

		InputStream in = FileUtil.getUploadFileStream(fileData);
		Integer version = Integer.valueOf(1);
		if (request.hasKey("version")) {
			version = request.getInteger("version");
		}

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(chaincodeName).setVersion(version.toString())
				.setPath(TAGSPLITSTR).build();
		ChannelClient channelClient = ChannelCache.getTestClient(channelName, orgName, chaincodeName);
		boolean isOK = channelClient.deployChainCode(chaincodeID, in);
		if (!isOK) {
			// 具体原因待返回 TODO
			throw new BusinessException("初始化失败");
		}
		result.put("status", "success");
		return result;
	}

	/**
	 * 部署合约
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/absInstall")
	public Map<String, Object> absInstall(@RequestBody JsonRequest request) throws Exception {
		Map<String, Object> result = new HashMap<String, Object>();
		String channelName = absChannelName;
		String orgName = absOrg;
		String chaincodeName = request.getString("chaincodeName");
		String fileData = request.getString("fileData");

		InputStream in = FileUtil.getUploadFileStream(fileData);
		Integer version = Integer.valueOf(1);
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(chaincodeName).setVersion(version.toString())
				.setPath(TAGSPLITSTR).build();
		ChannelClient channelClient = ChannelCache.getTestClient(channelName, orgName, chaincodeName);
		boolean isOK = channelClient.deployChainCode(chaincodeID, in);
		if (!isOK) {
			// 具体原因待返回 TODO
			throw new BusinessException("初始化失败");
		}
		result.put("status", "success");
		return result;
	}

	/**
	 * 初始化合约
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/instantiate")
	public Map<String, Object> instantiate(@RequestBody JsonRequest request) throws IOException {
		Map<String, Object> result = new HashMap<String, Object>();
		String channelName = request.getString("channelName");
		// String orgName = fabricConfig.getOrgName();
		String orgName = request.getString("orgName");
		String chaincodeName = request.getString("chaincodeName");
		String[] args = request.getStringArray("args");
		String[] orgArr = request.getStringArray("orgArr");
		Integer version = request.getInteger("version");
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(chaincodeName).setVersion(version.toString())
				.setPath(TAGSPLITSTR).build();
		ChannelClient channelClient = ChannelCache.getTestClient(channelName, orgName, chaincodeName);
		Boolean response = channelClient.initChainCode(chaincodeID, args);
		logger.debug("init response: " + response);
		result.put("response", response);
		return result;
	}

	@RequestMapping("/absInstantiate")
	public Map<String, Object> absInstantiate(@RequestBody JsonRequest request) throws IOException {
		Map<String, Object> result = new HashMap<String, Object>();
		String channelName = absChannelName;
		String orgName = absOrg;
		String chaincodeName = request.getString("chaincodeName");
		String[] args = request.getStringArray("args");
		Integer version = request.getInteger("version");
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(chaincodeName).setVersion(version.toString())
				.setPath(TAGSPLITSTR).build();
		ChannelClient channelClient = ChannelCache.getTestClient(channelName, orgName, chaincodeName);
		Boolean response = channelClient.initChainCode(chaincodeID, args);
		logger.debug("init response: " + response);
		result.put("response", response);
		return result;
	}

	@RequestMapping("/invoke")
	public Map<String, Object> invoke(@RequestBody JsonRequest request) throws IOException {
		Map<String, Object> result = new HashMap<String, Object>();
		String channelName = request.getString("channelName");
		// String orgName = fabricConfig.getOrgName();
		String orgName = request.getString("orgName");
		String chaincodeName = request.getString("chaincodeName");
		String fcn = request.getString("fcn");
		String[] args = request.getStringArray("args");

		ChannelClient channelClient = ChannelCache.getTestClient(channelName, orgName, chaincodeName);

		// ResponseAndHash<String> response = channelClient.invoke(fcn, String.class,
		// args);
		String response = channelClient.invokeAsync(fcn, String.class, args);
		logger.debug("invoke response: " + response);
		result.put("response", response);
		//
		// 存储调用记录
		sdkService.storeInvokeCount(channelName, chaincodeName, fcn);

		return result;
	}

	@RequestMapping("/absInvoke")
	public Map<String, Object> absInvoke(@RequestBody JsonRequest request) throws IOException {

		Map<String, Object> result = new HashMap<String, Object>();
		String channelName = absChannelName;
		String orgName = absOrg;
		String chaincodeName = absChaincodeName;
		if (request.hasKey("chaincodeName")) {
			chaincodeName = request.getString("chaincodeName");
		}
		String fcn = request.getString("fcn");
		String[] args = request.getStringArray("args");

		ChannelClient channelClient = ChannelCache.getTestClient(channelName, orgName, chaincodeName);

		ResponseAndHash<String> response = channelClient.invoke(fcn, String.class, args);

		logger.debug("invoke response: " + response);
		result.put("response", response);

		return result;
	}

	/**
	 * 合约查询操作
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/query")
	// @signRole(roles="client,baas")
	public Map<String, Object> query(@RequestBody JsonRequest request) throws IOException {
		Map<String, Object> result = new HashMap<String, Object>();
		String channelName = request.getString("channelName");
		// String orgName = fabricConfig.getOrgName();
		String orgName = request.getString("orgName");

		String chaincodeName = request.getString("chaincodeName");
		String fcn = request.getString("fcn");
		String[] args = request.getStringArray("args");

		ChannelClient channelClient = ChannelCache.getTestClient(channelName, orgName, chaincodeName);

		String response = channelClient.query(fcn, String.class, args);
		logger.debug("query response: " + response);
		result.put("response", response);
		return result;
	}

	@RequestMapping("/absQuery")
	public Map<String, Object> absQuery(@RequestBody JsonRequest request) throws IOException {
		Map<String, Object> result = new HashMap<String, Object>();
		String channelName = absChannelName;
		String orgName = absOrg;
		String chaincodeName = absChaincodeName;
		if (request.hasKey("chaincodeName")) {
			chaincodeName = request.getString("chaincodeName");
		}
		String fcn = request.getString("fcn");
		String[] args = request.getStringArray("args");

		ChannelClient channelClient = ChannelCache.getTestClient(channelName, orgName, chaincodeName);

		String response = channelClient.query(fcn, String.class, args);
		logger.debug("query response: " + response);
		result.put("response", response);
		return result;
	}

	/**
	 * 合约更新
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/update")
	public Map<String, Object> update(@RequestBody JsonRequest request) throws IOException {
		Map<String, Object> result = new HashMap<String, Object>();
		String channelName = request.getString("channelName");
		// String orgName = fabricConfig.getOrgName();
		String orgName = request.getString("orgName");

		String chaincodeName = request.getString("chaincodeName");
		String[] args = request.getStringArray("args");
		Integer version = request.getInteger("version");
		String[] orgArr = request.getStringArray("orgArr");
		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(chaincodeName).setVersion(version.toString())
				.setPath(TAGSPLITSTR).build();
		ChannelClient channelClient = ChannelCache.getTestClient(channelName, orgName, chaincodeName);

		Boolean response = channelClient.updateChainCode(chaincodeID, args);
		logger.debug("query response: " + response);
		result.put("response", response);
		return result;
	}

	@RequestMapping("/absUpdate")
	public Map<String, Object> absUpdate(@RequestBody JsonRequest request) throws IOException {
		Map<String, Object> result = new HashMap<String, Object>();
		String channelName = absChannelName;
		String orgName = absOrg;
		String chaincodeName = request.getString("chaincodeName");
		String[] args = request.getStringArray("args");
		Integer version = request.getInteger("version");

		ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(chaincodeName).setVersion(version.toString())
				.setPath(TAGSPLITSTR).build();
		ChannelClient channelClient = ChannelCache.getTestClient(channelName, orgName, chaincodeName);

		Boolean response = channelClient.updateChainCode(chaincodeID, args);
		logger.debug("query response: " + response);
		result.put("response", response);
		return result;
	}

	/**
	 * 查询区块高度
	 */
	@RequestMapping("/queryBlockHeight")
	public Map<String, Object> queryBlockHeight(@RequestBody JsonRequest request) {
		Map<String, Object> result = new HashMap<String, Object>();
		String chaincodeName = absChaincodeName;
		if (request.hasKey("chaincodeName")) {
			chaincodeName = request.getString("chaincodeName");
		}
		String channelName = request.getString("channelName");
		String orgName = fabricConfig.getOrgName();
		ChannelClient channelClient = ChannelCache.getTestClient(channelName, orgName, chaincodeName);
		result.put("response", sdkService.queryBlockHeight(channelClient, channelName));
		return result;
	}
}
