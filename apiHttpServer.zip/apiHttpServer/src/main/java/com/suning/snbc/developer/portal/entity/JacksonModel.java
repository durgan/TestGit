package com.suning.snbc.developer.portal.entity;

import com.baomidou.mybatisplus.activerecord.Model;

import java.util.HashMap;
import java.util.Map;

public abstract class JacksonModel {
    private static final long serialVersionUID = 1L;
    protected Map<String,Object> attrs = new HashMap<>();

    @com.fasterxml.jackson.annotation.JsonAnyGetter
    public Map<String, Object> getAttrs() {
        return attrs;
    }

    public JacksonModel putAttr(String key,Object value){
        attrs.put(key,value);
        return this;
    }
}
