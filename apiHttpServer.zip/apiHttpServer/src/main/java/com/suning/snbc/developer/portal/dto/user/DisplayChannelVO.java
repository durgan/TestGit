package com.suning.snbc.developer.portal.dto.user;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
public class DisplayChannelVO {
    private String channelName;
    private String channelId;
    private String testChannelName;
    private String chainCodeName;
    private String testChainCodeName;
    private String chainCodeId;
    private String testChainCodeId;
    private int channelStatus;
    private int testChannelStatus;
    private int chainCodeStatus;
    private int orgNum;
    private String createDate;
    private Boolean feedbackStatus;
}
