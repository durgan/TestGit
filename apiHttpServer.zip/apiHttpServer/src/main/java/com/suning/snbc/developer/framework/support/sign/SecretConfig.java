package com.suning.snbc.developer.framework.support.sign;

import java.util.HashMap;

public class SecretConfig {

	private HashMap<String,String> keySecretMap;
	
	private String publicSecret;

	public HashMap<String, String> getKeySecretMap() {
		return keySecretMap;
	}

	public void setKeySecretMap(HashMap<String, String> keySecretMap) {
		this.keySecretMap = keySecretMap;
	}

	public String getPublicSecret() {
		return publicSecret;
	}

	public void setPublicSecret(String publicSecret) {
		this.publicSecret = publicSecret;
	}
	
	
}
