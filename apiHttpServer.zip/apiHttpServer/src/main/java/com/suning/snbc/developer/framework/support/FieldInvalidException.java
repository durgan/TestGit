package com.suning.snbc.developer.framework.support;


import lombok.Getter;

/**
 * @author Huzl
 * @version 1.0.0
 */
public class FieldInvalidException extends RuntimeException {
    @Getter
    private String field;
    @Getter
    private String errorMessage;

    public FieldInvalidException(String field, String errorMessage) {
        this.field = field;
        this.errorMessage = errorMessage;
    }
}
