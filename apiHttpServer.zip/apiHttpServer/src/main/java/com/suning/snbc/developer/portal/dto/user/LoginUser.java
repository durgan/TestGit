package com.suning.snbc.developer.portal.dto.user;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.experimental.Accessors;
import java.io.Serializable;

@Data
@Accessors(chain = true)
public class LoginUser implements Serializable{
    private static final long serialVersionUID = -1L;
    private String userName;
    @JsonIgnore
    private String roleType;
    private Integer roleLevel;
    private String email;
    private String registerTime;

    @JsonProperty
    public String getRole(){

        return roleLevel == null?roleType:roleType + "_" + roleLevel;
    }
}
