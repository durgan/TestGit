package com.suning.snbc.developer.portal;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @author 17031596@cnsuning.com
 */
public enum ResultCode {
    LOGON_UNAUTHENTICATED(100),LOGON_UNKNOWN_ACCOUNT(101),LOGON_UNAUTHORIZED(102),LOGON_REPEATED(103),
    FLOW_CONTROLL(403),
    SERVER_ERROR(500);
    private int value;
    ResultCode(int value) {
        this.value = value;
    }


    @JsonValue
    public int getValue() {
        return value;
    }
}
