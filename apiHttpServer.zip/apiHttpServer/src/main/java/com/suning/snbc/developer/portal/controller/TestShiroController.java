package com.suning.snbc.developer.portal.controller;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.suning.snbc.developer.framework.support.JsonRequest;
import com.suning.snbc.developer.framework.support.security.JwtTokenUtil;
import com.suning.snbc.developer.framework.support.security.JwtUser;
import com.suning.snbc.developer.framework.support.sign.signRole;
import com.suning.snbc.developer.framework.support.version.ApiVersion;
import com.suning.snbc.developer.portal.ResultCode;
//import com.suning.snbc.developer.portal.entity.SysUser;
import com.suning.snbc.developer.portal.shiro.enableRole;
import com.suning.snbc.developer.support.BusinessException;
import com.suning.snbc.developer.util.AESUtil;
import com.suning.snbc.developer.util.TarUtils;

import io.netty.handler.codec.http.HttpContentEncoder.Result;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/{version}/shiro")
@Slf4j
@ApiVersion(1)
public class TestShiroController {
	private static final String DATA = "admin";  
    private static final String TAG = "TAG";  
    
                    
//	@RequestMapping("/getToken")
//	public String getToken(String roleType) throws Exception{
//            /** 
//             * 密钥 
//             */  
//            byte[] aesKey = AESUtil.initKey();  
//            System.out.println(DATA + "AES key: " + aesKey);  
//            /** 
//             * 加密后的数据 
//             */  
//            byte[] encryptResult = AESUtil.encrypt(DATA.getBytes(), aesKey);  
//            System.out.println(DATA + "AES 加密: " + Base64.getEncoder().encodeToString(encryptResult));  
//            /** 
//             * 解密后的数据 
//             */  
//            byte[] decryptResult = AESUtil.decrypt(encryptResult, aesKey);  
//            System.out.println(DATA + "AES 解密: " + new String(decryptResult));  
//            
//            return Base64.getEncoder().encodeToString(encryptResult);
//	}
//	
//	@RequestMapping("/getRole")
//	public String role(@RequestParam("token") String token) throws Exception{
//		byte[] aesKey = AESUtil.initKey(); 
//		byte[] decryptResult = AESUtil.decrypt(Base64.getDecoder().decode(token), aesKey);  
//        System.out.println(DATA + "AES 解密: " + new String(decryptResult));
//		return new String(decryptResult);
//	}
//	
//	@enableRole(roles="admin1")
//	@RequestMapping("/login1")
//	public String testLogin(@RequestBody JsonRequest request){
////		Subject currentUser = SecurityUtils.getSubject();
////	    UsernamePasswordToken token = new UsernamePasswordToken("test", "sdfasdfewfewf");
////	    currentUser.login(token);
//	    return "ok";
//	}
//	
//	@enableRole(roles="admin")
//	@RequestMapping("/login")
//	public String testLogin1(@RequestBody JsonRequest request){
////		Subject currentUser = SecurityUtils.getSubject();
////	    UsernamePasswordToken token = new UsernamePasswordToken("durgan", "sdfasdfewfewf");
////	    currentUser.login(token);
//	    return "ok";
//	}
//	
//	@RequestMapping("/info")
////	 @HystrixCommand(
////	          fallbackMethod = "infoFallback"
////	          ,
////	          threadPoolProperties = {  //10个核心线程池,超过20个的队列外的请求被拒绝; 当一切都是正常的时候，线程池一般仅会有1到2个线程激活来提供服务
////	                  @HystrixProperty(name = "coreSize", value = "1"),
////	                  @HystrixProperty(name = "maxQueueSize", value = "2"),
////	                  @HystrixProperty(name = "queueSizeRejectionThreshold", value = "2")},
////	          commandProperties = {
////	                  @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "3000"), //命令执行超时时间
////	                  @HystrixProperty(name = "circuitBreaker.requestVolumeThreshold", value = "2"), //若干10s一个窗口内失败三次, 则达到触发熔断的最少请求量
////	                  @HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds", value = "30000") //断路30s后尝试执行, 默认为5s
////	  }
////	          )
//	@HystrixCommand(fallbackMethod = "infoFallback")
//	public String info(){
//		try {
//			Thread.sleep(4000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	    return "info";
//	}
//	
//	
//	@RequestMapping("/tv")
//	public String testVersion(){
//		return "v1";
//	}
	
    @RequestMapping("/gt")
    @ResponseBody
	public boolean gt(){
		return true;
	}
    
//    fff
    @RequestMapping("/gf")
    @ResponseBody
	public boolean gf(){
		return false;
	}
    
	@RequestMapping("/ex1")
	public String testEx1(){
		throw new BusinessException(ResultCode.FLOW_CONTROLL, "user msg", "dev msg", "22890012");
	}
	
	@RequestMapping("/ex2")
	public String testEx2(){
		throw new BusinessException("simple error");
	}
	
	 @RequestMapping("/ts")
	 @signRole(roles="client")
	public boolean ts(@RequestBody JsonRequest request){
		return true;
	}
//	
//	@Autowired
//	private JwtTokenUtil jwtTokenUtil;
//	@Autowired
//	private AuthenticationManager authenticationManager;
//	@Autowired
//	private UserDetailsService userDetailsService;
//	@RequestMapping("/token")
//	public String getToken(){
//		 UsernamePasswordAuthenticationToken upToken = new UsernamePasswordAuthenticationToken("durgan", "durgan");
//	        Authentication authentication = authenticationManager.authenticate(upToken);
//	        SecurityContextHolder.getContext().setAuthentication(authentication);
//	        return jwtTokenUtil.generateToken(userDetailsService.loadUserByUsername("durgan"));
//	}
//	
	@PreAuthorize("hasPermission('operate','1')")
//	@PreAuthorize("hasAuthority('sa')")
	@RequestMapping(value="/tkoken1",method = RequestMethod.POST)
	public String testToken1(@RequestBody JsonRequest request){
		 return "tk1";
	}
//	
//	@PreAuthorize("hasAuthority('sa')")
//	@RequestMapping("/tkoken2")
//	public String testToken2(HttpServletRequest request){
//		SecurityContextImpl securityContextImpl = (SecurityContextImpl) request
//				.getSession().getAttribute("SPRING_SECURITY_CONTEXT");
//		if(securityContextImpl!=null)
//				// 登录名
//				System.out.println("Username:"
//				+ securityContextImpl.getAuthentication().getName());
//				
//		 return "tk2";
//	}
//	
//	
//	@RequestMapping("/refreshtoken")
//	public String refreshToken(@RequestHeader String Authorization){
//		String token = Authorization.substring("Bearer ".length());
//        if (!jwtTokenUtil.isTokenExpired(token)) {
//            return jwtTokenUtil.refreshToken(token);
//        }
//        return "error";
//	}
//	
//	public String infoFallback(){
//	      log.error("===================== 执行降级策略");
//	      return "error";
//	  }
//	
//	@enableRole(roles="admin")
//	@RequestMapping("/auth")
//	public String oauth(){
//	    return "auth";
//	}
//	
//	public static void main(String[] args) throws Exception {
////		TarUtils.archive("E:\\tmp\\commonInfo\\src", "E:\\tmp\\common2.tar");
//		
////		InputStream is = new FileInputStream("E:\\tmp\\common2.tar");
////        BufferedInputStream bis = new BufferedInputStream(is,1024);
////        int len = 0;
////        byte[] buf = new byte[1024];
////
////        ByteArrayOutputStream bos = new ByteArrayOutputStream();
////        while((len = bis.read(buf))!=-1){
////            bos.write(buf, 0, len);
////        }
////        bis.close();
////        is.close();
////
////        //将图片写入json中
////        String data = com.sun.org.apache.xerces.internal.impl.dv.util.Base64.encode(bos.toByteArray());
////        System.out.println(data);
//		
//		getChainCodeBase("E:\\tmp\\commonInfo\\src", "E:\\tmp\\common01.tar");
//	}
//	
//	
//	/**
//	 * 获取合约base字符
//	 * @param chaicodeSrc 合约文件夹地址，该地址下包含chaincode文件夹，文件夹中包含go文件合约
//	 * @param tarName 临时tar包输出路径
//	 * @return
//	 * @throws Exception 
//	 */
//	public static String getChainCodeBase(String chaicodeSrc,String tarName) throws Exception{
//		TarUtils.archive(chaicodeSrc, tarName);
//		
//		InputStream is = new FileInputStream(tarName);
//        BufferedInputStream bis = new BufferedInputStream(is,1024);
//        int len = 0;
//        byte[] buf = new byte[1024];
//
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        while((len = bis.read(buf))!=-1){
//            bos.write(buf, 0, len);
//        }
//        bis.close();
//        is.close();
//
//        //将图片写入json中
//        String data = com.sun.org.apache.xerces.internal.impl.dv.util.Base64.encode(bos.toByteArray());
//        System.out.println(data);
//        return data;
//	}
	
	
}
