package com.suning.snbc.developer.framework.support;

import com.suning.snbc.developer.portal.ResultCode;
import com.suning.snbc.developer.support.BusinessException;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authz.UnauthenticatedException;
import org.apache.shiro.authz.UnauthorizedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.util.StringUtils;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import javax.servlet.http.HttpServletRequest;

/**
 * controller异常处理
 * @author 17031596@cnsuning.com
 */
@ControllerAdvice
@ResponseBody
public class ExceptionHandlerAdvice {
    private final Logger logger = LoggerFactory.getLogger(getClass());

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public BaseResponse handleException(HttpServletRequest request, MethodArgumentNotValidException e) {
        logger.error("Request exception {} {}",request.getRequestURI(),e.getMessage());
        String message ;
        FieldError fieldError = e.getBindingResult().getFieldError();
        if(fieldError != null)
            message = String.format("字段[%s]%s",fieldError.getField(),fieldError.getDefaultMessage());
        else
            message = "请求参数错误";
        return new BaseResponse(message);
    }

    @ExceptionHandler(Exception.class)
    public BaseResponse handleException(HttpServletRequest request, Exception e) {
        logger.error("Request exception {}",request.getRequestURI(),e);
        BaseResponse response = BaseResponse.ERROR;
        response.setDeveloperMessage(readDetailExMessage(e));
        return response;
    }
    
    
    private String readDetailExMessage(Exception e){
    	ByteArrayOutputStream out = new ByteArrayOutputStream();  
        PrintStream pout = new PrintStream(out);  
        e.printStackTrace(pout);  
        String ret = new String(out.toByteArray());  
        pout.close();  
        try {  
             out.close();  
        } catch (Exception ex) {  
        } 
        return ret;
    }
    

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public BaseResponse handleException(HttpServletRequest request, HttpMessageNotReadableException e) {
        logger.error("Request exception {}",request.getRequestURI());
        return new BaseResponse("请求报文格式错误，无法解析");
    }

    @ExceptionHandler(FieldInvalidException.class)
    public BaseResponse handleException(HttpServletRequest request, FieldInvalidException e) {
         String  message = String.format(e.getErrorMessage(),e.getField());
        return new BaseResponse(message);
    }

    @ExceptionHandler(BusinessException.class)
    public BaseResponse handleException(HttpServletRequest request, BusinessException e) {
    	if(StringUtils.isEmpty(e.getRequestId()))
    		return new BaseResponse(e.getResultCode().getValue(),e.getResultMessage());
        return new BaseResponse(e.getResultCode().getValue(),e.getResultMessage(),e.getDeveloperMessage(),e.getRequestId());
    }
    
//    @ExceptionHandler(BusinessException.class)
//    public ErrorResponse handleException(HttpServletRequest request, BusinessException e) {
//        return new ErrorResponse(e.getResultCode().getValue(),e.getResultMessage(),e.getDeveloperMessage(),e.getRequestId());
//    }

    @ExceptionHandler(UnknownAccountException.class)
    public BaseResponse handleException(HttpServletRequest request, UnknownAccountException e) {
        return new BaseResponse("用户名或密码错误");
    }

    @ExceptionHandler(UnauthorizedException.class)
    public BaseResponse handleException(HttpServletRequest request, UnauthorizedException e) {
        return new BaseResponse(ResultCode.LOGON_UNAUTHORIZED.getValue(),"您无权限访问");
    }

    @ExceptionHandler(AuthenticationException.class)
    public BaseResponse handleException(HttpServletRequest request, AuthenticationException e) {
        if(e.getCause() instanceof BusinessException)
            return handleException(request, (BusinessException) e.getCause());
        else
            return new BaseResponse("登录失败");
    }

    @ExceptionHandler(UnauthenticatedException.class)
    public BaseResponse handleException(HttpServletRequest request, UnauthenticatedException e) {
        return new BaseResponse(ResultCode.LOGON_UNAUTHENTICATED.getValue(),"您未登录或登录会话已失效,请重新登录");
    }
}
