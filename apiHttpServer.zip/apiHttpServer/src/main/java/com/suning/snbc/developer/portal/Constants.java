package com.suning.snbc.developer.portal;

public class Constants {
    public static final String SESSION_USER_INFO = "SESSION_USER_INFO";
    public static final String SESSION_IMAGE_CODE = "SESSION_IMAGE_CODE";
//    order组织 与peer中order org对应  AidTech
    public static final String ORDEERORG = "Org0";
    public static final String INVOKE = "invoke";
    public static final String QUERY = "query";
    public static final String UPDATE = "update";
    public static final String INIT = "init";

    public static final String MESSAGE_DEVELOPER_DEPLOY = "部署成功";

    public static final String MESSAGE_DEVELOPER_REFUSE= "测试不通过";
    
    
    public static final String ARG_SIGN = "sign";
    public static final String ARG_APPID = "appid";
    public static final String ARG_APPKEY = "appkey";
    public static final String ARG_SECRETKEY = "secretkey";
    public static final String ARG_TIMESTAMP = "timestamp";
    public static final String ARG_ROLEMARK_BAAS = "0";
    public static final String ARG_ROLEMARK_CLIENT = "1";
    public static final String ARG_ROLE_BAAS = "baas";
    public static final String ARG_ROLE_CLIENT = "client";
    //接口请求有效时间-分钟
    public static final int EXPTIME_MIN = 5;
    
}
