package com.suning.snbc.developer.framework.support.security;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

/**
 * 
 * Description: 自定义权限 Title: OperablePermissionEvaluator.java
 * 
 * @author 88399341 - jiang
 * @date 2018-08-23 11:27
 */
//@Component
//@Configuration
public class OperablePermissionEvaluator implements PermissionEvaluator {

	public boolean hasPermission(Authentication authentication,

			Object targetDomainObject, Object permission) {

		if ("operate".equals(targetDomainObject)) {

			return this.hasPermission(authentication, permission);

		}

		return false;

	}

	/**
	 * 简单的字符串比较，相同则认为有权限
	 * @param authentication
	 * @param permission
	 * @return
	 */
	private boolean hasPermission(Authentication authentication, Object permission) {

//		Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
//
//		for (GrantedAuthority authority : authorities) {
//
//			if (authority.getAuthority().equals(permission)) {
//
//				return true;
//
//			}
//
//		}

		JwtUser userDetails = (JwtUser) authentication.getPrincipal();
		List<String> operateIds = userDetails.getOperateIds();
		if(operateIds.contains(permission)){
			return true;
		}
			
		return false;

	}

	@Override
	public boolean hasPermission(Authentication authentication, Serializable targetId, String targetType,
			Object permission) {
		
		return false;
	}

}
