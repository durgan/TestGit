package com.suning.snbc.developer.framework.support;


import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author 17031596@cnsuning.com
 */
public class SimpleMap<K,V> implements Map<K,V> {
    private Map<K,V> delegation = new HashMap<K,V>();

    public SimpleMap() {
    }

    public SimpleMap(K key, V value) {
        put(key,value);
    }

    public SimpleMap(K key1, V value1, K key2, V value2) {
        put(key1,value1);
        put(key2,value2);
    }


    public SimpleMap(Map<K, V> delegation) {
        this.delegation = delegation;
    }

    @Override
    public int size() {
        return delegation.size();
    }

    @Override
    public boolean isEmpty() {
        return delegation.isEmpty();
    }

    @Override
    public boolean containsKey(Object key) {
        return delegation.containsKey(key);
    }

    @Override
    public boolean containsValue(Object value) {
        return delegation.containsValue(value);
    }

    @Override
    public V get(Object key) {
        return delegation.get(key);
    }

    @Override
    public V put(K key, V value) {
        return delegation.put(key,value);
    }

    public SimpleMap set(K key, V value) {
        delegation.put(key,value);
        return this;
    }

    @Override
    public V remove(Object key) {
        return delegation.remove(key);
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> m) {
        delegation.putAll(m);
    }

    @Override
    public void clear() {
        delegation.clear();
    }

    @Override
    public Set<K> keySet() {
        return delegation.keySet();
    }

    @Override
    public Collection<V> values() {
        return delegation.values();
    }

    @Override
    public Set<Entry<K, V>> entrySet() {
        return delegation.entrySet();
    }
}
