package com.suning.snbc.developer.framework.support.security;
import com.suning.snbc.developer.portal.entity.SysUser;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * 
* Description: 用户验证方法
* Title: JwtUserDetailsServiceImpl.java
* @author 88399341 - jiang
* @date 2018-08-22 17:14
 */
@Service
public class JwtUserDetailsServiceImpl implements UserDetailsService {

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		SysUser user = new SysUser().setRoles(new ArrayList<String>(){{
        	add("sa");
        }});
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String password = encoder.encode("durgan");
		JwtUser ju = new JwtUser("durgan", password, user.getRoles().stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList()));
		ju.setOperateIds(new ArrayList<String>(){{
			add("1");
		}});
		UserDetails userDetails = ju;
        
		return userDetails;
	}


}
