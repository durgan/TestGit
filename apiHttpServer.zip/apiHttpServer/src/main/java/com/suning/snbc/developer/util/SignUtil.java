package com.suning.snbc.developer.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;


/**
 * 
* Description: 对请求参数根据私钥签名
* Title: SignUtil.java
* @author 88399341 - jiang
* @date 2018-09-28 15:10
 */
public class SignUtil {

	/**
	 * 生成参数签名
	 * @param params 所传参数的map集合。如果有参数值为String数组，那么转化为|分割的字符串。如["a","1"]那么转为"a|1".
	 * @param privateKey
	 * @return
	 */
	public static String createSign(Map<String, String> params, String privateKey) {
		StringBuilder sb = new StringBuilder(); 
		// 将参数以参数名的字典升序排序
        Map<String, String> sortParams = new TreeMap<String, String>(params);
        // 遍历排序的字典,并拼接"key=value"格式
        for (Map.Entry<String, String> entry : sortParams.entrySet()) {
        	String key = entry.getKey();
        	String value =  entry.getValue().trim();
        	if (StringUtils.isNotEmpty(value))
        		sb.append("&").append(key).append("=").append(value);
        }
        String stringA = sb.toString().replaceFirst("&", "");
        String stringSignTemp = stringA + "&secretKey="+privateKey;
        String signValue = DigestUtils.sha1Hex(stringSignTemp.getBytes());
        return signValue;
	}
	
	public static void main(String[] args) {
		Map m = new HashMap<String,String>();
		m.put("channelName", "ja411");
		m.put("chaincodeName", "ja415");
		m.put("orgName", "AidTech");
		m.put("fcn", "queryByKey");
		m.put("args", "jzw1");
		m.put("timestamp", "1538207729898");
		m.put("appkey", "1adeb6002-0a77-4bb2-a89b-e285f2ff41ec");
		
		
		String sign = createSign(m,"ccd8a87e2744c3004d19989a8c16c4f6c3b5aa60");
		
		System.out.println(sign);
		
		System.out.println(new Date().getTime());
	}

}
