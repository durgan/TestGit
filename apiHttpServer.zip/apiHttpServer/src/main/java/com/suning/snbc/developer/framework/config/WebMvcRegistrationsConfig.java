package com.suning.snbc.developer.framework.config;

import org.springframework.boot.autoconfigure.web.WebMvcRegistrationsAdapter;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.suning.snbc.developer.framework.support.version.ApiRequestMappingHandlerMapping;

/**
 * 
* Description: 版本控制相关配置
* Title: WebMvcRegistrationsConfig.java
* @author 88399341 - jiang
* @date 2018-08-22 14:20
 */
@Configuration
public class WebMvcRegistrationsConfig extends WebMvcRegistrationsAdapter{

	@Override
    public RequestMappingHandlerMapping getRequestMappingHandlerMapping() {
        return new ApiRequestMappingHandlerMapping();
    }
}
