package com.suning.snbc.developer.framework.support;

import java.util.Date;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**  
 * 简单缓存
 * @author 15082179
 * @date 2016年4月27日 下午7:46:25 
 * @version 1.0 
 * @param <V>
*/
public class MemoryCache<K, V> {
	private long PERIOD_DAY = 12 * 60 * 60 * 1000l;
	private Lock lock = new ReentrantLock();
	private Map<K, V> cacheContainer = new ConcurrentHashMap<K, V>();
	private static MemoryCache<Object, Object> obj;
	
	private MemoryCache() {
		Timer timer = new Timer();
		timer.schedule(new IdelTime(), new Date(), PERIOD_DAY);
	}
	
	
	public synchronized static MemoryCache<Object, Object> cache() {
		if (obj == null) {
			obj = new MemoryCache<Object, Object>();
		}
		return obj;
	}

	public V get(K k) {
		lock.lock();
		try {
			V v = this.cacheContainer.get(k);
			return v;
		} finally {
			lock.unlock();
		}
	}

	public void put(K k, V v) {
		lock.lock();
		try {
			this.cacheContainer.put(k, v);
		} finally {
			lock.unlock();
		}
	}
	
	public void clean(){
		lock.lock();
		try {
			this.cacheContainer.clear();
		} finally {
			lock.unlock();
		}
	}
	
	class IdelTime extends TimerTask {
		
		@Override
		public void run() {
			lock.lock();
			try {
				cacheContainer.clear();
			} finally {
				lock.unlock();
			}
			
		}
		
	}

}
