package com.suning.snbc.developer.portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.suning.snbc.developer.framework.support.JsonRequest;
import com.suning.snbc.developer.portal.Constants;
import com.suning.snbc.developer.portal.service.SecretService;
/**
 * 
* Description: 系统设置相关的接口类
* Title: SystemController.java
* @author 88399341 - jiang
* @date 2018-11-02 14:36
 */
@RestController
@RequestMapping("/sdk/system")
public class SystemController {

	@Autowired
	SecretService secretService;
	/**
	 * 刷新secretkey
	 * @param request
	 * @return
	 */
	@RequestMapping("/refreshSecretKey")
    public boolean refreshSecretKey(@RequestBody JsonRequest request){
		String secretkey =  request.getString(Constants.ARG_SECRETKEY);
		String appkey =  request.getString(Constants.ARG_APPKEY);
		String sign =  request.getString(Constants.ARG_SIGN);
		return secretService.refreshSecret(appkey, secretkey, sign);
    }
}
