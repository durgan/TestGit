package com.suning.snbc.developer.portal.shiro;

import lombok.Setter;
import org.apache.shiro.authz.aop.AuthorizingAnnotationMethodInterceptor;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.spring.LifecycleBeanPostProcessor;
import org.apache.shiro.spring.security.interceptor.AopAllianceAnnotationsAuthorizingMethodInterceptor;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.session.ExpiringSession;
import org.springframework.session.web.http.SessionRepositoryFilter;
import org.springframework.web.filter.CompositeFilter;

import javax.annotation.Resource;
import javax.servlet.Filter;
import java.util.Arrays;
import java.util.List;

/**
 * @author 17031596@cnsuning.com
 */
//@Configuration
public class ShiroConfiguration {

//    @Bean
    public Filter sessionFilter(SecurityManager securityManager,SessionRepositoryFilter springSessionRepositoryFilter) throws Exception {
        System.out.println("springSessionRepositoryFilter = " + springSessionRepositoryFilter);
        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
        shiroFilterFactoryBean.setSecurityManager(securityManager);
        Filter shiroFilter = (Filter) shiroFilterFactoryBean.getObject();
        CompositeFilter compositeFilter = new CompositeFilter();
        compositeFilter.setFilters(Arrays.asList(springSessionRepositoryFilter,shiroFilter));
        return compositeFilter;
    }
    //*/

    /*@Bean(name="test")
    public String redis(RedisTemplate<String, String> redisTemplate){
        redisTemplate.opsForValue().set("aa","aa");
        System.out.println("redisTemplate = " + redisTemplate.opsForValue().get("aa"));

        return "aaa";
    }*/

    /**
     * 不指定名字的话，自动创建一个方法名第一个字母小写的bean
     */
    @Bean
    public SecurityManager securityManager() {
        DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
        securityManager.setRealm(userRealm());
        return securityManager;
    }

    /**
     * Shiro Realm 继承自AuthorizingRealm的自定义Realm,即指定Shiro验证用户登录的类为自定义的
     */
    @Bean
    public UserRealm userRealm() {
        return new UserRealm();
    }



    /**
     * Shiro生命周期处理器
     */
    @Bean
    public LifecycleBeanPostProcessor lifecycleBeanPostProcessor() {
        return new LifecycleBeanPostProcessor();
    }

    /**
     * 开启Shiro的注解(如@RequiresRoles,@RequiresPermissions),需借助SpringAOP扫描使用Shiro注解的类,并在必要时进行安全逻辑验证
     * 配置以下两个bean(DefaultAdvisorAutoProxyCreator(可选)和AuthorizationAttributeSourceAdvisor)即可实现此功能
     */
    @Bean
    @DependsOn({"lifecycleBeanPostProcessor"})
    public DefaultAdvisorAutoProxyCreator advisorAutoProxyCreator() {
        DefaultAdvisorAutoProxyCreator advisorAutoProxyCreator = new DefaultAdvisorAutoProxyCreator();
        advisorAutoProxyCreator.setProxyTargetClass(true);
        return advisorAutoProxyCreator;
    }

    /**
     *  shiro 认证和授权拦截处理，并加入同时登录剔除功能
     * @return Advisor
     */
    @Bean
    public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor() {
        AuthorizationAttributeSourceAdvisor advisor = new AuthorizationAttributeSourceAdvisor();
        AopAllianceAnnotationsAuthorizingMethodInterceptor advice =
                (AopAllianceAnnotationsAuthorizingMethodInterceptor) advisor.getAdvice();
        List<AuthorizingAnnotationMethodInterceptor> interceptors = (List<AuthorizingAnnotationMethodInterceptor>) advice.getMethodInterceptors();
        interceptors.add(0,new SessionKickOutMethodInterceptor());
        advisor.setSecurityManager(securityManager());
        return advisor;
    }
}
