package com.suning.snbc.developer.portal.dto.user;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
public class ChannelVO {

    public static final String DOC_TYPE = "CHANNEL";
    private String docType = "CHANNEL";

    private String id;

    private String channelName;

    private String resourcePath;

    private Date gmtCreate;

    private String chainCodeId;

    private Integer status;

}
