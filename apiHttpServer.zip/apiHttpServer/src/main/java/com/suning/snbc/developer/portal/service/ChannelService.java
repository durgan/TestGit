package com.suning.snbc.developer.portal.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.plugins.Page;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.suning.snbc.developer.portal.dto.user.BlockVO;
import com.suning.snbc.developer.portal.dto.user.TransatcionVO;
import com.suning.snbc.developer.support.BusinessException;
import com.suning.snbc.developer.support.FindQueryBuilder;
import com.suning.snbc.developer.util.ChannelCache;
import com.suning.snbc.sdk.ChannelClient;
import com.suning.snbc.sdk.ChannelClientCreatedFactory;
import com.suning.snbc.sdk.ChannelClientFactory;
import com.suning.snbc.sdk.ChannelClientJoinFactory;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.hyperledger.fabric.sdk.BlockInfo;
import org.hyperledger.fabric.sdk.BlockchainInfo;
import org.hyperledger.fabric.sdk.ChaincodeID;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.SDKUtils;
import org.hyperledger.fabric.sdk.BlockInfo.EnvelopeInfo;
import org.hyperledger.fabric.sdk.exception.CryptoException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author 14020107@cnsuning.com
 * Date 2018/4/24
 */
@Service
public class ChannelService {

    private static Logger logger = LoggerFactory.getLogger(ChannelService.class);
//
    @Resource
    private FabricBlockService fabricBlockService;
//
//    @Resource
//    private FabricChannelService fabricChannelService;
//
//    @Resource(name = "commonChannel")
//    private ChannelClient commonChannel;
//
//    @Resource(name = "channelClientCreatedFactory")
//    private ChannelClientCreatedFactory channelClientCreatedFactory;
//
//    @Resource(name = "channelClientJoinFactory")
//    private ChannelClientJoinFactory channelClientJoinFactory;
//
//    @Resource
//    private AppConfiguration appConfiguration;
//
//    @Resource
//    private OrganizationRepository organizationRepository;
//
//    @Resource
//    private ChainService chainService;
//
//    @Resource
//    private ChannelClientFactory channelClientFactory;
//
//
//    @Value("${fabric.org.id}")
//    private String orgId;

    //获取channel
    public Channel reConstructChannel(String channelName,String orgName){
    	ChannelClient channelClient = ChannelCache.getTestClient(channelName,orgName , "just chanel");
    	return channelClient.getChannel();
    }
    

    public Page<TransatcionVO> queryTransactionByPage(String channelName,String orgName, String transactionHash, int pageNum, int pageSize) {
    	
    	Channel channel =reConstructChannel(channelName, orgName);
        Page<TransatcionVO> result = new Page<>();
        try {
            List<TransatcionVO> trans = fabricBlockService.getTransactions(channel, transactionHash, 100);
            //Integer pages = (trans.size()+1)/pageSize;
            List<TransatcionVO> pageTrans = RAMPageService.page(trans, pageNum, pageSize);
            result.setTotal(trans.size());
            result.setRecords(pageTrans);
            return result;
        } catch (Exception e) {
            logger.error("queryTransactionByPage fail, because " + e);
            throw new BusinessException(e.getMessage());
        }
    }


    public Page<BlockVO> queryBlockByPage(String channelName,String orgName, String blockParam, int pageNum, int pageSize) {
        Channel channel = reConstructChannel(channelName, orgName);
        Page<BlockVO> result = new Page<>();
        try {
            List<BlockVO> trans = fabricBlockService.getBlocks(channel, blockParam, 100);
            //Integer pages = (trans.size()+1)/pageSize;
            List<BlockVO> pageBlocks = RAMPageService.page(trans, pageNum, pageSize);
            result.setTotal(trans.size());
            result.setRecords(pageBlocks);
            return result;
        } catch (Exception e) {
            logger.error("queryBlockByPage fail, because " + e);
            throw new BusinessException(e.getMessage());
        }
    }
//
    public Page<TransatcionVO> queryBlockTransactionByPage(String channelName, String orgName,long blockNum, int pageNum, int pageSize) {
        Channel channel = reConstructChannel(channelName, orgName);
        Page<TransatcionVO> result = new Page<>();
        try {
            List<TransatcionVO> trans = fabricBlockService.getTransactionsByBlockNum(channel, blockNum);
            // Integer pages = (trans.size()+1)/pageSize;
            List<TransatcionVO> pageTrans = RAMPageService.page(trans, pageNum, pageSize);
            result.setTotal(trans.size());
            result.setRecords(pageTrans);
            return result;
        } catch (Exception e) {
            logger.error("queryBlockTransactionByPage fail, because " + e);
            throw new BusinessException(e.getMessage());
        }
    }
//
//
//    public long queryBlockHeight(String channelName) {
//        Channel channel = fabricChannelService.getChannelByName(channelName, queryChaincodeName(channelName));
//        try {
//            long height = fabricBlockService.getCurrentBlockHeight(channel);
//            return height;
//        } catch (Exception e) {
//            logger.error("queryBlockHeight fail, because " + e);
//            return 0;
//        }
//    }
//
//    private String queryChaincodeName(String channelName) {
//        String query = FindQueryBuilder.begin(ChannelVO.DOC_TYPE).eq("channelName", channelName).build();
//        byte[] result = commonChannel.query("customeQuery", byte[].class, query);
//        ArrayNode jsonNodes = (ArrayNode) JsonUtils.toJsonNode(result);
//        ChannelVO channel = null;
//        String[] chainCodeId = null;
//        if (jsonNodes != null && jsonNodes.size() > 0) {
//            for (JsonNode jsonNode : jsonNodes) {
//                channel = JsonUtils.recordJsonToObject(jsonNode, ChannelVO.class);
//                chainCodeId = channel.getChainCodeId() == null ? new String[]{} : channel.getChainCodeId().split("_");
//            }
//        }
//        if (chainCodeId != null && chainCodeId.length == 3) {
//            return chainCodeId[1];
//        }
//        return null;
//    }
//
//
//    public Map create(String channelName, String partners) {
//        ChannelVO channelVO = chainService.getChannelByName(channelName);
//        if (channelVO != null) {
//            throw new BusinessException("通道名已存在，请重新输入！");
//        }
//        createChannel(channelName, partners, 1);//创建正式通道
//
//        createChannel(Constants.getTestChannelName(channelName), partners, 2);//前缀为test的测试通道
//        return new SimpleMap("message", "通道创建成功");
//    }
//
//    private void createChannel(String channelName, String partners, int initChannnelStatus) {
//
//        channelClientCreatedFactory.buildChannelClient(channelName, "test");
//
//        ChannelVO channelVO = new ChannelVO();
//        channelVO.setChannelName(channelName);
//        channelVO.setGmtCreate(new Date());
//        channelVO.setId(channelName);
//        channelVO.setStatus(initChannnelStatus);
//        commonChannel.invoke("set", byte[].class, channelVO.getId(), JsonUtils.objecToJson(channelVO));
//
//        ChannelMapOrgVO channelMapOrgVO = new ChannelMapOrgVO();
//        channelMapOrgVO.setChannelId(channelVO.getId());
//        channelMapOrgVO.setChannelName(channelVO.getId());
//        channelMapOrgVO.setId(Helper.uuid());
//        channelMapOrgVO.setRegisterTime(new Date());
//        channelMapOrgVO.setOrgId(appConfiguration.getFabricOrgId());
//        channelMapOrgVO.setStatus(1);
//        commonChannel.invoke("set", byte[].class, channelMapOrgVO.getId(), JsonUtils.objecToJson(channelMapOrgVO));
//
//        if (partners != null && !"".equals(partners)) {
//            List partnerList = JSON.parseArray(partners);
//            if (partnerList != null && partnerList.size() > 0) {
//                createInviteOrg(channelName, partnerList);
//            }
//        }
//    }
//
//    public Page queryByPage(Integer current, Integer size) {
//        Page result = new Page<>();
//        ChannelVO channel;
//        //根据orgid查询channelName
//        Set<String> channelNameOrg = getChannelNameByOrgId();
//        System.out.println("channelNameOrg" + JSONObject.toJSONString(channelNameOrg));
//        //根据channelName筛选查询条件
//
//        String query = FindQueryBuilder.begin(ChannelVO.DOC_TYPE).build();
//        byte[] bytes = commonChannel.query("customeQuery", byte[].class, query);
//        ArrayNode jsonNodes = (ArrayNode) JsonUtils.toJsonNode(bytes);
//        Map<String, DisplayChannelVO> displayChannelMap = new HashMap<>();
//
//
//        query = FindQueryBuilder.begin(ChannelMapOrgVO.DOC_TYPE).build();
//        byte[] customeQueries = commonChannel.query("customeQuery", byte[].class, query);
//        ArrayNode orgNodes = (ArrayNode) JsonUtils.toJsonNode(customeQueries);
//
//        query = FindQueryBuilder.begin(ChainMapOrg.DOC_TYPE).eq("org", appConfiguration.getFabricOrgId()).build();
//        byte[] chainMapOrgQueries = commonChannel.query("customeQuery", byte[].class, query);
//        ArrayNode chainMapOrgNodes = (ArrayNode) JsonUtils.toJsonNode(chainMapOrgQueries);
//
//        if (jsonNodes == null || jsonNodes.size() == 0 ||
//                orgNodes == null || orgNodes.size() == 0) {
//            return result;
//        }
//        List orgOwnList = new ArrayList();
//        Map<String, Integer> orgMaps = new HashMap<>();
//
//        for (JsonNode orgNode : orgNodes) {
//            ChannelMapOrgVO channelMapOrgVO = JsonUtils.recordJsonToObject(orgNode, ChannelMapOrgVO.class);
//            String channelName = null;
//            if (channelMapOrgVO != null) {
//                channelName = channelMapOrgVO.getChannelName();
//            }
//            if (channelMapOrgVO != null && !channelName.startsWith("test")) {
//                Integer orgNum = orgMaps.get(channelName);
//                if (orgNum == null) {
//                    orgMaps.put(channelName, 1);
//                } else {
//                    orgMaps.put(channelName, orgNum + 1);
//                }
//            }
//            if (channelMapOrgVO != null) {
//                String orgId = channelMapOrgVO.getOrgId();
//                if (appConfiguration.getFabricOrgId() != null && appConfiguration.getFabricOrgId().equals(orgId) && channelMapOrgVO.getStatus() != null && channelMapOrgVO.getStatus() == 1) {
//                    orgOwnList.add(channelMapOrgVO.getChannelName());
//                }
//            }
//        }
//
//
//        for (JsonNode jsonNode : jsonNodes) {
//            channel = JsonUtils.recordJsonToObject(jsonNode, ChannelVO.class);
//            if (channel != null) {
//                String channelName = channel.getChannelName();
//
//                if (!orgOwnList.contains(channelName)) {
//                    continue;
//                }
//
//                if (!channelNameOrg.contains(channelName))
//                    continue;
//                String channelNameInMap = channelName.startsWith("test") ? channelName.substring(4) : channelName;
//
//                //String[] split = channel.getChainCodeId() == null ? new String[]{} : channel.getChainCodeId().split("_");
//                String chainCodeId = channel.getChainCodeId();
//
//                DisplayChannelVO displayChannelVO;
//                if (displayChannelMap.get(channelNameInMap) != null) {
//                    displayChannelVO = displayChannelMap.get(channelNameInMap);
//                } else {
//                    displayChannelVO = new DisplayChannelVO();
//                }
//
//                if (channelName.startsWith("test")) {
//                    displayChannelVO.setTestChannelName(channelName);
//                    displayChannelVO.setTestChannelStatus(channel.getStatus());
//                    displayChannelVO.setTestChainCodeId(channel.getChainCodeId());
//                    //if (split.length == 3) displayChannelVO.setTestChainCodeName(split[1]);
//                    if (StringUtils.isNotEmpty(chainCodeId)) {
//                        displayChannelVO.setTestChainCodeName(chainCodeId.substring(chainCodeId.indexOf("_") + 1, chainCodeId.lastIndexOf("_")));
//                    }
//                } else {
//                    displayChannelVO.setChannelName(channelName);
//                    displayChannelVO.setChannelId(channelName);
//                    displayChannelVO.setChannelStatus(channel.getStatus());
//                    displayChannelVO.setChainCodeId(channel.getChainCodeId());
//                    if (StringUtils.isNotEmpty(chainCodeId)) {
//                        displayChannelVO.setChainCodeName(chainCodeId.substring(chainCodeId.indexOf("_") + 1, chainCodeId.lastIndexOf("_")));
//                    }
//                }
//                displayChannelVO.setCreateDate(DateUtil.DateToString(channel.getGmtCreate(), DateStyle.YYYY_MM_DD_HH_MM));
//                displayChannelMap.put(channelNameInMap, displayChannelVO);
//            }
//        }
//
//        List<DisplayChannelVO> mValuesList = new ArrayList<>(displayChannelMap.values());
//        //按照时间进行排序
//        Collections.sort(mValuesList, new Comparator<DisplayChannelVO>() {
//            @Override
//            public int compare(DisplayChannelVO o1, DisplayChannelVO o2) {
//                String t1 = o1.getCreateDate();
//                String t2 = o2.getCreateDate();
//                if(t1 ==null || t2 == null ){
//                    return 0;
//                }
//                long longt1 = Long.valueOf(t1.replaceAll("[-\\s:]", ""));
//                long longt2 = Long.valueOf(t2.replaceAll("[-\\s:]", ""));
//
//                if (longt1 > longt2) {
//                    return -1;
//                } else if (longt1 == longt2) {
//                    return 0;
//                } else {
//                    return 1;
//                }
//            }
//        });
//
//        result.setTotal(mValuesList.size());
//        mValuesList = RAMPageService.page(mValuesList, current, size);
//
//
//        if (mValuesList != null && mValuesList.size() > 0) {
//            for (DisplayChannelVO displayChannelVO : mValuesList) {
//                if (displayChannelVO != null) {
//                    String channelName = displayChannelVO.getChannelName();
//                    String testChannelName = displayChannelVO.getTestChannelName();
//                    if (StringUtils.isNotEmpty(channelName) && !channelName.startsWith("test")) {
//                        displayChannelVO.setOrgNum(orgMaps.get(channelName));
//                    }
//                    if (StringUtils.isNotEmpty(testChannelName) && testChannelName.startsWith("test")
//                            && StringUtils.isNotEmpty(displayChannelVO.getTestChainCodeId())) {
//                        for (JsonNode jsonNode : chainMapOrgNodes) {
//                            ChainMapOrg chainMapOrg = JsonUtils.recordJsonToObject(jsonNode, ChainMapOrg.class);
//                            if (chainMapOrg != null && displayChannelVO.getTestChainCodeId().equals(chainMapOrg.getChain())) {
//                                if (StringUtils.isNotEmpty(chainMapOrg.getResult()) && !"-1".equals(chainMapOrg.getResult())) {
//                                    displayChannelVO.setFeedbackStatus(true);
//                                } else {
//                                    displayChannelVO.setFeedbackStatus(false);
//                                }
//                                break;
//                            }
//                        }
//                    }
//                }
//            }
//        }
//
//        result.setRecords(mValuesList);
//        return result;
//    }
//
//    /**
//     * 根据orgid查询channelName
//     *
//     * @return
//     */
//    private Set<String> getChannelNameByOrgId() {
//        Set<String> returnName = new HashSet<String>();
//        String query = FindQueryBuilder.begin(ChannelMapOrgVO.DOC_TYPE).eq("orgId", orgId).build();
//        byte[] bytes = commonChannel.query("customeQuery", byte[].class, query);
//        ArrayNode jsonNodes = (ArrayNode) JsonUtils.toJsonNode(bytes);
//        for (JsonNode jsonNode : jsonNodes) {
//            ChannelMapOrgVO channelOrg = JsonUtils.recordJsonToObject(jsonNode, ChannelMapOrgVO.class);
//            returnName.add(channelOrg.getChannelName());
//        }
//        return returnName;
//    }
//
//    public List partnerOrgs(String channelName, int status) {
//        FindQueryBuilder queryFindQueryBuilder = FindQueryBuilder.begin(ChannelMapOrgVO.DOC_TYPE).eq("channelName", channelName);
//        String query = null;
//        if (status == 1) {
//            query = queryFindQueryBuilder.eq("status", status).build();
//        } else {
//            query = queryFindQueryBuilder.build();
//        }
//        byte[] bytes = commonChannel.query("customeQuery", byte[].class, query);
//        ArrayNode jsonNodes = (ArrayNode) JsonUtils.toJsonNode(bytes);
//        List<Map> resultList = null;
//        Map orgMap = null;
//        if (jsonNodes != null && jsonNodes.size() > 0) {
//            resultList = new ArrayList<>(jsonNodes.size());
//            for (JsonNode jsonNode : jsonNodes) {
//                ChannelMapOrgVO channelMapOrgVO = JsonUtils.recordJsonToObject(jsonNode, ChannelMapOrgVO.class);
//                if (channelMapOrgVO != null) {
//                    if (channelMapOrgVO.getOrgId() != null && !"".equals(channelMapOrgVO.getOrgId())) {
//                        Organization organization = organizationRepository.getOrganization(channelMapOrgVO.getOrgId(), null);
//                        if (organization != null) {
//                            orgMap = new HashMap();
//                            orgMap.put("orgId", organization.getOrgId());
//                            orgMap.put("orgName", organization.getOrgName());
//                            orgMap.put("orgLevel", organization.getLevel());
//                            orgMap.put("is_join", (channelMapOrgVO.getStatus() != null && channelMapOrgVO.getStatus() == 0) || channelMapOrgVO.getStatus() == null
//                                    ? false : true);
//                            orgMap.put("registerTime", DateUtil.DateToString(channelMapOrgVO.getRegisterTime(), DateStyle.YYYY_MM_DD_HH_MM));
//                            resultList.add(orgMap);
//                        }
//                    }
//                }
//            }
//        }
//        return resultList;
//    }
//
    public Map queryChannelinfo(String channelName,String orgName) throws ProposalException, IOException, InvalidArgumentException {
        Map returnMap = new HashMap();
        ChannelClient channelClient = ChannelCache.getTestClient(channelName,orgName , "just chanel");
        returnMap.put("channelHeight", queryBlockHeight(channelClient,channelName));

        Channel channel = channelClient.getChannel();
        returnMap.put("transactionCounrt", fabricBlockService.getAllTransNum(channel));

        return returnMap;
    }
    
public long queryBlockHeight(ChannelClient channelClient, String channelName) {
    	
        Channel channel = channelClient.getChannel();
        try {
            long height = getCurrentBlockHeight(channel);
            return height;
        } catch (Exception e) {
            return 0;
        }
    }

/**
 * 获取 当前区块高度
 */
public long getCurrentBlockHeight(Channel channel) throws InvalidArgumentException, ProposalException, IOException {
    BlockchainInfo channelInfo = channel.queryBlockchainInfo();
    return channelInfo.getHeight();
}
//
    /*查看单一区块信息 service*/
    public Map<String, Object> queryChannelByName(String channelName,String orgName, Integer blockId) throws InvalidArgumentException, ProposalException {
        Channel channel = reConstructChannel(channelName, orgName);
        Map<String, Object> result = getMapInfo(channel, blockId);
        return result;
    }
    
    public Map<String,Object> getMapInfo(Channel channel, Integer blockId) throws InvalidArgumentException, ProposalException {
    	Map<String,Object> result = new HashMap<String,Object>();
    	BlockInfo  blockInfo =  channel.queryBlockByNumber(blockId);
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	String createTime=null;
    	Iterable<EnvelopeInfo> itretor=blockInfo.getEnvelopeInfos();
    	int count=0;
    	for (EnvelopeInfo envelopeInfo : itretor) {
    		count++;
    		if(count>=2){
    			break;
    		}
    	createTime=sdf.format(envelopeInfo.getTimestamp());
		}
    	result.put("blockId", blockInfo.getBlockNumber());
    	result.put("blockHash", blockInfo.getDataHash());
    	//result.put("blockHash", blockInfo.getDataHash());
		try {
			result.put("blockHash", Hex.encodeHexString(SDKUtils.calculateBlockHash(getSDKUtilsHFClient(),blockInfo.getBlockNumber(), blockInfo.getPreviousHash(), blockInfo.getDataHash())));
		} catch (IOException e) {
			logger.error("getMapInfo fail, because "+e);
		}
		result.put("transactionCount", blockInfo.getEnvelopeCount());
    	result.put("createTime", createTime);
		return result;
    }
    
    private HFClient getSDKUtilsHFClient(){
    	HFClient client = HFClient.createNewInstance();

        try {
			client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
		} catch (CryptoException | InvalidArgumentException | IllegalAccessException | InstantiationException
				| ClassNotFoundException | NoSuchMethodException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        return client;
    }
//
//    private Map createInviteOrg(String channelName, List partnerList) {
//        ChannelMapOrgVO channelMapOrgVO = null;
//        MessageVO messageVO = null;
//        List<Map> partnerOrgList = partnerOrgs(channelName, 0);
//        if (partnerList != null && partnerList.size() > 0) {
//            for (Object partner : partnerList) {
//                if (partner != null) {
//
//                    String inviteOrgId = partner.toString();
//                    if ("".equals(inviteOrgId)) {
//                        throw new BusinessException("邀请失败，请先选择所邀请的组织！");
//                    }
//
//                    if (partnerOrgList != null && partnerOrgList.size() > 0) {
//                        for (Map partnerOrg : partnerOrgList) {
//                            String orgId = partnerOrg.get("orgId") + "";
//                            if (orgId != null && inviteOrgId.equals(orgId)) {
//                                break;
//                            }
//                        }
//                    }
//
//                    //保存正式通道邀请信息
//                    channelMapOrgVO = new ChannelMapOrgVO();
//                    channelMapOrgVO.setChannelId(channelName);
//                    channelMapOrgVO.setChannelName(channelName);
//                    channelMapOrgVO.setId(Helper.uuid());
//                    channelMapOrgVO.setOrgId(inviteOrgId);
//                    channelMapOrgVO.setStatus(0);
//                    commonChannel.invoke("set", byte[].class, channelMapOrgVO.getId(), JsonUtils.objecToJson(channelMapOrgVO));
//
//                    //发送消息
//                    if (!channelName.startsWith("test")) {
//                    	LoginUser loginUser = (LoginUser) SecurityUtils.getSubject().getPrincipal();
//                        messageVO = new MessageVO();
//                        messageVO.setId(Constants.getMessageId(channelMapOrgVO.getOrgId()));
//                        messageVO.setSender(loginUser.getOrganizationName());
//                        messageVO.setStatus(0);
//                        messageVO.setSummary(MessageUtil.getInviteOrgMsg(channelName));
//                        messageVO.setType(Constants.MESSAGE_CHANNEL_INVITE);
//                        messageVO.setReceiver(channelMapOrgVO.getOrgId());
//                        commonChannel.invoke("set", byte[].class, messageVO.getId(), JsonUtils.objecToJson(messageVO));
//                    }
//
//                }
//            }
//            return new SimpleMap("message", "邀请成功！");
//        } else {
//            throw new BusinessException("邀请失败,请先选择邀请组织！");
//        }
//    }
//
//    public Map inviteOrg(String channelName, List partnerList) {
//        ChannelMapOrgVO channelMapOrgVO = null;
//        MessageVO messageVO = null;
//        ChainMapOrg chainMapOrg = null;
//        List<Map> partnerOrgList = partnerOrgs(channelName, 0);
//        Boolean returnFlag = false;
//        if (partnerList != null && partnerList.size() > 0) {
//            for (Object partner : partnerList) {
//                if (partner != null) {
//
//                    String inviteOrgId = partner.toString();
//                    if ("".equals(inviteOrgId)) {
//                        throw new BusinessException("邀请失败，请先选择所邀请的组织！");
//                    }
//
//                    if (partnerOrgList != null && partnerOrgList.size() > 0) {
//                        for (Map partnerOrg : partnerOrgList) {
//                            String orgId = partnerOrg.get("orgId") + "";
//                            if (orgId != null && inviteOrgId.equals(orgId)) {
//                                returnFlag = true;
//                                break;
//                            }
//                        }
//                    }
//                    if (returnFlag) {
//                        break;
//                    }
//
//                    Map channelMap = chainService.getChannelCondi(channelName);
//                    if(channelMap!=null && channelMap.size()>0){
//                        String testChannelStatus = channelMap.get("testChannelStatus")+"";
//                        String testChainCodeId = channelMap.get("testChainCodeId")+"";
//                        if(StringUtils.isNotEmpty(testChannelStatus) && "4".equals(testChannelStatus) && StringUtils.isNotEmpty(testChainCodeId)){
//                            chainMapOrg = new ChainMapOrg();
//                            chainMapOrg.setChain(testChainCodeId);
//                            chainMapOrg.setId(Helper.uuid());
//                            chainMapOrg.setOrg(inviteOrgId);
//                            chainMapOrg.setResult("-1");
//                            commonChannel.invoke("set", byte[].class, chainMapOrg.getId(), JsonUtils.objecToJson(chainMapOrg));
//                        }
//                    }
//
//                    //保存正式通道邀请信息
//                    channelMapOrgVO = new ChannelMapOrgVO();
//                    channelMapOrgVO.setChannelId(channelName);
//                    channelMapOrgVO.setChannelName(channelName);
//                    channelMapOrgVO.setId(Helper.uuid());
//                    channelMapOrgVO.setOrgId(inviteOrgId);
//                    channelMapOrgVO.setStatus(0);
//                    commonChannel.invoke("set", byte[].class, channelMapOrgVO.getId(), JsonUtils.objecToJson(channelMapOrgVO));
//
//                    //发送消息
//                    LoginUser loginUser = (LoginUser) SecurityUtils.getSubject().getPrincipal();
//                    messageVO = new MessageVO();
//                    messageVO.setId(Constants.getMessageId(channelMapOrgVO.getOrgId()));
//                    messageVO.setSender(loginUser.getOrganizationName());
//                    messageVO.setStatus(0);
//                    messageVO.setSummary(MessageUtil.getInviteOrgMsg(channelName));
//                    messageVO.setType(Constants.MESSAGE_CHANNEL_INVITE);
//                    messageVO.setReceiver(channelMapOrgVO.getOrgId());
//                    commonChannel.invoke("set", byte[].class, messageVO.getId(), JsonUtils.objecToJson(messageVO));
//
//                    //保存测试通道邀请信息
//                    channelMapOrgVO = new ChannelMapOrgVO();
//                    channelMapOrgVO.setChannelId(Constants.getTestChannelName(channelName));
//                    channelMapOrgVO.setChannelName(Constants.getTestChannelName(channelName));
//                    channelMapOrgVO.setId(Helper.uuid());
//                    channelMapOrgVO.setOrgId(inviteOrgId);
//                    channelMapOrgVO.setStatus(0);
//                    commonChannel.invoke("set", byte[].class, channelMapOrgVO.getId(), JsonUtils.objecToJson(channelMapOrgVO));
//
//                }
//            }
//            return new SimpleMap("message", "邀请成功！");
//        } else {
//            throw new BusinessException("邀请失败,请先选择邀请组织！");
//        }
//    }
//
//    public Map acceptInvitation(String channelName) {
//
//        String testChannelName = Constants.getTestChannelName(channelName);
//        String orgId = appConfiguration.getFabricOrgId();
//        String query = FindQueryBuilder.begin(ChannelMapOrgVO.DOC_TYPE).eq("channelName", channelName)
//                .eq("orgId", orgId).build();
//        byte[] bytes = commonChannel.query("customeQuery", byte[].class, query);
//        ChannelMapOrgVO channelMapOrgVO = JsonUtils.singleRecordJsonToObject(bytes, ChannelMapOrgVO.class);
//
//        String testQuery = FindQueryBuilder.begin(ChannelMapOrgVO.DOC_TYPE).eq("channelName", testChannelName)
//                .eq("orgId", orgId).build();
//        byte[] testBytes = commonChannel.query("customeQuery", byte[].class, testQuery);
//        ChannelMapOrgVO testChannelMapOrgVO = JsonUtils.singleRecordJsonToObject(testBytes, ChannelMapOrgVO.class);
//
//        if (channelMapOrgVO != null && testChannelMapOrgVO != null) {
//            Boolean testDeployFlag = false;
//            Boolean deployFlag = false;
//
//            ChannelClient channelClient = channelClientJoinFactory.buildChannelClient(channelName, "test");
//            //ChannelClient channelClient = channelClientFactory.buildChannelClient(channelName, "test");
//
//            ChannelClient testChannelClient = channelClientJoinFactory.buildChannelClient(Constants.getTestChannelName(channelName), "test");
//            //ChannelClient testChannelClient = channelClientFactory.buildChannelClient(Constants.getTestChannelName(channelName), "test");
//
//            ChannelVO channelVO = chainService.getChannelByName(channelName);
//            ChannelVO testChannelVO = chainService.getChannelByName(testChannelName);
//            //部署测试通道合约信息
//            if (testChannelVO != null) {
//                testDeployFlag = joinChaincode(testChannelVO, testChannelClient);
//            }
//
//            //部署正式通道合约信息
//            if (channelVO != null) {
//                deployFlag = joinChaincode(channelVO, channelClient);
//            }
//
//            if (testDeployFlag && deployFlag) {
//                channelMapOrgVO.setStatus(1);
//                channelMapOrgVO.setRegisterTime(new Date());
//                commonChannel.invoke("set", byte[].class, channelMapOrgVO.getId(), JsonUtils.objecToJson(channelMapOrgVO));
//
//                testChannelMapOrgVO.setStatus(1);
//                testChannelMapOrgVO.setRegisterTime(new Date());
//                commonChannel.invoke("set", byte[].class, testChannelMapOrgVO.getId(), JsonUtils.objecToJson(testChannelMapOrgVO));
//            }
//            if(testChannelVO != null && StringUtils.isNotEmpty(testChannelVO.getChainCodeId())){
//                return new SimpleMap("message", "加入并部署测试合约！");
//            }
//            return new SimpleMap("message", "加入成功！");
//        } else {
//            return new SimpleMap("message", "加入失败，您还无权加入该通道！");
//        }
//    }
//
//
//    public Map deployChaincode(String messageId) {
//
//        Message message = messageService.getDetail(Integer.valueOf(messageId));
//        String summary = null;
//        if (message == null || StringUtils.isEmpty(message.getSummary())) {
//            throw new BusinessException("部署失败，无此消息，或者消息内容为空，请联系管理员！");
//        }
//        summary = message.getSummary();
//        String channelName = null;
//        if (StringUtils.isNotEmpty(summary)) {
//            if (summary.lastIndexOf(Constants.MESSAGE_TEST_SUMMARY) > -1) {//测试通道合约部署
//                channelName = summary.replace(Constants.MESSAGE_TEST_SUMMARY, "");
//            } else if (summary.lastIndexOf(Constants.MESSAGE_DEPLOY_SUMMARY) > -1) {//正式通道合约部署
//                channelName = summary.replace(Constants.MESSAGE_DEPLOY_SUMMARY, "");
//                if (channelName.startsWith("test")) {
//                    channelName = channelName.replace("test", "");
//                }
//            }
//        }
//        if (StringUtils.isEmpty(channelName)) {
//            throw new BusinessException("通道名不能为空！");
//        }
//
//        String orgId = appConfiguration.getFabricOrgId();
//        String query = FindQueryBuilder.begin(ChannelMapOrgVO.DOC_TYPE).eq("channelName", channelName)
//                .eq("orgId", orgId).build();
//        byte[] bytes = commonChannel.query("customeQuery", byte[].class, query);
//        ChannelMapOrgVO channelMapOrgVO = JsonUtils.singleRecordJsonToObject(bytes, ChannelMapOrgVO.class);
//
//
//        if (channelMapOrgVO != null) {// && testChannelMapOrgVO != null
//            Boolean deployFlag = false;
//
//            ChannelClient channelClient = channelClientFactory.buildChannelClient(channelName, "test");
//
//            ChannelVO channelVO = chainService.getChannelByName(channelName);
//
//            //部署正式通道合约信息
//            if (channelVO != null) {
//                deployFlag = joinChaincode(channelVO, channelClient);
//            }
//
//            if (deployFlag) {
//                message.setStatus(MessageStatusEnum.DEAL.getType());//将message的status状态设置成2，说明该消息已经处理过了。
//                messageService.updateMessage(message);
//                return new SimpleMap("message", "部署合约成功！");
//            }
//            throw new BusinessException("部署合约失败！");
//        } else {
//            throw new BusinessException("加入失败，您还无权加入该通道！");
//        }
//    }
//
//    private Boolean joinChaincode(ChannelVO channelVO, ChannelClient channelClient) {
//        if (channelVO != null && channelClient != null) {
//            String chainCodeId = channelVO.getChainCodeId();
//            String channelName = channelVO.getChannelName();
//
//            if (!StringUtils.isEmpty(chainCodeId)) {
//                ChaincodeVO chaincodeVO = chainService.getChainCodeDetail(chainCodeId);
//
//                if (chaincodeVO != null && appConfiguration.getFabricOrgId().equals(chaincodeVO.getCreater())) {
//                    return true;
//                }
//
//                if (chaincodeVO != null && !StringUtils.isEmpty(chaincodeVO.getContent())
//                        && !StringUtils.isEmpty(chaincodeVO.getVersion())) {
//
//                    ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(channelName)
//                            .setVersion(chaincodeVO.getVersion()).setPath("chaincode").build();
//                    InputStream in = null;
//                    try {
//                        byte[] chainContentByte = org.apache.commons.codec.binary.Base64.decodeBase64(chaincodeVO.getContent());
//                        in = new ByteArrayInputStream(chainContentByte);
//
//                        return channelClient.deployChainCode(chaincodeID, in);
//                    } catch (Exception e) {
//                        logger.error("joinChaincode fail, because " + e);
//                    } finally {
//                        if (in != null) {
//                            try {
//                                in.close();
//                            } catch (IOException e) {
//                                //e.printStackTrace();
//                                logger.error("joinChaincode fail, because " + e);
//                            }
//                        }
//                    }
//                }
//            } else {
//                return true;
//            }
//        }
//        return false;
//    }
}
