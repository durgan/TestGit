package com.suning.snbc.developer.portal.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.exception.TransactionException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.suning.snbc.developer.framework.support.FieldValidator;
import com.suning.snbc.developer.framework.support.JsonRequest;
import com.suning.snbc.developer.portal.Constants;
import com.suning.snbc.developer.portal.sdk.ChannelClientCreatedAPIFactory;
//import com.suning.snbc.developer.portal.service.SDKService;
import com.suning.snbc.developer.support.BusinessException;
import com.suning.snbc.developer.util.ChannelCache;
import com.suning.snbc.sdk.ChannelClient;
import com.suning.snbc.sdk.ChannelClientCreatedFactory;
import com.suning.snbc.sdk.ChannelClientFactory;
import com.suning.snbc.sdk.FabricConfig;
import com.suning.snbc.sdk.FabricOrg;
import com.suning.snbc.sdk.FabricUser;

/**
 * 
 * Description:channel相关 Title: ChannelController.java
 * 
 * @author 88399341 - jiang
 * @date 2018-07-31 14:28
 */
@RestController
@RequestMapping("/sdk/channel")
public class ChannelController {

	// @Autowired
	// private SDKService sdkService;

	@Resource
	private FabricConfig fabricConfig;

	@Resource
	ChannelClientCreatedFactory create;

	@Resource(name = "channelClientCreatedFactory")
	private ChannelClientCreatedFactory channelClientCreatedFactory;

	@Resource
	private ChannelClientCreatedAPIFactory channelClientCreatedAPIFactory;
	@Resource
	ChannelClientFactory channelClientFactory;

	/**
	 * 创建通道
	 */
	@RequestMapping("/createChannel")
	public String create(@RequestBody JsonRequest jsonRequest) {
		String channelName = jsonRequest.getString("channelName");
		String orgName = jsonRequest.getString("orgName");
		// String orgName = fabricConfig.getOrgName();

		List<String> peerNameList = new ArrayList<String>();
		String[] peerNames = new String[] {};
		if (jsonRequest.getMap().containsKey("peerNames")) {
			peerNames = jsonRequest.getStringArray("peerNames");
			if (peerNames.length > 0) {
				peerNameList = Arrays.asList(peerNames);
			}
		}

		channelClientCreatedAPIFactory.buildChannelWithOrgPeer(channelName, peerNameList, orgName);

		return "ok";
	}

	/**
	 * 加入通道
	 * 
	 * @param jsonRequest
	 * @throws InvalidKeySpecException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws IOException
	 * @throws InvalidArgumentException
	 * @throws ProposalException
	 */
	@RequestMapping("/joinChannel")
	public String joinChannel(@RequestBody JsonRequest jsonRequest)
			throws InvalidKeySpecException, NoSuchAlgorithmException, NoSuchProviderException, IOException,
			InvalidArgumentException, ProposalException {

		// String orgName = fabricConfig.getOrgName();
		String orgName = jsonRequest.getString("orgName");
		String channelName = jsonRequest.getString("channelName");
		String toJoinPeerStr = jsonRequest.getString("toJoinPeerStr");
		channelClientCreatedAPIFactory.joinPeers(channelName, orgName, toJoinPeerStr);

		return "ok";

	}

	// /**
	// * 拉取系统channel和普通channel
	// * @param jsonRequest
	// * @return
	// * @throws IOException
	// * @throws ClientProtocolException
	// * @throws TransactionException
	// * @throws ProposalException
	// * @throws InvalidArgumentException
	// */
	// @RequestMapping("/queryChannelConfig")
	// public Map queryChannelConfig(@RequestBody JsonRequest jsonRequest) throws
	// TransactionException, ClientProtocolException, IOException,
	// InvalidArgumentException, ProposalException{
	// String channelName = jsonRequest.getString("channelName");
	// String orgName = fabricConfig.getOrgName();
	//// JSONObject sysChannel = getChannelConfig("testchainid","AidTech","t1");
	// JSONObject customChannel = getChannelConfig(channelName,orgName,"t1");
	//
	//
	// return new HashMap(){{
	// put("customChannel",customChannel);
	//// put("sysChannel",sysChannel);
	//
	// }};
	// }
	//
	// private JSONObject getChannelConfig(String channelName,String orgName,String
	// chaincodeName) throws TransactionException, ClientProtocolException,
	// IOException, InvalidArgumentException, ProposalException {
	// ChannelClient channelClient = ChannelCache.getTestClient(channelName,orgName
	// , chaincodeName);
	//
	//// System.out.println(JSONObject.toJSONString(channelClient.getChannel().queryBlockByNumber(0)));
	//// JSONObject tm =
	// JSONObject.parseObject(JSONObject.toJSONString(channelClient.getChannel().queryBlockByNumber(0)))
	// ;
	// final byte[] channelConfigurationBytes =
	// channelClient.getChannel().getChannelConfigurationBytes();
	//
	// HttpClient httpclient = HttpClients.createDefault();
	// HttpPost httppost = new HttpPost(getFabricConfigTxLaterLocation() +
	// "/protolator/decode/common.Config");
	// httppost.setEntity(new ByteArrayEntity(channelConfigurationBytes));
	//
	// HttpResponse response = httpclient.execute(httppost);
	// int statuscode = response.getStatusLine().getStatusCode();
	// String responseAsString = EntityUtils.toString(response.getEntity());
	//
	// System.out.println("oldResponseString"+responseAsString);
	// return JSONObject.parseObject(responseAsString);
	// }
	//
	// public String getFabricConfigTxLaterLocation() {
	//// return "http://" + "10.244.167.152" + ":7059";
	// return "http://" + "10.37.198.250" + ":7059";
	//
	// }

}
