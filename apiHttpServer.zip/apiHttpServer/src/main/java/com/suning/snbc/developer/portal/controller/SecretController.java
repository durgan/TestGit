package com.suning.snbc.developer.portal.controller;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.suning.snbc.developer.framework.support.JsonRequest;
import com.suning.snbc.developer.framework.support.version.ApiVersion;
import com.suning.snbc.developer.portal.ResultCode;
import com.suning.snbc.developer.portal.service.SecretService;
import com.suning.snbc.developer.support.BusinessException;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/{version}/secret")
@Slf4j
@ApiVersion(1)
public class SecretController {

	@Autowired
    private ServletContext servletContext;
	
	@Autowired
	private SecretService secretService;
	/**
	 * 刷新存储的appid 和 APPsecret
	 * @return
	 */
	@RequestMapping("/refreshSecret")
	public String refreshSecret(@RequestBody JsonRequest request){
		String appkey = request.getString("appkey");
		String appsecret = request.getString("appsecret");
		String sign = request.getString("sign");

		boolean isOk = secretService.refreshSecret(appkey,appsecret,sign);
		
		if(isOk){
			return "success";
		}
		
		return "error";
	}
	
	public static void main(String[] args) {
		
	}
	
	
}
