package com.suning.snbc.developer.portal;

/**
 * @author 17031596@cnsuning.com
 */
public interface RoleConstants {
}
