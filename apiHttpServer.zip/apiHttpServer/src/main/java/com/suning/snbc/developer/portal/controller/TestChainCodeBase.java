package com.suning.snbc.developer.portal.controller;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPOutputStream;

import com.suning.snbc.developer.util.TarUtils;

/**
 * 
* Description: 获取合约文件base64字符串
* Title: TestChainCodeBase.java
* @author 88399341 - jiang
* @date 2018-09-04 15:45
 */
public class TestChainCodeBase {
	private static int BUFFER = 1024 * 4; // 缓冲大小
	 private static byte[] B_ARRAY = new byte[BUFFER];
	 
	public static void main(String[] args) throws Exception {

//		String result = getChainCodeBase("E:\\tmp\\commonInfo\\src","E:\\tmp\\tc1.tar");
		String result = readString("E:\\tmp\\commoninfo.tar.gz");
//		 System.out.println(result);
	}

	

	/*
	  * 方法功能：把打包的tar文件压缩成gz格式 参数：srcFile 要压缩的tar文件路径
	  */
	 private static void compress(File srcFile) {
	  File target = new File(srcFile.getAbsolutePath() + ".gz");
	  FileInputStream in = null;
	  GZIPOutputStream out = null;
	  try {
	   in = new FileInputStream(srcFile);
	   out = new GZIPOutputStream(new FileOutputStream(target));
	   int number = 0;
	   while ((number = in.read(B_ARRAY, 0, BUFFER)) != -1) {
	    out.write(B_ARRAY, 0, number);
	   }
	  } catch (FileNotFoundException e) {
	   e.printStackTrace();
	  } catch (IOException e) {
	   e.printStackTrace();
	  } finally {
	   try {
	    if (in != null) {
	     in.close();
	    }

	    if (out != null) {
	     out.close();
	    }
	   } catch (IOException e) {
	    e.printStackTrace();
	   }
	  }
	 }
	 
	/**
	 * 获取合约base字符
	 * 
	 * @param chaicodeSrc
	 *            合约文件夹地址，该地址下包含chaincode文件夹，文件夹中包含go文件合约
	 * @param tarName
	 *            临时tar包输出路径
	 * @return
	 * @throws Exception
	 */
	public static String getChainCodeBase(String chaicodeSrc, String tarName) throws Exception {
		TarUtils.archive(chaicodeSrc, tarName);
		compress(new File(tarName));
		return readString(tarName+".gz");
	}

	public static String readString(String tarName) throws IOException {
		InputStream is = new FileInputStream(tarName);
		BufferedInputStream bis = new BufferedInputStream(is, 1024);
		int len = 0;
		byte[] buf = new byte[1024];

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		while ((len = bis.read(buf)) != -1) {
			bos.write(buf, 0, len);
		}
		bis.close();
		is.close();
		String data = com.sun.org.apache.xerces.internal.impl.dv.util.Base64.encode(bos.toByteArray());
		System.out.println(data);
		return data;
	}
}
