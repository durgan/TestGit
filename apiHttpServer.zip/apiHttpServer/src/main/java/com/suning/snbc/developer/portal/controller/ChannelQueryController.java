package com.suning.snbc.developer.portal.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.plugins.Page;
import com.suning.snbc.developer.framework.support.JsonRequest;
import com.suning.snbc.developer.framework.support.PageQuery;
import com.suning.snbc.developer.portal.dto.user.BlockVO;
import com.suning.snbc.developer.portal.dto.user.TransatcionVO;
import com.suning.snbc.developer.portal.service.ChannelService;
import com.suning.snbc.developer.portal.service.SDKService;
import com.suning.snbc.sdk.FabricConfig;

/**
 * 区块信息，交易信息相关查询
 * @author binarykey
 *
 */
@RestController
@RequestMapping("/sdk/channelQuery")
public class ChannelQueryController {

	@Resource
	SDKService sdkService;
	@Resource
	private FabricConfig fabricConfig;

	@Resource
	private ChannelService channelService;

	/**
	 * 分页查询交易
	 * @param request
	 * @return
	 */
	@RequestMapping("/queryTransactionByPage")
	public Page<TransatcionVO> queryTransactionByPage(@RequestBody JsonRequest request) {
		String channelName = request.getString("channelName");
		String orgName = fabricConfig.getOrgName();
		Integer current = request.getInteger("current", 0, null);
		Integer size = request.getInteger("size", 1, 50);
		String transactionHash = null;
		Map paramMap = request.getMap();
		if (paramMap != null && paramMap.size() > 0) {
			transactionHash = (paramMap.get("transactionHash") + "").trim();
		}
		return channelService.queryTransactionByPage(channelName, orgName, transactionHash, current, size);
	}

	/**
	 * 分页查询区块
	 * @param request
	 * @return
	 */
	@RequestMapping("/queryBlockByPage")
	public Page<BlockVO> queryBlockByPage(@RequestBody JsonRequest request) {
		String channelName = request.getString("channelName");
		String orgName = fabricConfig.getOrgName();
		Integer current = request.getInteger("current", 0, null);
		Integer size = request.getInteger("size", 1, 50);
		String blockParam = null;
		Map paramMap = request.getMap();
		if (paramMap != null && paramMap.size() > 0) {
			blockParam = (paramMap.get("blockParam") + "").trim();
		}
		return channelService.queryBlockByPage(channelName, orgName, blockParam, current, size);
	}

	@RequestMapping("/queryBlockTransactionByPage")
	public Page<TransatcionVO> queryBlockTransactionByPage(@RequestBody JsonRequest request) {
		String channelName = request.getString("channelName");
		String orgName = fabricConfig.getOrgName();
		Integer current = request.getInteger("current", 0, null);
		Integer size = request.getInteger("size", 1, 50);
		Long blockNum = request.getLong("blockId");
		return channelService.queryBlockTransactionByPage(channelName, orgName, blockNum, current, size);
	}

	/**
	 * 查询单一通道概要信息
	 */
	@RequestMapping("/queryChannelinfo")
	public Map queryChannelinfo(@RequestBody JsonRequest params)
			throws ProposalException, IOException, InvalidArgumentException {
		String channelName = params.getString("channelName");
		String orgName = fabricConfig.getOrgName();
		return channelService.queryChannelinfo(channelName, orgName);
	}

	/**
	 * 查询单一区块概要信息
	 * 
	 */
	@RequestMapping("/queryBlockDetail")
	public Map<String, Object> queryBlockDetail(@RequestBody JsonRequest params)
			throws InvalidArgumentException, ProposalException {
		String channelName = params.getString("channelName");
		String orgName = fabricConfig.getOrgName();
		Integer blockId = params.getInteger("blockId");
		return channelService.queryChannelByName(channelName, orgName, blockId);
	}

	/**
	 * 查询调用次数 目前使用内置数据库，可以考虑改成业务数据库
	 * @param params
	 * @return
	 */
	@RequestMapping("/queryInvokeCount")
	public Page<Map> queryInvokeCount(@RequestBody JsonRequest params){
		String channelName = params.getString("channelName");
		int ccurrent = params.getInteger("current");
		int csize = params.getInteger("size");
		PageQuery<Map> queryVO = new PageQuery<Map>(){{
			setCurrent(ccurrent);
			setSize(csize);
		}};
		Page<Map> pageResult = sdkService.queryInvokeCount(channelName,queryVO);
		return pageResult;
	}
}
