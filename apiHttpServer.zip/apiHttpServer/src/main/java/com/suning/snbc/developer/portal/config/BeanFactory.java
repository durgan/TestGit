package com.suning.snbc.developer.portal.config;

import java.io.IOException;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.ServletContext;

import com.suning.snbc.developer.framework.support.sign.SecretConfig;
import com.suning.snbc.developer.framework.support.sign.SecretConfigFactory;
import com.suning.snbc.developer.portal.Constants;
import com.suning.snbc.developer.portal.sdk.ChannelClientCreatedAPIFactory;
import com.suning.snbc.developer.portal.service.SDKService;
import com.suning.snbc.developer.support.BusinessException;
import com.suning.snbc.developer.util.DerbyUtil;
import com.suning.snbc.sdk.ChannelClient;
import com.suning.snbc.sdk.ChannelClientCreatedFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.suning.snbc.sdk.ChannelClientFactory;
import com.suning.snbc.sdk.FabricConfig;
import com.suning.snbc.sdk.FabricConfigFactory;
import org.springframework.web.context.ServletContextAware;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;

@Configuration
public class BeanFactory implements ServletContextAware {
	private static final Log logger = LogFactory.getLog(BeanFactory.class);
	@Value("${common.channel.name}")
    private String channelName;
    @Value("${common.channel.chaincode}")
    private String chainCode;
    
    
    @Override
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @Autowired
    private ServletContext servletContext;

    {
    	//初始化本地数据库
    	try {
			DerbyUtil.initTable();
		} catch (SQLException e) {
			logger.error("初始化本地数据库失败");
			e.printStackTrace();
//			throw new BusinessException("初始化本地数据库失败");
		}
    }
    
    @Bean(name = "channelClientCreatedFactory")
    public ChannelClientCreatedFactory channelClientCreatedFactory(FabricConfig fabricConfig) throws IOException {
        ChannelClientCreatedFactory channelClientCreatedFactory = new ChannelClientCreatedFactory();
        channelClientCreatedFactory.setFabricConfig(fabricConfig);
        return channelClientCreatedFactory;
    }

    @Bean(name = "channelClientFactory")
    public ChannelClientFactory channelClientFactory(FabricConfig fabricConfig) throws IOException {
        ChannelClientFactory channelClientFactory = new ChannelClientFactory();
        channelClientFactory.setFabricConfig(fabricConfig);
        return channelClientFactory;
    }

    @Bean
    public FabricConfig fabricConfig() throws IOException {
        FabricConfigFactory fabricConfigFactory = fabricConfigFactory();
        if (servletContext != null)
            fabricConfigFactory.setBaseDir(servletContext.getRealPath("/WEB-INF/classes/fabric"));
        FabricConfig config =fabricConfigFactory.buildFabricConfig();
        config.setOrgName(Constants.ORDEERORG);
        return config;
    }
    
    @Bean
    public FabricConfigFactory fabricConfigFactory() throws IOException {
    	FabricConfigFactory fabricConfigFactory = new FabricConfigFactory();
        fabricConfigFactory.setRunningTLS(false);
        return fabricConfigFactory;
    }

    @Bean
    public CookieSerializer cookieSerializer(){
        DefaultCookieSerializer cookieSerializer = new DefaultCookieSerializer();
        cookieSerializer.setCookiePath("/");
        cookieSerializer.setUseHttpOnlyCookie(true);
        return cookieSerializer;
    }
    
//    @Bean(name = "commonChannel")
//    public ChannelClient buildCommonChannel(ChannelClientFactory channelClientFactory) throws IOException {
////        channelClientFactory.setTransactionActionInfoListener(commonChannelBlockLisenter);
//        return channelClientFactory.buildChannelClient(channelName, chainCode);
//    }
    
    @Bean(name = "channelClientCreatedAPIFactory")
    public ChannelClientCreatedAPIFactory channelClientCreatedAPIFactory(FabricConfig fabricConfig) throws IOException {
    	ChannelClientCreatedAPIFactory channelClientCreatedFactory = new ChannelClientCreatedAPIFactory();
        channelClientCreatedFactory.setFabricConfig(fabricConfig);
        return channelClientCreatedFactory;
    }
    
    @Bean
    public SecretConfigFactory secretConfigFactory() throws IOException {
    	SecretConfigFactory secretConfigFactory = new SecretConfigFactory();
        if (servletContext != null)
        	secretConfigFactory.setBaseDir(servletContext.getRealPath("/WEB-INF/classes/fabric"));
        return secretConfigFactory;
    }

}
