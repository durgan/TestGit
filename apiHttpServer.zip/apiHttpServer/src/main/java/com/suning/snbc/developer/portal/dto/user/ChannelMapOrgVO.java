package com.suning.snbc.developer.portal.dto.user;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
public class ChannelMapOrgVO {

    public static final String DOC_TYPE = "CHANNELMAPORG";
    private String docType = "CHANNELMAPORG";

    private String id;

    private String channelId;

    private String channelName;

    private String orgId;

    private String orgName;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date registerTime;

    private Integer status;
}
