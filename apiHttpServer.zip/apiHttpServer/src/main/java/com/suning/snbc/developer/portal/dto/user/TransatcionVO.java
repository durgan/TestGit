package com.suning.snbc.developer.portal.dto.user;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class TransatcionVO {

    private String transactionID;

    private String blockHash;

    private long blockNum;

    private String chainCodeName;

    private String chainCodeArgs;

    private String createTime;

}
