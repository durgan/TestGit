package com.suning.snbc.developer.framework.support;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import org.springframework.util.StringUtils;

/**
 * @author 17031596@cnsuning.com
 */
public class EntityWrapperBuilder<T> {
    EntityWrapper<T> entityWrapper = new EntityWrapper<>();
    public EntityWrapperBuilder() {
    }

    public EntityWrapperBuilder<T> eq(String column, Object value){
        if(StringUtils.isEmpty(value))return this;
        entityWrapper.eq(column,value);
        return this;
    }

    public EntityWrapperBuilder<T> like(String column, String value){
        if(StringUtils.isEmpty(value))return this;
        entityWrapper.like(column,value);
        return this;
    }



    public EntityWrapper<T> getEntityWrapper() {
        return entityWrapper;
    }
}
