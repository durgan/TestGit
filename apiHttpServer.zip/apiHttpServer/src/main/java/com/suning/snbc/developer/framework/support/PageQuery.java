package com.suning.snbc.developer.framework.support;

import com.baomidou.mybatisplus.plugins.Page;

/**
 * @author 17031596@cnsuning.com
 */
public class PageQuery<T> {
    protected Integer current;
    protected Integer size;

    public PageQuery() {
        size = 10;
        current = 0;
    }

    public Page<T> toPage(){
        return new Page<T>(current,size);
    }

    public Integer getCurrent() {
        return current;
    }

    public void setCurrent(Integer current) {
        this.current = current;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }
}
