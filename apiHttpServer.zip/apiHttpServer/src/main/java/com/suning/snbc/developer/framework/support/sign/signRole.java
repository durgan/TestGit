package com.suning.snbc.developer.framework.support.sign;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 
* Description: 允许访问的角色
* Title: signRole.java
* @author 88399341 - jiang
* @date 2018-09-28 16:28
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface signRole {
	/**
	 * 允许访问的角色，如有多个用逗号隔开
	 * baas:baas平台角色 client:client角色
	 * @return
	 */
	String roles() default "client";
}
