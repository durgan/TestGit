package com.suning.snbc.developer.framework.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;

import com.suning.snbc.developer.framework.support.security.OperablePermissionEvaluator;

/**
 * 
* Description: 方法权限配置
* Title: MethodSecurityConfig.java
* @author 88399341 - jiang
* @date 2018-08-23 11:27
 */
//@Configuration
//@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class MethodSecurityConfig extends GlobalMethodSecurityConfiguration {
	@Autowired
    private OperablePermissionEvaluator operablePermissionEvaluator;
    

//    @Autowired
//    public void setCustomPermissionEvaluator(OperablePermissionEvaluator operablePermissionEvaluator) {
//        this.operablePermissionEvaluator = operablePermissionEvaluator;
//    }

    @Override
    protected MethodSecurityExpressionHandler createExpressionHandler() {
        DefaultMethodSecurityExpressionHandler expressionHandler = new DefaultMethodSecurityExpressionHandler();
        expressionHandler.setPermissionEvaluator(operablePermissionEvaluator);
        return expressionHandler;
        //return super.createExpressionHandler();
    }
}

