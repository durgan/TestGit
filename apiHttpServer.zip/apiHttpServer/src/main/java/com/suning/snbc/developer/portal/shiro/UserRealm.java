package com.suning.snbc.developer.portal.shiro;

import com.alibaba.fastjson.JSONObject;
import com.suning.snbc.developer.portal.dto.user.LoginUser;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

/**
 * shiro 用户名密码登录认证域实现
 * @author 17031596@cnsuning.com
 */
@Slf4j
public class UserRealm extends AuthorizingRealm {


    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
    	JSONObject loginUser  = (JSONObject) SecurityUtils.getSubject().getPrincipal();
        //为当前用户设置角色和权限
        System.out.println(loginUser.toJSONString());
//        String role = getRoleTest(loginUser);
        SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
        authorizationInfo.addRole(loginUser.getString("loginName"));
//        LoginUser loginUser  = (LoginUser) SecurityUtils.getSubject().getPrincipal();
//        //为当前用户设置角色和权限
//        SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
//        authorizationInfo.addRole(loginUser.getRole());
//        authorizationInfo.addRole("authenticated");
        return authorizationInfo;
    }

    /**
     * 验证当前登录的Subject
     * LoginController.login()方法中执行Subject.login()时 执行此方法
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authcToken) throws AuthenticationException {
        System.out.println("authcToken:"+JSONObject.toJSONString(authcToken));
    	String loginName = (String) authcToken.getPrincipal();
        String password = new String((char[]) authcToken.getCredentials());
//        LoginUser user = logonService.getLoginUser(loginName,password);
        Map user = new HashMap<String,Object>(){{
        	put("loginName",loginName);
        	put("password",password);
        }};
        return new SimpleAuthenticationInfo(JSONObject.toJSON(user), password,  getName());
    }
}
