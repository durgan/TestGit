package com.suning.snbc.developer.framework.support;

/**
 * @author 17031596@cnsuning.com
 */
public interface IntValueEnum {
    int getValue();
}
