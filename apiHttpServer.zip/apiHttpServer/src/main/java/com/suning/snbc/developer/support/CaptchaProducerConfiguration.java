package com.suning.snbc.developer.support;

import com.google.code.kaptcha.impl.DefaultKaptcha;
import com.google.code.kaptcha.util.Config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Properties;

/**
 * @author 17031596@cnsuning.com
 */
@Configuration
public class CaptchaProducerConfiguration {

    @Bean("captchaProducer")
    public DefaultKaptcha kaptchaBean(){
        DefaultKaptcha result = new DefaultKaptcha();
        Properties config = new Properties();
        config.setProperty("kaptcha.border.color","105,179,90");
        config.setProperty("kaptcha.image.width","100");
        config.setProperty("kaptcha.image.height","35");
        config.setProperty("kaptcha.textproducer.font.size","27");
        config.setProperty("kaptcha.textproducer.char.length","4");
        config.setProperty("kaptcha.textproducer.char.string","0123456789");
        result.setConfig(new Config(config));
        return result;
    }

    public static void main(String[] args) throws IOException {
        DefaultKaptcha kaptcha = new CaptchaProducerConfiguration().kaptchaBean();
        for (int i = 0; i < 20; i++) {
            System.out.println(kaptcha.createText());
        }
        BufferedImage image = kaptcha.createImage(kaptcha.createText());
        ImageIO.write(image,"jpg",new File("aaaa.jpg"));
    }

}
