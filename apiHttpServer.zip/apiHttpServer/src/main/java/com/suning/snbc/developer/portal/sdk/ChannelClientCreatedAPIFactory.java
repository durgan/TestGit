package com.suning.snbc.developer.portal.sdk;

import static org.hyperledger.fabric.sdk.BlockInfo.EnvelopeType.TRANSACTION_ENVELOPE;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Security;
import java.security.spec.InvalidKeySpecException;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.servlet.ServletContext;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.hyperledger.fabric.sdk.BlockEvent;
import org.hyperledger.fabric.sdk.BlockInfo;
import org.hyperledger.fabric.sdk.BlockListener;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.ChannelConfiguration;
import org.hyperledger.fabric.sdk.Enrollment;
import org.hyperledger.fabric.sdk.EventHub;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.Orderer;
import org.hyperledger.fabric.sdk.Peer;
import org.hyperledger.fabric.sdk.Peer.PeerEventingServiceDisconnected;
import org.hyperledger.fabric.sdk.exception.CryptoException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.exception.TransactionException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.springframework.beans.factory.annotation.Autowired;

import com.suning.snbc.developer.portal.Constants;
import com.suning.snbc.sdk.APIPeerEventingServiceDisconnected;
import com.suning.snbc.sdk.ChannelClient;
import com.suning.snbc.sdk.ChannelClientCreatedFactory;
import com.suning.snbc.sdk.ChannelClientFactory;
import com.suning.snbc.sdk.ChannelClientImpl;
import com.suning.snbc.sdk.FabricConfig;
import com.suning.snbc.sdk.FabricConfigFactory;
import com.suning.snbc.sdk.FabricException;
import com.suning.snbc.sdk.FabricOrg;
import com.suning.snbc.sdk.FabricUser;
import com.suning.snbc.sdk.bean.Chaincode;
import com.suning.snbc.sdk.event.TransactionActionInfoListener;

/**
 * channel API重新构建类。从sdk中抽离需要
 * @author binarykey
 *
 */
public class ChannelClientCreatedAPIFactory extends ChannelClientFactory{

	private static final Log logger = LogFactory.getLog(ChannelClientCreatedAPIFactory.class);

	private static final String PERIOD = "\\.";
	
	private static final String EQUAL_SIGN = "=";
	@Resource
	FabricConfigFactory fabricConfigFactory;
	@Resource
	ChannelClientFactory channelClientFactory;
	
	@Autowired
    private ServletContext servletContext;
	
	TransactionActionInfoListener transactionActionInfoListener;
	//坑 TODO
//	private boolean runningTLS = false;
//	private boolean runningFabricCATLS = runningTLS;
//	private boolean runningFabricTLS = runningTLS;
//
//	private static final String PEER = "peer";
//    private static final String GRPC = "grpc://";
//    private static final String GRPCS = "grpcs://";
    private static final String MSP = "MSP";
//    private static final String HTTP = "http://";
//    private static final String HTTPS = "https://";
//    
//    private static final String ORDERER = "orderer";
    
    /**
     * 需要启动block监听则在创建之前注入实现类
     * @param transactionActionInfoListener
     * @return
     */
    public ChannelClientFactory setTransactionActionInfoListener(TransactionActionInfoListener transactionActionInfoListener) {
        this.transactionActionInfoListener = transactionActionInfoListener;
        return this;
    }
    
//	private String grpcTLSify(String location) {
//        location = location.trim();
//        return super.getFabricConfig(). runningFabricTLS ?
//                GRPCS + location : GRPC + location;
//
//    }
	
//	public Properties getOrdererProperties(String name) {
//
//        return getEndPointProperties(ORDERER, name);
//
//    }
//    private Properties getEndPointProperties(final String type, final String name) {
//    	String baseDir = null;
//    	
//    	if (servletContext != null)
//    		baseDir = servletContext.getRealPath("/WEB-INF/classes/fabric");
//    	
//    	logger.info("baseDir:"+baseDir); 
//    	
//        String path = baseDir + "/data/tls/" + name + "_server.crt";
//        File cert = new File(path);
//        if (!cert.exists()) {
//            throw new RuntimeException(String.format("Missing cert file for: %s. Could not find at location: %s", name,
//                    cert.getAbsolutePath()));
//        }
//        Properties ret = new Properties();
//        ret.setProperty("pemFile", cert.getAbsolutePath());
//        //      ret.setProperty("trustServerCertificate", "true"); //testing environment only NOT FOR PRODUCTION!
//        ret.setProperty("hostnameOverride", name);
//        ret.setProperty("sslProvider", "openSSL");
//        ret.setProperty("negotiationType", "TLS");
//
//        return ret;
//    }
    
//    private String httpTLSify(String location) {
//        location = location.trim();
//
//        return runningFabricCATLS ?
//                HTTPS + location : HTTP + location;
//    }
    
//    public Properties getPeerProperties(String name) {
//
//        return getEndPointProperties(PEER, name);
//
//    }
    
    private File findFileSk(File directory) {
        File[] matches = directory.listFiles((dir, name) -> name.endsWith("_sk"));
        if (null == matches) {
            throw new RuntimeException(String.format("Matches returned null does %s directory exist?", directory.getAbsoluteFile().getName()));
        }
        if (matches.length != 1) {
            throw new RuntimeException(String.format("Expected in %s only 1 sk file but found %d", directory.getAbsoluteFile().getName(), matches.length));
        }
        return matches[0];
    }
    
    static PrivateKey getPrivateKeyFromBytes(byte[] data) throws IOException, NoSuchProviderException, NoSuchAlgorithmException, InvalidKeySpecException {
        final Reader pemReader = new StringReader(new String(data));

        final PrivateKeyInfo pemPair;
        try (PEMParser pemParser = new PEMParser(pemReader)) {
            pemPair = (PrivateKeyInfo) pemParser.readObject();
        }
        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
        PrivateKey privateKey = new JcaPEMKeyConverter().setProvider(BouncyCastleProvider.PROVIDER_NAME).getPrivateKey(pemPair);

        return privateKey;
    }
    
    static final class UserEnrollement implements Enrollment, Serializable {

        private static final long serialVersionUID = -6016856733490161125L;
        private final PrivateKey privateKey;
        private final String certificate;

        UserEnrollement(PrivateKey privateKey, String certificate) {
            this.certificate = certificate;
            this.privateKey = privateKey;
        }

        @Override
        public PrivateKey getKey() {
            return privateKey;
        }

        @Override
        public String getCert() {
            return certificate;
        }

    }
    
    
	
public HFClient buildChannelWithOrgPeer(String channelName,List<String> peerNames, String bOrgName){
		
		//校验peer，org参数合法性 TODO
	
	
		HFClient client = null;
		try {
        generateChannelTX(channelName);
        
		//peer构建
        FabricOrg peerOrg = generateToJoinPeerOrg(bOrgName,peerNames);
//        FabricOrg fabricOrg = fabricConfig.getFabricOrg(bOrgName);
//		FabricOrg peerOrg = new FabricOrg(bOrgName , bOrgName + MSP, fabricOrg.getDomainName(), fabricOrg.getCALocation());
//         
//         FabricUser peerOrgAdmin = new FabricUser(bOrgName + "Admin",bOrgName);
//         peerOrgAdmin.setMspId(peerOrg.getMSPID());
//         peerOrg.setPeerAdmin(peerOrgAdmin); //A special user that can create channels, join peers and install chaincode
//         File privateKeyFile = findFileSk(new File(getFabricConfig().getChannelArtifactsPath() + "/data/orgs/" + bOrgName + "/admin/msp/keystore"));
//         File certificateFile = new File(getFabricConfig().getChannelArtifactsPath() + "/data/orgs/" + bOrgName + "/admin/msp/signcerts/cert.pem");
//         String certificate = new String(IOUtils.toByteArray(new FileInputStream(certificateFile)), "UTF-8");
//         PrivateKey privateKey = getPrivateKeyFromBytes(IOUtils.toByteArray(new FileInputStream(privateKeyFile)));
//         peerOrgAdmin.setEnrollment(new UserEnrollement(privateKey, certificate));
//         
//        for(String bPeerName:peerNames){
////   		 String peerName = "peer1.org1.cnsuning.com";
//        	String peerName = bPeerName+"."+bOrgName+".cnsuning.com";
//            peerOrg.addPeerLocation(peerName, fabricOrg.getPeerLocation(peerName));
//            peerOrg.addPeerProperties(peerName, fabricOrg.getPeerProperties(peerName));
//        }
		
         
        client = createChannel(channelName, fabricConfig.getFabricOrg(Constants.ORDEERORG), peerOrg);
		}catch(Exception e){
			throw new FabricException(e.getMessage(), e);
		}
		return client;
		
	}
	

	/**
	 * 构建待加入的peer节点
	 * @param bOrgName
	 * @param peerNames
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws NoSuchProviderException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 */
	private FabricOrg generateToJoinPeerOrg(String bOrgName,List<String> peerNames) throws UnsupportedEncodingException, FileNotFoundException, IOException, NoSuchProviderException, NoSuchAlgorithmException, InvalidKeySpecException{
		
		FabricOrg fabricOrg = fabricConfig.getFabricOrg(bOrgName);
		FabricOrg peerOrg = new FabricOrg(bOrgName , bOrgName + MSP, fabricOrg.getDomainName(), fabricOrg.getCALocation());
         
         FabricUser peerOrgAdmin = new FabricUser(bOrgName + "Admin",bOrgName);
         peerOrgAdmin.setMspId(peerOrg.getMSPID());
         peerOrg.setPeerAdmin(peerOrgAdmin); //A special user that can create channels, join peers and install chaincode
         File privateKeyFile = findFileSk(new File(getFabricConfig().getChannelArtifactsPath() + "/data/orgs/" + bOrgName + "/admin/msp/keystore"));
         File certificateFile = new File(getFabricConfig().getChannelArtifactsPath() + "/data/orgs/" + bOrgName + "/admin/msp/signcerts/cert.pem");
         String certificate = new String(IOUtils.toByteArray(new FileInputStream(certificateFile)), "UTF-8");
         PrivateKey privateKey = getPrivateKeyFromBytes(IOUtils.toByteArray(new FileInputStream(privateKeyFile)));
         peerOrgAdmin.setEnrollment(new UserEnrollement(privateKey, certificate));
         
        for(String bPeerName:peerNames){
//   		 String peerName = "peer1.org1.cnsuning.com";
        	String peerName = bPeerName+"."+bOrgName+".cnsuning.com";
            peerOrg.addPeerLocation(peerName, fabricOrg.getPeerLocation(peerName));
            peerOrg.addPeerProperties(peerName, fabricOrg.getPeerProperties(peerName));
        }
        
		return peerOrg;
		
	}
	
	private FabricOrg generateToJoinPeer(String bOrgName,String toJoinPeerStr) throws UnsupportedEncodingException, FileNotFoundException, IOException, NoSuchProviderException, NoSuchAlgorithmException, InvalidKeySpecException{
		
//		peer1.org1.cnsuning.com = 10.37.218.11:7051
				
//		FabricOrg fabricOrg = fabricConfig.getFabricOrg(bOrgName);
		String[] keyValue = toJoinPeerStr.split(EQUAL_SIGN);
		//rca.org0.cnsuning.com = 10.37.218.11:7054
		String[] org = keyValue[0].trim().split(PERIOD);
        String doMainName = keyValue[0].trim().substring(org[0].length());
        String caLocation = fabricConfigFactory.httpTLSify(keyValue[1].trim());
        
        
		FabricOrg peerOrg = new FabricOrg(bOrgName , bOrgName + MSP, doMainName, caLocation);
         
		String peerName = keyValue[0].trim();
        String peerLocation = fabricConfigFactory.grpcTLSify(keyValue[1].trim());
        Properties peerProperties = fabricConfigFactory.getPeerProperties(peerName);
//    	String peerName = bPeerName+"."+bOrgName+".cnsuning.com";
        peerOrg.addPeerLocation(peerName, peerLocation);
        peerOrg.addPeerProperties(peerName, peerProperties);
        
        
		return peerOrg;
		
	}
	
	
	 private void generateChannelTX(String channelName) throws IOException, InterruptedException {
	        String baseDir = getFabricConfig().getChannelArtifactsPath();
	        String txpath = baseDir + "make_tx.sh";
	        String configtxgen = baseDir + "configtxgen";
	        //修改可执行权限
	        String[] commend3 = {"chmod", "+x", txpath};
	        execute(commend3);
	        String[] commend4 = {"chmod", "+x", configtxgen};
	        execute(commend4);
	        //生成文件
	        String[] commend = {txpath, channelName};
	        execute(commend);

	    }
	 
	 private HFClient createChannel(String channelName, com.suning.snbc.sdk.FabricOrg ordererOrg, com.suning.snbc.sdk.FabricOrg peerOrg) throws CryptoException, InvalidArgumentException, TransactionException, IOException, ProposalException, IllegalAccessException, InstantiationException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException {

	        HFClient client = HFClient.createNewInstance();

	        client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite()); 


	        client.setUserContext(peerOrg.getPeerAdmin());

	        Collection<Orderer> orderers = new LinkedList<>();

	        for (String orderName : ordererOrg.getOrdererNames()) {
	            Properties ordererProperties = ordererOrg.getOrdererProperties(orderName);
	            ordererProperties.put("grpc.NettyChannelBuilderOption.keepAliveTime", new Object[]{5L, TimeUnit.MINUTES});
	            ordererProperties.put("grpc.NettyChannelBuilderOption.keepAliveTimeout", new Object[]{8L, TimeUnit.SECONDS});
	            orderers.add(client.newOrderer(orderName, ordererOrg.getOrdererLocation(orderName),
	                    ordererProperties));
	        }

	        Orderer anOrderer = orderers.iterator().next();
	        orderers.remove(anOrderer);
	        ChannelConfiguration channelConfiguration = new ChannelConfiguration(new File(getFabricConfig().getChannelArtifactsPath() + "data/" + channelName + ".tx"));

	        //Create channel that has only one signer that is this orgs peer admin. If channel creation policy needed more signature they would need to be added too.
	        Channel newChannel = client.newChannel(channelName, anOrderer, channelConfiguration, client.getChannelConfigurationSignature(channelConfiguration, peerOrg.getPeerAdmin()));
//	        Channel newChannel = client.newChannel(channelName);

	        for (String peerName : peerOrg.getPeerNames()) {
	            String peerLocation = peerOrg.getPeerLocation(peerName);

	            Properties peerProperties = peerOrg.getPeerProperties(peerName); //test properties for peer.. if any.
	            if (peerProperties == null) {
	            	logger.error("没有加入的组织-------------------");
	            	
	            	continue;
//	                peerProperties = new Properties();
	            }
	            //Example of setting specific options on grpc's NettyChannelBuilder
	            peerProperties.put("grpc.NettyChannelBuilderOption.maxInboundMessageSize", 9000000);

	            Peer peer = client.newPeer(peerName, peerLocation, peerProperties);
	            PeerEventingServiceDisconnected newPeerEventingServiceDisconnectedHandler = new APIPeerEventingServiceDisconnected();
	            peer.setPeerEventingServiceDisconnected(newPeerEventingServiceDisconnectedHandler);
	            peer.setPeerEventingServiceDisconnected(null);
	            newChannel.joinPeer(peer);
//	            newChannel.addPeer(peer);
	            peerOrg.addPeer(peer);
	        }

	        for (Orderer orderer : orderers) { //add remaining orderers if any.
	            newChannel.addOrderer(orderer);
	        }

	        for (String eventHubName : peerOrg.getEventHubNames()) {

	            final Properties eventHubProperties = peerOrg.getEventHubProperties(eventHubName);
	            eventHubProperties.put("grpc.NettyChannelBuilderOption.keepAliveTime", new Object[]{5L, TimeUnit.MINUTES});
	            eventHubProperties.put("grpc.NettyChannelBuilderOption.keepAliveTimeout", new Object[]{8L, TimeUnit.SECONDS});
	            EventHub eventHub = client.newEventHub(eventHubName, peerOrg.getEventHubLocation(eventHubName),
	                    eventHubProperties);
	            newChannel.addEventHub(eventHub);
	        }
	        newChannel.initialize();
//	       registerBlockListener(newChannel);
	       return client;
	    }
	 
	 private void execute(String[] commend) throws IOException, InterruptedException {
	        Process pro = Runtime.getRuntime().exec(commend);
	        pro.waitFor();
	        InputStream in = pro.getInputStream();
	        BufferedReader read = new BufferedReader(new InputStreamReader(in));
	        String result = read.readLine();
	    }
	 
	 void registerBlockListener(Channel channel) {
	        if (transactionActionInfoListener != null) {
	                    try {
	                        channel.registerBlockListener(
	                                new BlockListener() {
	                                    @Override
	                                    public void received(BlockEvent event) {
	                                        for (BlockInfo.EnvelopeInfo envelopeInfo : event.getEnvelopeInfos()) {
	                                            if (envelopeInfo.isValid() && envelopeInfo.getType() == TRANSACTION_ENVELOPE) {
	                                                BlockInfo.TransactionEnvelopeInfo transactionEnvelopeInfo = (BlockInfo.TransactionEnvelopeInfo) envelopeInfo;
	                                                for (BlockInfo.TransactionEnvelopeInfo.TransactionActionInfo transactionActionInfo : transactionEnvelopeInfo.getTransactionActionInfos()) {
	                                                    transactionActionInfoListener.doAction(transactionActionInfo);
	                                                }
	                                            }
	                                        }
	                                    }
	                                });
	                    } catch (InvalidArgumentException e) {
	                        e.printStackTrace();
	                    }
	                }
	        }

	 
	 
	public void joinPeers(String channelName, String orgName, String toJoinPeerStr) throws UnsupportedEncodingException, FileNotFoundException, NoSuchProviderException, NoSuchAlgorithmException, InvalidKeySpecException, IOException, InvalidArgumentException, ProposalException {
//		List<String> peerNameList = Arrays.asList(peerNames);
		FabricOrg peerOrg = generateToJoinPeer(orgName,toJoinPeerStr);
//		FabricOrg peerOrg = fabricConfig.getFabricOrg(orgName);
		ChannelClient buildChannelClient = channelClientFactory.buildChannelClient(channelName, "fff");
		 buildChannelClient.joinPeer(peerOrg);
	}

	public void joinPeers(String channelName, String[] peerNames, String orgName) throws InvalidArgumentException, ProposalException {
		FabricOrg peerOrg = fabricConfig.getFabricOrg(orgName);
		ChannelClient buildChannelClient = channelClientFactory.buildChannelClient(channelName, "fff");
		 buildChannelClient.joinPeer(peerOrg);
	}
	 

}
