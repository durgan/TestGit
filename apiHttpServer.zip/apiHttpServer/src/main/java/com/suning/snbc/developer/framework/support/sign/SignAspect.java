package com.suning.snbc.developer.framework.support.sign;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSONObject;
import com.suning.snbc.developer.framework.support.FieldInvalidException;
import com.suning.snbc.developer.framework.support.JsonRequest;
import com.suning.snbc.developer.portal.Constants;
import com.suning.snbc.developer.portal.ResultCode;
import com.suning.snbc.developer.support.BusinessException;
import com.suning.snbc.developer.util.AESUtil;
import com.suning.snbc.developer.util.SignUtil;

/**
 * 
* Description: 签名拦截校验
* Title: SignAspect.java
* @author 88399341 - jiang
* @date 2018-09-28 16:37
 */
@Aspect
@Component
public class SignAspect {

	@Resource
    private SecretConfigFactory secretConfigFactory;
	
	@Pointcut("execution (* com.suning.snbc.developer.portal.controller..*.*(..))")
	public void controllerAspect() {

	}

	@Around("controllerAspect()")
	public Object Interceptor(ProceedingJoinPoint pjp) throws Throwable {
		// 取自定义注解
		Method method = ((MethodSignature) pjp.getSignature()).getMethod();
		Method realMethod = pjp.getTarget().getClass().getDeclaredMethod(pjp.getSignature().getName(),
				method.getParameterTypes());
		Annotation an = method.getAnnotation(signRole.class);
		String action = "";
		if (an instanceof signRole) {
			signRole myAnno = (signRole) an;
			action = myAnno.roles();
			System.out.println("value: " + action);
		}

		Object result = null;
		if (action.equals("")) {
			result = pjp.proceed();
		} else {
			Object[] args = pjp.getArgs();
			System.out.println(JSONObject.toJSONString(args[0]));
			JsonRequest paramMap = (JsonRequest) args[0];
			Map<String, Object> allMap = paramMap.getMap();
			
			checkArgExsit(allMap,Constants.ARG_SIGN);
			checkArgExsit(allMap,Constants.ARG_APPKEY);
			checkArgExsit(allMap,Constants.ARG_TIMESTAMP);
			
			String sign = paramMap.getString(Constants.ARG_SIGN);
			String appkey = paramMap.getString(Constants.ARG_APPKEY);
			String timestamp = paramMap.getString(Constants.ARG_TIMESTAMP);
			
			
			//校验接口角色访问权限 
			//appley第一位标识用户类型
			String role = Constants.ARG_ROLE_CLIENT;
			checkAppkeyValiable(appkey);
			String roleMark = appkey.substring(0, 1);
			if(roleMark.equals(Constants.ARG_ROLEMARK_BAAS)){
				role = Constants.ARG_ROLE_BAAS;
			}
			String[] requiredRoles = action.split(",");
			boolean haRule = false;
			for (String r : requiredRoles) {
				if (role.equals(r)) {
					haRule = true;
					break;
				}
			}
			if (!haRule) {
				throw new BusinessException(role + "没有权限访问该接口!");
			}
			
			
			//校验时效性
			CheckTimeAvablie(timestamp);
			String appSecret = getAppSecret(appkey);
			
			//获取除sign以外的所有参数并进行签名
			Map<String,String> toSignParam = new HashMap<String,String>();
			for(Entry<String, Object> entry:allMap.entrySet()){
				String eKey = entry.getKey();
				Object eValue = entry.getValue();
				if(eKey.equals(Constants.ARG_SIGN))
					continue;
				
//				if (eValue.getClass().isPrimitive()||eValue instanceof String) {
//					toSignParam.put(eKey, String.valueOf(eValue));
//	            } else 
				
//				目前考虑数组与基本能转换成String的类型,后期出现其他位置类型再补充
	            if(eValue.getClass().isArray()){
	            	//数组要拆分，并用|分割拼接
	            	Object[] pA = (Object[]) eValue;
	            	if(pA.length==0)
	            		continue;
	            	
	            	StringBuilder sb = new StringBuilder();
	            	for(Object o:pA){
	            		sb.append("|").append(String.valueOf(o));
	            	}
	            	String rStr = sb.toString().replaceFirst("\\|", "");
	            	toSignParam.put(eKey, rStr);
	            }else if(eValue instanceof ArrayList){
	            	ArrayList pA = (ArrayList) eValue;
	            	if(pA.size()==0)
	            		continue;
	            	
	            	StringBuilder sb = new StringBuilder();
	            	for(Object o:pA){
	            		sb.append("|").append(String.valueOf(o));
	            	}
	            	String rStr = sb.toString().replaceFirst("\\|", "");
	            	toSignParam.put(eKey, rStr);
	            }else{
	            	toSignParam.put(eKey, String.valueOf(eValue));
	            }
			}
			
			//获取预期签名
			String goalSign = SignUtil.createSign(toSignParam, appSecret);
			if(!goalSign.equals(sign)){
				throw new BusinessException(ResultCode.SERVER_ERROR,"签名校验有误，请查看签名流程。");
			}else{
				result = pjp.proceed();
			}

		}

		return result;
	}

    public static void main(String[] args) {
		System.out.println("|jzw1".replaceFirst("\\|", ""));
	}
	/**
	 * 校验appkey合法性
	 * @param appkey
	 */
	private void checkAppkeyValiable(String appkey) {
		String roleMark = appkey.substring(0, 1);
		if(!roleMark.equals(Constants.ARG_ROLEMARK_BAAS)&&!roleMark.equals(Constants.ARG_ROLEMARK_CLIENT))
			throw new BusinessException(ResultCode.SERVER_ERROR,"appkey格式非法！");
		
	}

	/**
	 * 根据appkey获取API server存储的appsecret
	 * @param appkey
	 * @return
	 */
	private String getAppSecret(String appkey) {
		String secret = null;
		try {
			HashMap<String, String> keysecretMap = secretConfigFactory.getSecretConfig().getKeySecretMap();
			secret = keysecretMap.get(appkey);
		} catch (IOException e) {
			e.printStackTrace();
			throw new BusinessException(ResultCode.SERVER_ERROR,"获取appsecret失败!");
		}
		
		if(StringUtils.isEmpty(secret)){
			throw new BusinessException(ResultCode.SERVER_ERROR,"不存在该appkey对应的secret！请查看配置！");
		}
		return secret;
	}

	/**
	 * 校验时效性 5分钟内有效确保唯一性。如有必要，后期加入norce随机字符串
	 * @param timestamp
	 */
	private void CheckTimeAvablie(String timestamp) {
//		long oldTime = Long.valueOf(timestamp);
//		long nowTime = new Date().getTime();
//		long timespace = nowTime-oldTime;
//		if(timespace>Constants.EXPTIME_MIN*60*1000){
//			throw new BusinessException(ResultCode.SERVER_ERROR,"接口调用超时或已经被调用过。");
//		}
	}

	/**
	 * 校验参数是否存在
	 * @param allMap
	 * @param argSign
	 */
	private void checkArgExsit(Map<String, Object> allMap, String argSign) {
		if(!allMap.containsKey(argSign)||StringUtils.isEmpty(String.valueOf(allMap.get(argSign)))){
			throw new FieldInvalidException(argSign, "不存在");
		}
		
	}
}
