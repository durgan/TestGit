package com.suning.snbc.developer.portal.service;
//
import com.baomidou.mybatisplus.plugins.Page;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.suning.snbc.developer.framework.support.PageQuery;
import com.suning.snbc.developer.framework.support.SimpleMap;
import com.suning.snbc.developer.portal.config.AppConfiguration;
import com.suning.snbc.developer.portal.constant.enumValue.Constants;
import com.suning.snbc.developer.portal.controller.ChainCodeController;
import com.suning.snbc.developer.portal.dto.user.*;
//import com.suning.snbc.developer.portal.entity.Organization;
import com.suning.snbc.developer.support.*;
import com.suning.snbc.developer.util.DerbyUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.suning.snbc.sdk.ChannelClient;
import com.suning.snbc.sdk.ChannelClientCreatedFactory;
import com.suning.snbc.sdk.ChannelClientFactory;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.shiro.SecurityUtils;
import org.hyperledger.fabric.sdk.BlockInfo;
import org.hyperledger.fabric.sdk.BlockchainInfo;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.SDKUtils;
import org.hyperledger.fabric.sdk.exception.CryptoException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
//
import javax.annotation.Resource;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.hyperledger.fabric.sdk.BlockInfo.EnvelopeType.TRANSACTION_ENVELOPE;
//
@Service("sdkService")
public class SDKService {
	private static final Log logger = LogFactory.getLog(SDKService.class);
//    @Resource(name = "channelClientCreatedFactory")
//    private ChannelClientCreatedFactory channelClientCreatedFactory;
//    @Resource
//    private ChannelClientFactory channelClientFactory;
//
////    @Resource
////    private OrganizationRepository organizationRepository;
//
//    @Resource
//    private AppConfiguration appConfiguration;
////    @Resource(name = "commonChannel")
////    private ChannelClient commonChannel;
//    @Value("${fabric.org.id}")
//    private String orgId;
//
//    public Page<TransatcionVO> queryTransactionByPage(String channelName, String transactionHash, int pageNum, int pageSize) {
//        Channel channel = getChannelByName(channelName, queryChaincodeName(channelName));
//        Page<TransatcionVO> result = new Page<>();
//        try {
//            List<TransatcionVO> trans = getTransactions(channel, transactionHash, 100);
//            //Integer pages = (trans.size()+1)/pageSize;
//            List<TransatcionVO> pageTrans = RAMPageService.page(trans, pageNum, pageSize);
//            result.setTotal(trans.size());
//            result.setRecords(pageTrans);
//            return result;
//        } catch (Exception e) {
//            throw new BusinessException(e.getMessage());
//        }
//    }
//
//    public Channel getChannelByName(String channelName, String chanincodeName) {
//
//        ChannelClient channelClient = channelClientFactory.buildChannelClient(channelName, chanincodeName);
//        Channel channel = channelClient.getNativeChannel();
//        return channel;
//    }
//
//    private String queryChaincodeName(String channelName) {
//        String query = FindQueryBuilder.begin(ChannelVO.DOC_TYPE).eq("channelName", channelName).build();
//        byte[] result = commonChannel.query("customeQuery", byte[].class, query);
//        ArrayNode jsonNodes = (ArrayNode) JsonaUtils.toJsonNode(result);
//        ChannelVO channel = null;
//        String[] chainCodeId = null;
//        if (jsonNodes != null && jsonNodes.size() > 0) {
//            for (JsonNode jsonNode : jsonNodes) {
//                channel = JsonaUtils.recordJsonToObject(jsonNode, ChannelVO.class);
//                chainCodeId = channel.getChainCodeId() == null ? new String[]{} : channel.getChainCodeId().split("_");
//            }
//        }
//        if (chainCodeId != null && chainCodeId.length == 3) {
//            return chainCodeId[1];
//        }
//        return null;
//    }
//
//    
//    /**
//     * Hex.encodeHexString 方法需要的HFclient
//     * @return
//     * @throws CryptoException
//     * @throws InvalidArgumentException
//     * @throws IllegalAccessException
//     * @throws InstantiationException
//     * @throws ClassNotFoundException
//     * @throws NoSuchMethodException
//     * @throws InvocationTargetException
//     */
//    private HFClient getSDKUtilsHFClient(){
//    	HFClient client = HFClient.createNewInstance();
//
//        try {
//			client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
//		} catch (CryptoException | InvalidArgumentException | IllegalAccessException | InstantiationException
//				| ClassNotFoundException | NoSuchMethodException | InvocationTargetException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        
//        return client;
//    }
//    
//    /**
//     * 获取 前NUM个 Block 的Trasactions
//     */
//    public List<TransatcionVO> getTransactions(Channel channel, String transactionHash, long num) throws InvalidArgumentException, ProposalException, IOException {
//        if (num <= 0) {
//            num = 100;
//        }
//        BlockchainInfo channelInfo = channel.queryBlockchainInfo();
//        List<TransatcionVO> trasatcionList = new ArrayList<TransatcionVO>();
//        for (long current = channelInfo.getHeight() - 1; current > current - num; --current) {
//            if (current < 0) break;
//            BlockInfo returnedBlock = channel.queryBlockByNumber(current);
//            final long blockNumber = returnedBlock.getBlockNumber();
//            String blockHash = Hex.encodeHexString(SDKUtils.calculateBlockHash(getSDKUtilsHFClient(),blockNumber, returnedBlock.getPreviousHash(), returnedBlock.getDataHash()));
//            for (BlockInfo.EnvelopeInfo envelopeInfo : returnedBlock.getEnvelopeInfos()) {
//
//                if(StringUtils.isNotEmpty(transactionHash) &&
//                        !transactionHash.equals(envelopeInfo.getTransactionID())){
//                    continue;
//                }
//
//                TransatcionVO vo = new TransatcionVO();
//                vo.setBlockHash(blockHash).setBlockNum(blockNumber);
//                vo.setBlockNum(blockNumber);
//                vo.setTransactionID(envelopeInfo.getTransactionID());
//                vo.setCreateTime(DateUtil.DateToString(envelopeInfo.getTimestamp(), DateStyle.YYYY_MM_DD_HH_MM));
//                if (StringUtils.isNotEmpty(vo.getTransactionID())) {
//                    //如果trancId 为空不添加（0 blockNum）
//                    trasatcionList.add(vo);
//                }
//            }
//        }
//        return trasatcionList;
//    }
//
//
//    public Page<BlockVO> queryBlockByPage(String channelName, String blockParam, int pageNum, int pageSize) {
//        Channel channel = getChannelByName(channelName, queryChaincodeName(channelName));
//        Page<BlockVO> result = new Page<>();
//        try {
//            List<BlockVO> trans = getBlocks(channel, blockParam, 100);
//            //Integer pages = (trans.size()+1)/pageSize;
//            List<BlockVO> pageBlocks = RAMPageService.page(trans, pageNum, pageSize);
//            result.setTotal(trans.size());
//            result.setRecords(pageBlocks);
//            return result;
//        } catch (Exception e) {
//            throw new BusinessException(e.getMessage());
//        }
//    }
//
//    /**
//     * 获取 前NUM个 Block
//     */
//    public List<BlockVO> getBlocks(Channel channel, String blockParam, long num) throws InvalidArgumentException, ProposalException, IOException {
//        if (num <= 0) {
//            num = 100;
//        }
//        BlockchainInfo channelInfo = channel.queryBlockchainInfo();
//        List<BlockVO> blockList = new ArrayList<BlockVO>();
//        for (long current = channelInfo.getHeight() - 1; current > current - num; --current) {
//            if (current < 0) break;
//            BlockVO vo = new BlockVO();
//            BlockInfo returnedBlock = channel.queryBlockByNumber(current);
//            final long blockNumber = returnedBlock.getBlockNumber();
//            final int envelopeCount = returnedBlock.getEnvelopeCount();
//            String dataHash = Hex.encodeHexString(returnedBlock.getDataHash());
//            String preHash = Hex.encodeHexString(returnedBlock.getPreviousHash());
//            String blockHash = Hex.encodeHexString(SDKUtils.calculateBlockHash(getSDKUtilsHFClient(),blockNumber, returnedBlock.getPreviousHash(), returnedBlock.getDataHash()));
//
//            if(StringUtils.isNotEmpty(blockParam) &&
//                    !blockParam.equals(blockNumber+"") && !blockParam.equals(blockHash)){
//                continue;
//            }
//
//            vo.setBlockNum(blockNumber).setBlockHash(blockHash).setDataHash(dataHash).setPreHash(preHash).setTrasNum(envelopeCount).setChannelId(returnedBlock.getChannelId());
//            if (envelopeCount > 0) {
//                BlockInfo.EnvelopeInfo info = returnedBlock.getEnvelopeInfo(envelopeCount - 1);
//                vo.setCreateTime(DateUtil.DateToString(info.getTimestamp(), DateStyle.YYYY_MM_DD_HH_MM_SS));
//            }
//            blockList.add(vo);
//        }
//        return blockList;
//    }
//
//    public Page<TransatcionVO> queryBlockTransactionByPage(String channelName, long blockNum, int pageNum, int pageSize) {
//        Channel channel = getChannelByName(channelName, queryChaincodeName(channelName));
//        Page<TransatcionVO> result = new Page<>();
//        try {
//            List<TransatcionVO> trans = getTransactionsByBlockNum(channel, blockNum);
//            // Integer pages = (trans.size()+1)/pageSize;
//            List<TransatcionVO> pageTrans = RAMPageService.page(trans, pageNum, pageSize);
//            result.setTotal(trans.size());
//            result.setRecords(pageTrans);
//            return result;
//        } catch (Exception e) {
//            throw new BusinessException(e.getMessage());
//        }
//    }
//
//    /**
//     * 根据BlockNum  获取当前区块的所有交易信息
//     */
//    public List<TransatcionVO> getTransactionsByBlockNum(Channel channel, long blockNum) throws InvalidArgumentException, ProposalException, IOException {
//        List<TransatcionVO> trasatcionList = new ArrayList<TransatcionVO>();
//        BlockInfo blockInfo = channel.queryBlockByNumber(blockNum);
//        final long blockNumber = blockInfo.getBlockNumber();
//        String blockHash = Hex.encodeHexString(SDKUtils.calculateBlockHash(getSDKUtilsHFClient(),blockNumber, blockInfo.getPreviousHash(), blockInfo.getDataHash()));
////        arg不是string类型的type
//        Set<String> argNotStrSet = new HashSet<String>(){
//            {
//                add("deploy");
//                add("upgrade");
//                add("init");
//            }
//        };
//
//        for (BlockInfo.EnvelopeInfo envelopeInfo : blockInfo.getEnvelopeInfos()) {
//            TransatcionVO vo = new TransatcionVO();
//            vo.setBlockHash(blockHash);
//            vo.setBlockNum(blockNumber);
//            vo.setTransactionID(envelopeInfo.getTransactionID());
//            vo.setCreateTime(DateUtil.DateToString(envelopeInfo.getTimestamp(), DateStyle.YYYY_MM_DD_HH_MM));
//            if (envelopeInfo.getType() == TRANSACTION_ENVELOPE) {
//                BlockInfo.TransactionEnvelopeInfo transactionEnvelopeInfo = (BlockInfo.TransactionEnvelopeInfo) envelopeInfo;
//                transactionEnvelopeInfo.getValidationCode();
//                for (BlockInfo.TransactionEnvelopeInfo.TransactionActionInfo transactionActionInfo : transactionEnvelopeInfo.getTransactionActionInfos()) {
//                    String args = "";
//                    String type = "";
//                    for (int z = 0; z < transactionActionInfo.getChaincodeInputArgsCount(); ++z) {
//                        byte[] argArr = transactionActionInfo.getChaincodeInputArgs(z);
//                        String arg = new String(argArr, "UTF-8");
//                        if(z==0){
//                            type = arg;
//                        }
//                        if (z==2&&argNotStrSet.contains(type)){
//                            break;
//                        }
////                        if (z==2&&(type.equals("upgrade")||type.equals("init"))){
////                            String[] sa = bytesToHexStrings(argArr);
////                            arg =  JSONObject.toJSONString(sa);
////                        }
//                        args = args + "," + arg;
//                    }
//                    vo.setChainCodeArgs(StringUtils.removeFirst(args, ","));
//                }
//            }
//            if (vo.getChainCodeArgs()==null){vo.setChainCodeArgs("");}
//            trasatcionList.add(vo);
//        }
//        return trasatcionList;
//    }
//
//
//    public Map create(String channelName, String partners) {
//        ChannelVO channelVO = getChannelByName(channelName);
//        if (channelVO != null) {
//            throw new BusinessException("通道名已存在，请重新输入！");
//        }
//        createChannel(channelName, partners, 1);//创建正式通道
//
//        createChannel(Constants.getTestChannelName(channelName), partners, 2);//前缀为test的测试通道
//        return new SimpleMap("message", "通道创建成功");
//    }
//
////    public ChannelVO getChannelByName(String channelName) {
////        String query = FindQueryBuilder.begin(ChannelVO.DOC_TYPE)
////                .eq("channelName", channelName).build();
////        byte[] bytes = commonChannel.query("customeQuery", byte[].class, query);
////
////        return JsonaUtils.singleRecordJsonToObject(bytes, ChannelVO.class);
////    }
//
//    private void createChannel(String channelName, String partners, int initChannnelStatus) {
//
//        channelClientCreatedFactory.buildChannelClient(channelName, "test");
//
//        ChannelVO channelVO = new ChannelVO();
//        channelVO.setChannelName(channelName);
//        channelVO.setGmtCreate(new Date());
//        channelVO.setId(channelName);
//        channelVO.setStatus(initChannnelStatus);
//        commonChannel.invoke("set", byte[].class, channelVO.getId(), JsonUtils.objecToJson(channelVO));
//
//        ChannelMapOrgVO channelMapOrgVO = new ChannelMapOrgVO();
//        channelMapOrgVO.setChannelId(channelVO.getId());
//        channelMapOrgVO.setChannelName(channelVO.getId());
//        channelMapOrgVO.setId(Helper.uuid());
//        channelMapOrgVO.setRegisterTime(new Date());
//        channelMapOrgVO.setOrgId(appConfiguration.getFabricOrgId());
//        channelMapOrgVO.setStatus(1);
//        commonChannel.invoke("set", byte[].class, channelMapOrgVO.getId(), JsonUtils.objecToJson(channelMapOrgVO));
//
//        if (partners != null && !"".equals(partners)) {
//            List partnerList = JSON.parseArray(partners);
//            if (partnerList != null && partnerList.size() > 0) {
////                createInviteOrg(channelName, partnerList);
//            }
//        }
//    }
//
////    private Map createInviteOrg(String channelName, List partnerList) {
////        ChannelMapOrgVO channelMapOrgVO = null;
////        MessageVO messageVO = null;
////        List<Map> partnerOrgList = partnerOrgs(channelName, 0);
////        if (partnerList != null && partnerList.size() > 0) {
////            for (Object partner : partnerList) {
////                if (partner != null) {
////
////                    String inviteOrgId = partner.toString();
////                    if ("".equals(inviteOrgId)) {
////                        throw new BusinessException("邀请失败，请先选择所邀请的组织！");
////                    }
////
////                    if (partnerOrgList != null && partnerOrgList.size() > 0) {
////                        for (Map partnerOrg : partnerOrgList) {
////                            String orgId = partnerOrg.get("orgId") + "";
////                            if (orgId != null && inviteOrgId.equals(orgId)) {
////                                break;
////                            }
////                        }
////                    }
////
////                    //保存正式通道邀请信息
////                    channelMapOrgVO = new ChannelMapOrgVO();
////                    channelMapOrgVO.setChannelId(channelName);
////                    channelMapOrgVO.setChannelName(channelName);
////                    channelMapOrgVO.setId(Helper.uuid());
////                    channelMapOrgVO.setOrgId(inviteOrgId);
////                    channelMapOrgVO.setStatus(0);
////                    commonChannel.invoke("set", byte[].class, channelMapOrgVO.getId(), JsonUtils.objecToJson(channelMapOrgVO));
////
////                    //发送消息
//////                    if (!channelName.startsWith("test")) {
//////                        LoginUser loginUser = (LoginUser) SecurityUtils.getSubject().getPrincipal();
//////                        messageVO = new MessageVO();
//////                        messageVO.setId(Constants.getMessageId(channelMapOrgVO.getOrgId()));
//////                        messageVO.setSender(loginUser.getOrganizationName());
//////                        messageVO.setStatus(0);
//////                        messageVO.setSummary(MessageUtil.getInviteOrgMsg(channelName));
//////                        messageVO.setType(Constants.MESSAGE_CHANNEL_INVITE);
//////                        messageVO.setReceiver(channelMapOrgVO.getOrgId());
//////                        commonChannel.invoke("set", byte[].class, messageVO.getId(), JsonUtils.objecToJson(messageVO));
//////                    }
////
////                }
////            }
////            return new SimpleMap("message", "邀请成功！");
////        } else {
////            throw new BusinessException("邀请失败,请先选择邀请组织！");
////        }
////    }
//
//
//
//    public Page queryByPage(Integer current, Integer size) {
//        Page result = new Page<>();
//        ChannelVO channel;
//        //根据orgid查询channelName
//        Set<String> channelNameOrg = getChannelNameByOrgId();
//        System.out.println("channelNameOrg" + JSONObject.toJSONString(channelNameOrg));
//        //根据channelName筛选查询条件
//
//        String query = FindQueryBuilder.begin(ChannelVO.DOC_TYPE).build();
//        byte[] bytes = commonChannel.query("customeQuery", byte[].class, query);
//        ArrayNode jsonNodes = (ArrayNode) JsonaUtils.toJsonNode(bytes);
//        Map<String, DisplayChannelVO> displayChannelMap = new HashMap<>();
//
//
//        query = FindQueryBuilder.begin(ChannelMapOrgVO.DOC_TYPE).build();
//        byte[] customeQueries = commonChannel.query("customeQuery", byte[].class, query);
//        ArrayNode orgNodes = (ArrayNode) JsonaUtils.toJsonNode(customeQueries);
//
//        query = FindQueryBuilder.begin(ChainMapOrg.DOC_TYPE).eq("org", appConfiguration.getFabricOrgId()).build();
//        byte[] chainMapOrgQueries = commonChannel.query("customeQuery", byte[].class, query);
//        ArrayNode chainMapOrgNodes = (ArrayNode) JsonaUtils.toJsonNode(chainMapOrgQueries);
//
//        if (jsonNodes == null || jsonNodes.size() == 0 ||
//                orgNodes == null || orgNodes.size() == 0) {
//            return result;
//        }
//        List orgOwnList = new ArrayList();
//        Map<String, Integer> orgMaps = new HashMap<>();
//
//        for (JsonNode orgNode : orgNodes) {
//            ChannelMapOrgVO channelMapOrgVO = JsonaUtils.recordJsonToObject(orgNode, ChannelMapOrgVO.class);
//            String channelName = null;
//            if (channelMapOrgVO != null) {
//                channelName = channelMapOrgVO.getChannelName();
//            }
//            if (channelMapOrgVO != null && !channelName.startsWith("test")) {
//                Integer orgNum = orgMaps.get(channelName);
//                if (orgNum == null) {
//                    orgMaps.put(channelName, 1);
//                } else {
//                    orgMaps.put(channelName, orgNum + 1);
//                }
//            }
//            if (channelMapOrgVO != null) {
//                String orgId = channelMapOrgVO.getOrgId();
//                if (appConfiguration.getFabricOrgId() != null && appConfiguration.getFabricOrgId().equals(orgId) && channelMapOrgVO.getStatus() != null && channelMapOrgVO.getStatus() == 1) {
//                    orgOwnList.add(channelMapOrgVO.getChannelName());
//                }
//            }
//        }
//
//
//        for (JsonNode jsonNode : jsonNodes) {
//            channel = JsonaUtils.recordJsonToObject(jsonNode, ChannelVO.class);
//            if (channel != null) {
//                String channelName = channel.getChannelName();
//
//                if (!orgOwnList.contains(channelName)) {
//                    continue;
//                }
//
//                if (!channelNameOrg.contains(channelName))
//                    continue;
//                String channelNameInMap = channelName.startsWith("test") ? channelName.substring(4) : channelName;
//
//                //String[] split = channel.getChainCodeId() == null ? new String[]{} : channel.getChainCodeId().split("_");
//                String chainCodeId = channel.getChainCodeId();
//
//                DisplayChannelVO displayChannelVO;
//                if (displayChannelMap.get(channelNameInMap) != null) {
//                    displayChannelVO = displayChannelMap.get(channelNameInMap);
//                } else {
//                    displayChannelVO = new DisplayChannelVO();
//                }
//
//                if (channelName.startsWith("test")) {
//                    displayChannelVO.setTestChannelName(channelName);
//                    displayChannelVO.setTestChannelStatus(channel.getStatus());
//                    displayChannelVO.setTestChainCodeId(channel.getChainCodeId());
//                    //if (split.length == 3) displayChannelVO.setTestChainCodeName(split[1]);
//                    if (StringUtils.isNotEmpty(chainCodeId)) {
//                        displayChannelVO.setTestChainCodeName(chainCodeId.substring(chainCodeId.indexOf("_") + 1, chainCodeId.lastIndexOf("_")));
//                    }
//                } else {
//                    displayChannelVO.setChannelName(channelName);
//                    displayChannelVO.setChannelId(channelName);
//                    displayChannelVO.setChannelStatus(channel.getStatus());
//                    displayChannelVO.setChainCodeId(channel.getChainCodeId());
//                    if (StringUtils.isNotEmpty(chainCodeId)) {
//                        displayChannelVO.setChainCodeName(chainCodeId.substring(chainCodeId.indexOf("_") + 1, chainCodeId.lastIndexOf("_")));
//                    }
//                }
//                displayChannelVO.setCreateDate(DateUtil.DateToString(channel.getGmtCreate(), DateStyle.YYYY_MM_DD_HH_MM));
//                displayChannelMap.put(channelNameInMap, displayChannelVO);
//            }
//        }
//
//        List<DisplayChannelVO> mValuesList = new ArrayList<>(displayChannelMap.values());
//        //按照时间进行排序
//        Collections.sort(mValuesList, new Comparator<DisplayChannelVO>() {
//            @Override
//            public int compare(DisplayChannelVO o1, DisplayChannelVO o2) {
//                String t1 = o1.getCreateDate();
//                String t2 = o2.getCreateDate();
//                if(t1 ==null || t2 == null ){
//                    return 0;
//                }
//                long longt1 = Long.valueOf(t1.replaceAll("[-\\s:]", ""));
//                long longt2 = Long.valueOf(t2.replaceAll("[-\\s:]", ""));
//
//                if (longt1 > longt2) {
//                    return -1;
//                } else if (longt1 == longt2) {
//                    return 0;
//                } else {
//                    return 1;
//                }
//            }
//        });
//
//        result.setTotal(mValuesList.size());
//        mValuesList = RAMPageService.page(mValuesList, current, size);
//
//
//        if (mValuesList != null && mValuesList.size() > 0) {
//            for (DisplayChannelVO displayChannelVO : mValuesList) {
//                if (displayChannelVO != null) {
//                    String channelName = displayChannelVO.getChannelName();
//                    String testChannelName = displayChannelVO.getTestChannelName();
//                    if (StringUtils.isNotEmpty(channelName) && !channelName.startsWith("test")) {
//                        displayChannelVO.setOrgNum(orgMaps.get(channelName));
//                    }
//                    if (StringUtils.isNotEmpty(testChannelName) && testChannelName.startsWith("test")
//                            && StringUtils.isNotEmpty(displayChannelVO.getTestChainCodeId())) {
//                        for (JsonNode jsonNode : chainMapOrgNodes) {
//                            ChainMapOrg chainMapOrg = JsonaUtils.recordJsonToObject(jsonNode, ChainMapOrg.class);
//                            if (chainMapOrg != null && displayChannelVO.getTestChainCodeId().equals(chainMapOrg.getChain())) {
//                                if (StringUtils.isNotEmpty(chainMapOrg.getResult()) && !"-1".equals(chainMapOrg.getResult())) {
//                                    displayChannelVO.setFeedbackStatus(true);
//                                } else {
//                                    displayChannelVO.setFeedbackStatus(false);
//                                }
//                                break;
//                            }
//                        }
//                    }
//                }
//            }
//        }
//
//        result.setRecords(mValuesList);
//        return result;
//    }
//
//    /**
//     * 根据orgid查询channelName
//     *
//     * @return
//     */
//    private Set<String> getChannelNameByOrgId() {
//        Set<String> returnName = new HashSet<String>();
//        String query = FindQueryBuilder.begin(ChannelMapOrgVO.DOC_TYPE).eq("orgId", orgId).build();
//        byte[] bytes = commonChannel.query("customeQuery", byte[].class, query);
//        ArrayNode jsonNodes = (ArrayNode) JsonaUtils.toJsonNode(bytes);
//        for (JsonNode jsonNode : jsonNodes) {
//            ChannelMapOrgVO channelOrg = JsonaUtils.recordJsonToObject(jsonNode, ChannelMapOrgVO.class);
//            returnName.add(channelOrg.getChannelName());
//        }
//        return returnName;
//    }
//
//
    public long queryBlockHeight(ChannelClient channelClient, String channelName) {
    	
        Channel channel = channelClient.getChannel();
        try {
            long height = getCurrentBlockHeight(channel);
            return height;
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * 获取 当前区块高度
     */
    public long getCurrentBlockHeight(Channel channel) throws InvalidArgumentException, ProposalException, IOException {
        BlockchainInfo channelInfo = channel.queryBlockchainInfo();
        return channelInfo.getHeight();
    }
//
////    public List partnerOrgs(String channelName, int status) {
////        FindQueryBuilder queryFindQueryBuilder = FindQueryBuilder.begin(ChannelMapOrgVO.DOC_TYPE).eq("channelName", channelName);
////        String query = null;
////        if (status == 1) {
////            query = queryFindQueryBuilder.eq("status", status).build();
////        } else {
////            query = queryFindQueryBuilder.build();
////        }
////        byte[] bytes = commonChannel.query("customeQuery", byte[].class, query);
////        ArrayNode jsonNodes = (ArrayNode) JsonaUtils.toJsonNode(bytes);
////        List<Map> resultList = null;
////        Map orgMap = null;
////        if (jsonNodes != null && jsonNodes.size() > 0) {
////            resultList = new ArrayList<>(jsonNodes.size());
////            for (JsonNode jsonNode : jsonNodes) {
////                ChannelMapOrgVO channelMapOrgVO = JsonaUtils.recordJsonToObject(jsonNode, ChannelMapOrgVO.class);
////                if (channelMapOrgVO != null) {
////                    if (channelMapOrgVO.getOrgId() != null && !"".equals(channelMapOrgVO.getOrgId())) {
////                        com.suning.snbc.developer.portal.dto.user.Organization organization = organizationRepository.getOrganization(channelMapOrgVO.getOrgId(), null);
////                        if (organization != null) {
////                            orgMap = new HashMap();
////                            orgMap.put("orgId", organization.getOrgId());
////                            orgMap.put("orgName", organization.getOrgName());
////                            orgMap.put("orgLevel", organization.getLevel());
////                            orgMap.put("is_join", (channelMapOrgVO.getStatus() != null && channelMapOrgVO.getStatus() == 0) || channelMapOrgVO.getStatus() == null
////                                    ? false : true);
////                            orgMap.put("registerTime", DateUtil.DateToString(channelMapOrgVO.getRegisterTime(), DateStyle.YYYY_MM_DD_HH_MM));
////                            resultList.add(orgMap);
////                        }
////                    }
////                }
////            }
////        }
////        return resultList;
////    }
//
//
//    public Map queryChannelinfo(String channelName) throws ProposalException, IOException, InvalidArgumentException {
//        Map returnMap = new HashMap();
//        returnMap.put("channelHeight", queryBlockHeight(channelName));
//
//        Channel channel = getChannelByName(channelName, queryChaincodeName(channelName));
//        returnMap.put("transactionCounrt", getAllTransNum(channel));
//
//        return returnMap;
//    }
//
//    /**
//     * 获取 总交易数
//     */
//    public long getAllTransNum(Channel channel) throws InvalidArgumentException, ProposalException, IOException {
//        long totalNum = 0;
//        BlockchainInfo channelInfo = channel.queryBlockchainInfo();
//        for (long current = channelInfo.getHeight() - 1; current > -1; --current) {
//            BlockInfo returnedBlock = channel.queryBlockByNumber(current);
//            final int envelopeCount = returnedBlock.getEnvelopeCount();
//            totalNum = totalNum + envelopeCount;
//        }
//        return totalNum;
//    }
//
//    /*查看单一区块信息 service*/
//    public Map<String, Object> queryChannelByName(String channelName, Integer blockId) throws InvalidArgumentException, ProposalException {
//        Channel channel = getChannelByName(channelName, queryChaincodeName(channelName));
//        Map<String, Object> result = getMapInfo(channel, blockId);
//        return result;
//    }
//
//    public Map<String,Object> getMapInfo(Channel channel, Integer blockId) throws InvalidArgumentException, ProposalException {
//        Map<String,Object> result = new HashMap<String,Object>();
//        BlockInfo  blockInfo =  channel.queryBlockByNumber(blockId);
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String createTime=null;
//        Iterable<BlockInfo.EnvelopeInfo> itretor=blockInfo.getEnvelopeInfos();
//        int count=0;
//        for (BlockInfo.EnvelopeInfo envelopeInfo : itretor) {
//            count++;
//            if(count>=2){
//                break;
//            }
//            createTime=sdf.format(envelopeInfo.getTimestamp());
//        }
//        result.put("blockId", blockInfo.getBlockNumber());
//        //result.put("blockHash", blockInfo.getDataHash());
//        try {
//            result.put("blockHash", Hex.encodeHexString(SDKUtils.calculateBlockHash(getSDKUtilsHFClient(),blockInfo.getBlockNumber(), blockInfo.getPreviousHash(), blockInfo.getDataHash())));
//        } catch (IOException e) {
//            //e.printStackTrace();
//        }
//        result.put("transactionCount", blockInfo.getEnvelopeCount());
//        result.put("createTime", createTime);
//        return result;
//    }
// 

    /**
     * 存储接口调用记录
     * @param channelName
     * @param chaincodeName
     * @param fcn
     */
	public void storeInvokeCount(String channelName, String chaincodeName, String fcn) {
		try {
			Connection coon = DerbyUtil.getConnection();
			coon.setAutoCommit(false);
	    	   Statement s = coon.createStatement();
//	    	   String existSql =  "SELECT count(*) FROM fcnInvokeCountTable where channelname='"+channelName+"' and chaincodename='"+chaincodeName+"' and fcnname='"+fcn+"'";
//	    	   boolean isExist = false;
//	    	   ResultSet existrs = s.executeQuery(existSql);
//	    	   while (existrs.next()) {
//	    		   isExist = true;
//				}
	    	   
	    	   
	    	   String sql = "SELECT count FROM fcnInvokeCountTable where channelname='"+channelName+"' and chaincodename='"+chaincodeName+"' and fcnname='"+fcn+"'";
	    	   int count = 0;
	    	   ResultSet rs = s.executeQuery(sql);
				while (rs.next()) {
					count = rs.getInt(1);
				}
				count++;
				
				String updatesql = "insert into fcnInvokeCountTable(channelname,chaincodename,fcnname,count) values('"+channelName+"','"+chaincodeName+"','"+fcn+"',"+count+")";
				if(count>1){
					updatesql = "update fcnInvokeCountTable set count = "+count+" where channelname='"+channelName+"' and chaincodename='"+chaincodeName+"'";
				}
				s.execute(updatesql);
				coon.commit();
				
				DerbyUtil.close(rs,s,coon);
		} catch (SQLException e) {
			logger.error("存储调用记录失败！"+e.getMessage());
			e.printStackTrace();
		}
		
	}

	public Page<Map> queryInvokeCount(String channelName, PageQuery<Map> queryVO) {
		Page<Map> pageResult = queryVO.toPage(); 
		
		try {
			List<Map> records = new ArrayList<Map>();
			Connection coon = DerbyUtil.getConnection();
			coon.setAutoCommit(false);
	    	   Statement s = coon.createStatement();
	    	   String countsql = "SELECT count(*) FROM fcnInvokeCountTable where channelname='"+channelName+"'";
	    	   ResultSet countrs = s.executeQuery(countsql);
	    	   int total =0;
				while (countrs.next()) {
					total = countrs.getInt(1);
				}
				pageResult.setTotal(total);
				DerbyUtil.close(countrs,null,null);
				int current = queryVO.getCurrent();
				int size = queryVO.getSize();
				int startIndex = current*size;
	    	   
	    	   String sql = "SELECT chaincodename,fcnname,count FROM fcnInvokeCountTable where channelname='"+channelName+"' OFFSET "+startIndex+" ROWS FETCH NEXT "+size+" ROWS ONLY";
	    	   ResultSet rs = s.executeQuery(sql);
				while (rs.next()) {
					Map record = new HashMap();
					String chaincodename = rs.getString("chaincodename");
					String fcnname = rs.getString("fcnname");
					int count = rs.getInt("count");
					record.put("chainCodeName", chaincodename);
					record.put("methodName", fcnname);
					record.put("invokeSuccessCount", count);
					records.add(record);
				}
				pageResult.setRecords(records);
				coon.commit();
				DerbyUtil.close(rs,s,coon);
		} catch (SQLException e) {
			logger.error("查询调用记录失败！"+e.getMessage());
			e.printStackTrace();
		}
		
		
		
		return pageResult;
	}
}
