package com.suning.snbc.developer.portal.dto.user;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class ChannelMapChainVO {

    public static final String DOC_TYPE = "CHANNELMAPCHAIN";
    private String docType = "CHANNELMAPCHAIN";

    private String id;

    private String channelName;

    private String chainId;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date deployTime;

    private Integer isUsed;
}
