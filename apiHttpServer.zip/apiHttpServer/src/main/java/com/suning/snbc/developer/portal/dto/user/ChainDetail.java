package com.suning.snbc.developer.portal.dto.user;

import java.io.Serializable;

import lombok.Data;
import lombok.experimental.Accessors;
/**
 * 
* Description: 合约详情
* Title: ChainDetail.java
* @author 88399341 - jiang
* @date 2018-05-08 11:49
 */
@Data
@Accessors(chain = true)
public class ChainDetail implements Serializable{
	private static final long serialVersionUID = -1L;

	private Integer chainCodeId;
	private String name;
	private String version;
	private String content;
	
}
