package com.suning.snbc.developer.support;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.CollectionUtils;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * @author 17031596@cnsuning.com
 */
public class Helper {
    public static  String encodeImageBase64(BufferedImage image) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream(image.getWidth()*image.getHeight()*4);
        ImageIO.write(image,"JPG",buf);
        return Base64.encodeBase64String(buf.toByteArray());
    }

    public static String uuid(){
        return UUID.randomUUID().toString().replace("-","");
    }

    public static Integer validInteger(Integer value,Integer min,Integer max){
        if(value == null)return null;
        if(min != null && value.compareTo(min)<0)return min;
        if(max != null && value.compareTo(max)>0)return max;
        return value;
    }

    public static <T> List<T> pageList(List<T> list,int pageIndex,int size){
        return subList(list,(pageIndex-1)*size,size);
    }

    public static <T> List<T> subList(List<T> list,int offset,int size){
        if(CollectionUtils.isEmpty(list))return list;
        if(list.size()<offset)return Collections.emptyList();
        int toIndex = Math.min(offset + size,list.size());
        return list.subList(offset,toIndex);
    }
}
