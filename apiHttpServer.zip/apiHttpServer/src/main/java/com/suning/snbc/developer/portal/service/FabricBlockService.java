package com.suning.snbc.developer.portal.service;

import com.alibaba.fastjson.JSONObject;
import com.suning.snbc.developer.portal.dto.user.BlockVO;
import com.suning.snbc.developer.portal.dto.user.TransatcionVO;
import com.suning.snbc.developer.support.DateStyle;
import com.suning.snbc.developer.support.DateUtil;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hyperledger.fabric.sdk.BlockInfo;
import org.hyperledger.fabric.sdk.BlockchainInfo;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.SDKUtils;
import org.hyperledger.fabric.sdk.exception.CryptoException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.hyperledger.fabric.sdk.BlockInfo.EnvelopeType.TRANSACTION_ENVELOPE;

/**
 * @author 14020107@cnsuning.com
 * Date 2018/4/26
 */
@Service
public class FabricBlockService {

    private static final Log logger = LogFactory.getLog(FabricBlockService.class);

    /**
     * 获取 前NUM个 Block
     */
    public List<BlockVO> getBlocks(Channel channel, String blockParam, long num) throws InvalidArgumentException, ProposalException, IOException {
        if (num <= 0) {
            num = 100;
        }
        BlockchainInfo channelInfo = channel.queryBlockchainInfo();
        List<BlockVO> blockList = new ArrayList<BlockVO>();
        for (long current = channelInfo.getHeight() - 1; current > current - num; --current) {
            if (current < 0) break;
            BlockVO vo = new BlockVO();
            BlockInfo returnedBlock = channel.queryBlockByNumber(current);
            final long blockNumber = returnedBlock.getBlockNumber();
            final int envelopeCount = returnedBlock.getEnvelopeCount();
            String dataHash = Hex.encodeHexString(returnedBlock.getDataHash());
            String preHash = Hex.encodeHexString(returnedBlock.getPreviousHash());
            String blockHash = Hex.encodeHexString(SDKUtils.calculateBlockHash(getSDKUtilsHFClient(),blockNumber, returnedBlock.getPreviousHash(), returnedBlock.getDataHash()));

            if(StringUtils.isNotEmpty(blockParam) &&
                    !blockParam.equals(blockNumber+"") && !blockParam.equals(blockHash)){
                continue;
            }

            vo.setBlockNum(blockNumber).setBlockHash(blockHash).setDataHash(dataHash).setPreHash(preHash).setTrasNum(envelopeCount).setChannelId(returnedBlock.getChannelId());
            if (envelopeCount > 0) {
                BlockInfo.EnvelopeInfo info = returnedBlock.getEnvelopeInfo(envelopeCount - 1);
                vo.setCreateTime(DateUtil.DateToString(info.getTimestamp(), DateStyle.YYYY_MM_DD_HH_MM_SS));
            }
            blockList.add(vo);
        }
        return blockList;
    }
    
    private HFClient getSDKUtilsHFClient(){
    	HFClient client = HFClient.createNewInstance();

        try {
			client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
		} catch (CryptoException | InvalidArgumentException | IllegalAccessException | InstantiationException
				| ClassNotFoundException | NoSuchMethodException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        return client;
    }

    /**
     * 获取 当前区块高度
     */
    public long getCurrentBlockHeight(Channel channel) throws InvalidArgumentException, ProposalException, IOException {
        BlockchainInfo channelInfo = channel.queryBlockchainInfo();
        return channelInfo.getHeight();
    }


    /**
     * 获取 总交易数
     */
    public long getAllTransNum(Channel channel) throws InvalidArgumentException, ProposalException, IOException {
        long totalNum = 0;
        BlockchainInfo channelInfo = channel.queryBlockchainInfo();
        for (long current = channelInfo.getHeight() - 1; current > -1; --current) {
            BlockInfo returnedBlock = channel.queryBlockByNumber(current);
            final int envelopeCount = returnedBlock.getEnvelopeCount();
            totalNum = totalNum + envelopeCount;
        }
        return totalNum;
    }

    /**
     * 根据BlockNum  获取当前区块的所有交易信息
     */
    public List<TransatcionVO> getTransactionsByBlockNum(Channel channel, long blockNum) throws InvalidArgumentException, ProposalException, IOException {
        List<TransatcionVO> trasatcionList = new ArrayList<TransatcionVO>();
        BlockInfo blockInfo = channel.queryBlockByNumber(blockNum);
        final long blockNumber = blockInfo.getBlockNumber();
        String blockHash = Hex.encodeHexString(SDKUtils.calculateBlockHash(getSDKUtilsHFClient(),blockNumber, blockInfo.getPreviousHash(), blockInfo.getDataHash()));
//        arg不是string类型的type
        Set<String> argNotStrSet = new HashSet<String>(){
            {
                add("deploy");
                add("upgrade");
                add("init");
            }
        };

        for (BlockInfo.EnvelopeInfo envelopeInfo : blockInfo.getEnvelopeInfos()) {
            TransatcionVO vo = new TransatcionVO();
            vo.setBlockHash(blockHash);
            vo.setBlockNum(blockNumber);
            vo.setTransactionID(envelopeInfo.getTransactionID());
            vo.setCreateTime(DateUtil.DateToString(envelopeInfo.getTimestamp(), DateStyle.YYYY_MM_DD_HH_MM));
            if (envelopeInfo.getType() == TRANSACTION_ENVELOPE) {
                BlockInfo.TransactionEnvelopeInfo transactionEnvelopeInfo = (BlockInfo.TransactionEnvelopeInfo) envelopeInfo;
                transactionEnvelopeInfo.getValidationCode();
                for (BlockInfo.TransactionEnvelopeInfo.TransactionActionInfo transactionActionInfo : transactionEnvelopeInfo.getTransactionActionInfos()) {
                    String args = "";
                    String type = "";
                    for (int z = 0; z < transactionActionInfo.getChaincodeInputArgsCount(); ++z) {
                        byte[] argArr = transactionActionInfo.getChaincodeInputArgs(z);
                       String arg = new String(argArr, "UTF-8");
                        if(z==0){
                            type = arg;
                        }
                       if (z==2&&argNotStrSet.contains(type)){
                           logger.info("对应操作arg不是字符串");
                           break;
                       }
                        args = args + "," + arg;
                    }
                    vo.setChainCodeArgs(StringUtils.removeFirst(args, ","));
                }
            }
            if (vo.getChainCodeArgs()==null){vo.setChainCodeArgs("");}
            trasatcionList.add(vo);
        }
        return trasatcionList;
    }

    /**

     * byte数组转换成16进制字符数组

     * @param src

     * @return

     */

    public static String[] bytesToHexStrings(byte[] src){

        if (src == null || src.length <= 0) {

            return null;

        }

        String[] str = new String[src.length];



        for (int i = 0; i < src.length; i++) {

            int v = src[i] & 0xFF;

            String hv = Integer.toHexString(v);

            if (hv.length() < 2) {

                str[i] = "0";

            }

            str[i] = hv;

        }

        return str;

    }

    public static String replaceBlank(String str) {
        String dest = "";
        if (str != null) {
            Pattern p = Pattern.compile("\\s*|\t|\r|\n|\b|\n+");
            Matcher m = p.matcher(str);
            dest = m.replaceAll("");
        }
        return dest;
    }


    /**
     * 获取 前NUM个 Block 的Trasactions
     */
    public List<TransatcionVO> getTransactions(Channel channel, String transactionHash, long num) throws InvalidArgumentException, ProposalException, IOException {
        if (num <= 0) {
            num = 100;
        }
        BlockchainInfo channelInfo = channel.queryBlockchainInfo();
        List<TransatcionVO> trasatcionList = new ArrayList<TransatcionVO>();
        for (long current = channelInfo.getHeight() - 1; current > current - num; --current) {
            if (current < 0) break;
            BlockInfo returnedBlock = channel.queryBlockByNumber(current);
            final long blockNumber = returnedBlock.getBlockNumber();
            String blockHash = Hex.encodeHexString(SDKUtils.calculateBlockHash(getSDKUtilsHFClient(),blockNumber, returnedBlock.getPreviousHash(), returnedBlock.getDataHash()));
            for (BlockInfo.EnvelopeInfo envelopeInfo : returnedBlock.getEnvelopeInfos()) {

                if(StringUtils.isNotEmpty(transactionHash) &&
                        !transactionHash.equals(envelopeInfo.getTransactionID())){
                    continue;
                }

                TransatcionVO vo = new TransatcionVO();
                vo.setBlockHash(blockHash).setBlockNum(blockNumber);
                vo.setBlockNum(blockNumber);
                vo.setTransactionID(envelopeInfo.getTransactionID());
                vo.setCreateTime(DateUtil.DateToString(envelopeInfo.getTimestamp(), DateStyle.YYYY_MM_DD_HH_MM));
                if (StringUtils.isNotEmpty(vo.getTransactionID())) {
                    //如果trancId 为空不添加（0 blockNum）
                    trasatcionList.add(vo);
                }
            }
        }
        return trasatcionList;
    }

}
