package com.suning.snbc.developer.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import com.suning.snbc.developer.support.BusinessException;

public class FileUtil {

//	上传合约tar包的临时路径
	private static String tmpUploadPath = "D:\\";
	// tag包固定分割字符 chaincode
	public static final String TAGSPLITSTR = "chaincode";
		
	public static InputStream getUploadFileStream(String fileData) throws FileNotFoundException {
    	File f = new File(tmpUploadPath+TAGSPLITSTR+".tar");
    	byte[] bdata = Base64.decode(fileData);

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(f);

            fos.write(bdata);

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            try {
                fos.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
            }
          }
        if(!f.exists())
        	throw new BusinessException("上传合约转化失败");
		return new FileInputStream(f);
	}

}
