package com.suning.snbc.developer.portal.shiro;

import com.suning.snbc.developer.portal.ResultCode;
import com.suning.snbc.developer.support.BusinessException;
import org.apache.shiro.aop.MethodInvocation;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.authz.aop.AuthorizingAnnotationHandler;
import org.apache.shiro.authz.aop.AuthorizingAnnotationMethodInterceptor;
import org.apache.shiro.session.Session;

import java.lang.annotation.Annotation;

/**
 * @author 17031596@cnsuning.com
 */
public class SessionKickOutMethodInterceptor extends AuthorizingAnnotationMethodInterceptor {

    public SessionKickOutMethodInterceptor() {
        super(new AuthorizingAnnotationHandler(Annotation.class){
            @Override
            public void assertAuthorized(Annotation a) throws AuthorizationException {

            }
        });
    }

    @Override
    public void assertAuthorized(MethodInvocation mi) throws AuthorizationException {
        Session session = this.getSubject().getSession(false);
        if(session == null)return;
        if(session.getAttribute("_KICKOUT_") != null) {
            session.stop();
            throw new BusinessException(ResultCode.LOGON_UNAUTHENTICATED, "您的账号从其他地点已经登录");
        }
    }

    @Override
    public boolean supports(MethodInvocation mi) {
        return true;
    }
}
