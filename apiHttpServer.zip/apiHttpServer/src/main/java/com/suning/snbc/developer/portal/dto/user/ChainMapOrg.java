package com.suning.snbc.developer.portal.dto.user;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;


@Data
@Accessors(chain = true)
public class ChainMapOrg {

    public static final String DOC_TYPE = "CHAINMAPORG";
    private String docType = "CHAINMAPORG";

    private String id;

    private String chain;

    private String org;

    private String result;

    private String suggestion;

    private Date time;

}
