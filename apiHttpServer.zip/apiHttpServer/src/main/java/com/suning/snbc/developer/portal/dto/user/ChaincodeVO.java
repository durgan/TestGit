package com.suning.snbc.developer.portal.dto.user;

import java.util.Date;


import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class ChaincodeVO {

    public static final String DOC_TYPE = "CHAINCODE";
    private String docType = "CHAINCODE";

    private String id;

    private String name;

    private String version;

    private Date createTime;

    //@JsonIgnore
    private String content;

    private String origin;

    private String creater;
}

