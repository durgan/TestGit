package com.suning.snbc.developer.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.UnsupportedEncodingException;

/**
 * @author 17031596@cnsuning.com
 */
public class JsonUtils {
    private static final ObjectMapper MAPPER = new ObjectMapper();
    static {
        MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        MAPPER.configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false);
        MAPPER.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
    }

    public static <T> T jsonToObject(String json, Class<T> cl) {
        if(json == null)
            return null;
        try {
            return MAPPER.readValue(json, cl);
        } catch (RuntimeException e) {
            throw  e;
        }catch (Throwable e) {
            throw new IllegalArgumentException("parse json exception :" + json,e);
        }
    }

    public static <T> T jsonToObject(String json, TypeReference<T> cl) {
        if(json == null)
            return null;
        try {
            return MAPPER.readValue(json, cl);
        }catch (RuntimeException e) {
            throw  e;
        }catch (Throwable e) {
            throw new IllegalArgumentException("parse json exception :" + json,e);
        }
    }


    public static <T> T jsonToObject(byte[] bytes, Class<T> cl) {
        if(bytes == null || bytes.length == 0)
            return null;
        try {
            return MAPPER.readValue(bytes, cl);
        } catch (RuntimeException e) {
            throw  e;
        }catch (Throwable e) {
            throw new IllegalArgumentException("parse json exception :" + utf8String(bytes),e);
        }
    }

    public static <T> T jsonToObject(byte[] bytes, TypeReference<T> cl) {
        if(bytes == null || bytes.length == 0)
            return null;
        try {
            return MAPPER.readValue(bytes, cl);
        }catch (RuntimeException e) {
            throw  e;
        }catch (Throwable e) {
            throw new IllegalArgumentException("parse json exception :" + utf8String(bytes),e);
        }
    }

    private static String utf8String(byte[] bytes){
        if(bytes == null || bytes.length == 0)
            return null;
        try {
            return new String(bytes,"UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * 对象转换为json
     *
     * @param obj 需要转换对象
     * @return 转换后的json串
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static String objecToJson(Object obj) {
        try {
            return MAPPER.writeValueAsString(obj);
        } catch (RuntimeException e) {
            throw  e;
        }catch (Throwable e) {
            throw new IllegalArgumentException("as json exception :" + obj,e);
        }
    }


}
