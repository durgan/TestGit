package com.suning.snbc.developer.framework.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.suning.snbc.developer.portal.shiro.StatelessAuthcFilter;

@Configuration
public class FilterConfig {

	
	
	@Bean
	public StatelessAuthcFilter StatelessAuthcFilterRegistry() {
		return new StatelessAuthcFilter();
	}
}
