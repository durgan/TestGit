package com.suning.snbc.developer.portal.constant.enumValue;

import java.util.Date;

public class Constants {
    public static final String SESSION_USER_INFO = "SESSION_USER_INFO";
    public static final String SESSION_IMAGE_CODE = "SESSION_IMAGE_CODE";
    public interface ORG_STATUS {
        Integer UNREGSITER = 0;
        Integer REGSITER = 1;
    }

    public static final String COMMON_SET = "set";

    public static final String MESSAGE_ = "Message_";


    public static final String MESSAGE_DEVELOPER_DEPLOY = "部署成功";

    public static final String MESSAGE_DEVELOPER_REFUSE= "测试不通过";

    public static final String MESSAGE_DEPLOY_TYPE = "合约部署";

    public static final String MESSAGE_CHANNEL_INVITE = "通道邀请";

    public static final String MESSAGE_CHAINCODEDEPLAY_FEEDBACK = "合约部署反馈";

    public static final String MESSAGE_CHAINCODEDEPLAYFail_FEEDBACK = "测试不通过";

    public static final String MESSAGE_TEST_SUMMARY = "合约待部署，请开始测试。";

    public static final String MESSAGE_DEPLOY_SUMMARY = "合约已正式部署。";

    //public static final String MESSAGE_CHANNELINVITE_SUMMARY = "通道邀请您加入。";

    public static String getTestChannelName(String channelName){
        return "test"+channelName;
    }

    public static String getChainId(String channelName,String chainName,String version){
        return channelName+"_"+chainName+"_"+version;
    }

    public static String getMessageId(String orgId){
        return "Message_" + orgId + "_"+new Date().getTime();
    }
}
