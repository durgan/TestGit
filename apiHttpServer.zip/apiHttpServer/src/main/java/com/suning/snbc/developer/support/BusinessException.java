package com.suning.snbc.developer.support;

import com.suning.snbc.developer.portal.ResultCode;

/**
 * @author 17031596@cnsuning.com
 */
public class BusinessException extends RuntimeException {
    private ResultCode resultCode = ResultCode.SERVER_ERROR;
    private String resultMessage;
    private String developerMessage;
    private String requestId;

    public BusinessException( ResultCode resultCode, String resultMessage) {
        super(resultMessage);
        this.resultCode = resultCode;
        this.resultMessage = resultMessage;
    }
    
    public BusinessException( ResultCode resultCode, String resultMessage,String developerMessage,String requestId) {
        super(resultMessage);
        this.resultCode = resultCode;
        this.resultMessage = resultMessage;
        this.developerMessage = developerMessage;
        this.requestId = requestId;
    }

    public BusinessException(String resultMessage) {
        super(resultMessage);
        this.resultMessage = resultMessage;
    }
    
    public BusinessException(String resultMessage,String developerMessage,String requestId) {
        super(resultMessage);
        this.resultMessage = resultMessage;
        this.developerMessage = developerMessage;
        this.requestId = requestId;
    }

    public ResultCode getResultCode() {
        return resultCode;
    }

    public String getResultMessage() {
        return resultMessage;
    }

	public String getDeveloperMessage() {
		return developerMessage;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setResultCode(ResultCode resultCode) {
		this.resultCode = resultCode;
	}

	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}
    
    

}
