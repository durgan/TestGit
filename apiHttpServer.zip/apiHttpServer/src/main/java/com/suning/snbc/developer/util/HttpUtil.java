package com.suning.snbc.developer.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSONObject;

/**
 * http辅助工具类 Description: Title: HttpUtil.java
 * 
 * @author 88399341 - jiang
 * @date 2018-05-11 09:56
 */
public class HttpUtil {

	private static final Log logger = LogFactory.getLog(HttpUtil.class);

	/**
	 * 上传文件
	 * 
	 * @param desUrl
	 * @param toSubmitUrl
	 * @param paramMap
	 * @throws IOException
	 * @throws ClientProtocolException
	 */
	public static boolean sendFile(String desUrl, String toSubmitUrl, Map<String, Object> paramMap)
			throws ClientProtocolException, IOException {
		boolean returnBool = false;
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		CloseableHttpResponse httpResponse = null;
		RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(200000).setSocketTimeout(200000000)
				.build();
		HttpPost httpPost = new HttpPost(desUrl);
		httpPost.setConfig(requestConfig);
		MultipartEntityBuilder multipartEntityBuilder = MultipartEntityBuilder.create();
		multipartEntityBuilder.setCharset(Charset.forName("UTF-8"));

		multipartEntityBuilder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		ContentType contentType = ContentType.create(HTTP.PLAIN_TEXT_TYPE, HTTP.UTF_8);
		// 填充参数
		File file = new File(toSubmitUrl);
		multipartEntityBuilder.addBinaryBody("file", file, contentType, file.getName());
		multipartEntityBuilder.addTextBody("userName", paramMap.get("userName").toString(), contentType);
		multipartEntityBuilder.addTextBody("chainCodeName", paramMap.get("chainCodeName").toString(), contentType);

		HttpEntity httpEntity = multipartEntityBuilder.build();
		httpPost.setEntity(httpEntity);

		httpResponse = httpClient.execute(httpPost);
		HttpEntity responseEntity=null;
		int statusCode=0;
		if(null!=httpResponse){ responseEntity= httpResponse.getEntity();	
		statusCode = httpResponse.getStatusLine().getStatusCode();}
		if (statusCode == 200) {
			BufferedReader reader = new BufferedReader(new InputStreamReader(responseEntity.getContent()));
			StringBuffer buffer = new StringBuffer();
			String str = "";
			while (!StringUtils.isEmpty(str = reader.readLine())) {
				buffer.append(str);
			}
            reader.close();
			String resultStr = buffer.toString();

			JSONObject resultJSON = JSONObject.parseObject(resultStr);

			logger.info("上传文件返回:"+resultJSON.toJSONString());

			returnBool =  (Integer) resultJSON.get("success") == 1 ? true : false;
		}

		httpClient.close();
		if (httpResponse != null) {
			httpResponse.close();
		}

		return returnBool;

	}

	public static String doPost(String url, String params) throws ClientProtocolException, IOException {

		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(url);// 创建httpPost
		httpPost.setHeader("Accept", "application/json");
		httpPost.setHeader("Content-Type", "application/json");
		String charSet = "UTF-8";

		StringEntity entity = new StringEntity(params, charSet);
		httpPost.setEntity(entity);
		CloseableHttpResponse response = null;

		try {

			response = httpclient.execute(httpPost);
			StatusLine status = response.getStatusLine();
			int state = status.getStatusCode();
			if (state == HttpStatus.SC_OK) {
				HttpEntity responseEntity = response.getEntity();
				String jsonString = EntityUtils.toString(responseEntity);
				return jsonString;
			} else {
				logger.info("请求返回:" + state + "(" + url + ")");
			}
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
					logger.error(e);
				}
			}
			try {
				httpclient.close();
			} catch (IOException e) {
				logger.error(e);
			}
		}
		return null;
	}

	public static String doGet(String url) {
		try {
			HttpClient client = new DefaultHttpClient();
			// 发送get请求
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			/** 请求发送成功，并得到响应 **/
			if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				/** 读取服务器返回过来的json字符串数据 **/
				String strResult = EntityUtils.toString(response.getEntity(), "gb2312");

				return strResult;
			}
		} catch (IOException e) {
			logger.error(e);
		}

		return null;
	}
	
	public static void main(String[] args) {
		String toStr = "ef=http://durgan.host3v.vip/s.txt?FileMd5Key=c4eb22e2bd957fbc4b315b32acec03f0";
		Pattern p=Pattern.compile("(durgan)"); 
		Matcher m=p.matcher(toStr); 
		m.find();   //匹配aaa2223 
		m.groupCount();   //返回2,因为有2组 
//		m.start(1);   //返回0 返回第一组匹配到的子字符串在字符串中的索引号 
		System.out.println(m.find());
		System.out.println(m.start(1));

//		System.out.println(doGet("http://durgan.host3v.vip/s.txt?FileMd5Key=486ee0dc015e011252510ef3bbcf4c0e"));
	}

}
