package com.suning.snbc.developer.framework.support;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author 17031596@cnsuning.com
 */
public class IntValueEnumTypeHandler<E extends Enum & IntValueEnum> extends BaseTypeHandler<IntValueEnum> {
    private Class<E> type;

    public IntValueEnumTypeHandler(Class<E> type) {
        this.type = type;
    }

    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, IntValueEnum intValueEnum, JdbcType jdbcType) throws SQLException {
        preparedStatement.setInt(i,intValueEnum.getValue());
    }

    @Override
    public IntValueEnum getNullableResult(ResultSet resultSet, String s) throws SQLException {
        int value = resultSet.getInt(s);
        return resultSet.wasNull()?null:codeOf(value);
    }

    @Override
    public IntValueEnum getNullableResult(ResultSet resultSet, int i) throws SQLException {
        int value = resultSet.getInt(i);
        return resultSet.wasNull()?null:codeOf(value);
    }

    @Override
    public IntValueEnum getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        int value = callableStatement.getInt(i);
        return callableStatement.wasNull()?null:codeOf(value);
    }

    private E codeOf(int value){
        E[] enumConstants = type.getEnumConstants();
        for (E e : enumConstants) {
            if (e.getValue() == value)
                return e;
        }
        return null;
    }
}
