package com.suning.snbc.developer.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.TimeZone;

public class JsonaUtils {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    static {
        MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        MAPPER.configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false);
        MAPPER.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        MAPPER.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));

    }

    public static <T> T jsonToObject(String json, Class<T> cl) {
        if(json == null)
            return null;
        try {
            return MAPPER.readValue(json, cl);
        } catch (RuntimeException e) {
            throw  e;
        }catch (Throwable e) {
            throw new IllegalArgumentException("parse json exception :" + json,e);
        }
    }

    public static <T> T jsonToObject(JsonNode json, Class<T> cl) {
        if(json == null)
            return null;
        else
            return jsonToObject(json.toString(), cl);
    }

    public static <T> T jsonToObject(JsonNode json, String field,Class<T> cl) {
        if(json == null)
            return null;
        else
            return jsonToObject(json.get(field), cl);
    }

    /**
     * couchdb 合约查询json结果 转成对象
     * @param  json json
     * @param cl 目标类
     * @param <T> 类型
     * @return 对象
     */
    public static <T> T recordJsonToObject(JsonNode json,Class<T> cl) {
        return jsonToObject(json,"Record", cl);
    }

    /**
     * couchdb 合约查询json结果，第一条Record 转成对象
     * @param  bytes json bytes
     * @param cl 目标类
     * @param <T> 类型
     * @return 对象
     */
    public static <T> T singleRecordJsonToObject(byte[] bytes,Class<T> cl) {
        if(bytes == null)return null;
        ArrayNode jsonNodes = (ArrayNode) JsonaUtils.toJsonNode(bytes);
        if(jsonNodes.size() == 0)
            return null;
        return recordJsonToObject(jsonNodes.get(0),cl);
    }

//    public static <T> T jsonToObject(String json, TypeReference<T> cl) {
//        if(json == null)
//            return null;
//        try {
//            return MAPPER.readValue(json, cl);
//        }catch (RuntimeException e) {
//            throw  e;
//        }catch (Throwable e) {
//            throw new IllegalArgumentException("parse json exception :" + json,e);
//        }
//    }


    public static <T> T jsonToObject(byte[] bytes, Class<T> cl) {
        if(bytes == null || bytes.length == 0)
            return null;
        try {
            return MAPPER.readValue(bytes, cl);
        } catch (RuntimeException e) {
            throw  e;
        }catch (Throwable e) {
            throw new IllegalArgumentException("parse json exception :" + utf8String(bytes),e);
        }
    }

//    public static <T> T jsonToObject(byte[] bytes, TypeReference<T> cl) {
//        if(bytes == null || bytes.length == 0)
//            return null;
//        try {
//            return MAPPER.readValue(bytes, cl);
//        }catch (RuntimeException e) {
//            throw  e;
//        }catch (Throwable e) {
//            throw new IllegalArgumentException("parse json exception :" + utf8String(bytes),e);
//        }
//    }

    private static String utf8String(byte[] bytes){
        if(bytes == null || bytes.length == 0)
            return null;
        try {
            return new String(bytes,"UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * 对象转换为json
     *
     * @param obj 需要转换对象
     * @return 转换后的json串
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static String objecToJson(Object obj) {
        try {
            return MAPPER.writeValueAsString(obj);
        } catch (RuntimeException e) {
            throw  e;
        }catch (Throwable e) {
            throw new IllegalArgumentException("as json exception :" + obj,e);
        }
    }

    public static JsonNode toJsonNode(byte[] bytes) {
        if(bytes == null)return null;
        String str = new String(bytes, Charset.forName("UTF-8"));
        try {
            return MAPPER.readTree(str);
        } catch (IOException e) {
            throw new BusinessException("parse json exception for [ " + str + " ]");
        }
    }

}
