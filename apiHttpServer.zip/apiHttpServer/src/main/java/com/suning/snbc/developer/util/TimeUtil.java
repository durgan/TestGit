package com.suning.snbc.developer.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeUtil {
	
	//获取当前时间，格式：yyyy-MM-dd HH:mm:ss
	public static String formatTime(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(new Date());
	}
	//把时间格式转换为String:"yyyy-MM-dd HH:mm:ss"
	public static String formatStringbyDate(Date time){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(time);
	}
	
}
