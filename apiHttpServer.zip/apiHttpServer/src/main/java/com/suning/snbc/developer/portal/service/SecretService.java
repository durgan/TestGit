package com.suning.snbc.developer.portal.service;

import java.io.File;
import java.io.IOException;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.suning.snbc.developer.framework.support.sign.SecretConfig;
import com.suning.snbc.developer.framework.support.sign.SecretConfigFactory;
import com.suning.snbc.developer.portal.ResultCode;
import com.suning.snbc.developer.support.BusinessException;
import com.suning.snbc.developer.util.RSAEncrypt;
import com.suning.snbc.developer.util.RSASignature;
@Service("secretService")
public class SecretService {

	
	@Resource
    private SecretConfigFactory secretConfigFactory;
	
	/**
	 * 刷新存储的appid 和 APPsecret
	 * @param appkey
	 * @param appsecret
	 * @param sign
	 * @return
	 */
	public boolean refreshSecret(String appkey, String appsecret, String sign) {
		try {
			SecretConfig secretConfig = secretConfigFactory.getSecretConfig();
//			String publicSecret = secretConfig.getPublicSecret();
			boolean isValidate = checkSignValid(appkey,appsecret,sign);
			if(isValidate){
				SecretConfig newSecretConfig = secretConfigFactory.updateKeySecret(appkey, appsecret);
				String nv = newSecretConfig.getKeySecretMap().get(appkey);
				
				if(nv!=null&&nv.equals(appsecret)){
					return true;
				}else{
					throw new BusinessException(ResultCode.SERVER_ERROR, "api server没有成功存储吗，更新失败！");
				}
			}else{
				throw new BusinessException(ResultCode.SERVER_ERROR, "签名不合法，请查看api server公钥校对签名流程！");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	/**
	 * 根据公钥校验签名是否合法
	 * @param appkey
	 * @param appsecret
	 * @param sign
	 * @param publicSecret
	 * @return
	 * @throws Exception 
	 */
	private boolean checkSignValid(String appkey, String appsecret, String sign){
//		String goalsign = RSASignature.sign("vvsfds",RSAEncrypt.loadPrivateKeyByFile(secretConfigFactory.getBaseDir()+secretConfigFactory.secretFileName),"UTF-8");
    	boolean isOk = false;
		try {
			isOk = RSASignature.doCheck(appkey+appsecret,sign,RSAEncrypt.loadPrivateKeyByFile(secretConfigFactory.getBaseDir()+secretConfigFactory.secretFileName),"UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException(ResultCode.SERVER_ERROR, "公钥校验签名出错");
		}

		return isOk;
	}
	
	 
	 

}
